"""Shared FastAPI dependencies."""

from __future__ import annotations

from collections.abc import AsyncIterator

from fastapi import Depends, Header, HTTPException, status
from psycopg import AsyncConnection

from api.settings import Settings, get_settings
from db.pool import connection


async def db_conn() -> AsyncIterator[AsyncConnection]:
    """Yield a connection from the pool. Releases on request close."""
    async with connection() as conn:
        yield conn


def require_admin_token(
    x_admin_token: str | None = Header(default=None, alias="X-Admin-Token"),
    settings: Settings = Depends(get_settings),
) -> None:
    """Gate an endpoint behind the `X-Admin-Token` header."""
    if not settings.admin_token:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="admin endpoints disabled (set ADMIN_TOKEN in .env to enable)",
        )
    if x_admin_token != settings.admin_token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="invalid admin token",
        )
