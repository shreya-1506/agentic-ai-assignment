"""FastAPI app + lifespan-managed daemons.

One uvicorn process hosts:
  - this HTTP API
  - the orchestrator polling loop (started in lifespan; cooperatively stopped on shutdown)
  - future: the communication-event polling loop (Step 14)
"""

from __future__ import annotations

import asyncio
import contextlib

import structlog
from fastapi import FastAPI

import agents  # noqa: F401  triggers agent registry side-effects
from agents import orchestration_agent
from api.routes import admin as admin_routes
from api.routes import call as call_routes
from api.routes import cases as cases_routes
from api.routes import clinician as clinician_routes
from api.routes import extraction as extraction_routes
from api.routes import health as health_routes
from api.routes import intake as intake_routes
from api.routes import outreach as outreach_routes
from api.routes import review as review_routes
from api.routes import scheduling as scheduling_routes
from api.settings import get_settings
from db.pool import close_pool, get_pool
from skills._common import configure_logging

log = structlog.get_logger(__name__)


@contextlib.asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup: open pool, start orchestrator daemon. Shutdown: stop daemon, close pool."""
    configure_logging()
    settings = get_settings()
    log.info("api_startup_begin", app=settings.app_name, env=settings.env)

    # Pool warm-up (idempotent if already opened).
    await get_pool()

    stop_event = asyncio.Event()
    orchestrator_task: asyncio.Task | None = None

    if settings.orchestrator_enabled:
        orchestrator_task = asyncio.create_task(
            orchestration_agent.run(
                poll_interval_s=settings.orchestrator_poll_seconds,
                stop_event=stop_event,
            ),
            name="orchestrator_daemon",
        )
        log.info(
            "orchestrator_daemon_started",
            poll_seconds=settings.orchestrator_poll_seconds,
        )
    else:
        log.info("orchestrator_daemon_disabled")

    try:
        yield
    finally:
        log.info("api_shutdown_begin")
        if orchestrator_task is not None:
            stop_event.set()
            try:
                await asyncio.wait_for(orchestrator_task, timeout=10.0)
            except asyncio.TimeoutError:
                log.warning("orchestrator_daemon_cancel_forced")
                orchestrator_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await orchestrator_task
        await close_pool()
        log.info("api_shutdown_complete")


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title="TCM POC API",
        description=(
            "Multi-agent post-discharge Transitional Care Management. "
            "The single uvicorn process hosts the API + the orchestrator polling loop."
        ),
        version="0.1.0",
        lifespan=lifespan,
    )

    app.include_router(health_routes.router)
    app.include_router(cases_routes.router)
    app.include_router(extraction_routes.router)
    app.include_router(outreach_routes.router)
    app.include_router(review_routes.router)
    app.include_router(clinician_routes.router)
    app.include_router(call_routes.router)
    app.include_router(scheduling_routes.router)
    app.include_router(intake_routes.router)
    app.include_router(admin_routes.router)

    @app.get("/", tags=["meta"], include_in_schema=False)
    async def root() -> dict:
        return {
            "app": settings.app_name,
            "env": settings.env,
            "docs": "/docs",
            "health": "/health",
        }

    return app


app = create_app()
