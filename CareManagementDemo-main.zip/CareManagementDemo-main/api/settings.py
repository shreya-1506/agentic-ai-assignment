"""Typed environment configuration via pydantic-settings.

Single source of truth for env-driven runtime config. Reads `.env` in the
project root + `os.environ`. Hand-rolled `_load_env` helpers in `scripts/`
remain for one-shot CLI tools; the API uses this class.
"""

from __future__ import annotations

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Process-wide config."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",  # tolerate .env keys we don't care about
        case_sensitive=False,
    )

    # ---- App ---------------------------------------------------------------
    app_name: str = "tcm-poc"
    log_level: str = "INFO"
    env: str = "local"

    # ---- Postgres ---------------------------------------------------------
    database_url: str

    # ---- Bedrock ----------------------------------------------------------
    bedrock_region: str = "us-east-1"
    bedrock_model_id: str = "us.anthropic.claude-haiku-4-5-20251001-v1:0"
    bedrock_embedding_model_id: str = "amazon.titan-embed-text-v2:0"
    bedrock_embedding_dimensions: int = 1024

    # ---- Orchestrator daemon ---------------------------------------------
    orchestrator_enabled: bool = True
    orchestrator_poll_seconds: int = 5
    orchestrator_tick_limit: int = 10

    # ---- Human gate -------------------------------------------------------
    clinician_review_sla_hours: int = 4

    # ---- Admin endpoints --------------------------------------------------
    # When None or empty, admin endpoints respond 503. Set to a non-empty
    # string in `.env` to enable them (require `X-Admin-Token: <value>`).
    admin_token: str | None = Field(default=None)


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]
