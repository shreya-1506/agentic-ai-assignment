"""FastAPI surface for the TCM POC.

Single uvicorn process hosts:
  - the HTTP API (this package)
  - the orchestrator polling loop (started in `main.lifespan`)
  - future: the communication-event polling loop
"""
