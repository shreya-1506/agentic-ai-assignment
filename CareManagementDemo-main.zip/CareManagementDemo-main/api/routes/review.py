"""Human-gate reviewer endpoint.

`POST /cases/{case_id}/review` records the clinician's outcome
(approve / reject / escalate) and transitions the case state accordingly:

  approve   -> DOCUMENT_APPROVED        (orchestrator then auto-transitions
                                          to OUTREACH_SCHEDULED on its next tick,
                                          and dispatches outreach_agent the tick after)
  reject    -> ESCALATED                (clinician unhappy with extraction;
                                          senior CM / medical director picks it up)
  escalate  -> ESCALATED                (same target; semantically a manual escalation)
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from psycopg import AsyncConnection
from pydantic import BaseModel, Field

from api.dependencies import db_conn
from api.settings import Settings, get_settings
from db.state import update_case_state
from db.state_io import get_case, insert_reviewer_decision
from models.schemas import Case, CaseState, ReviewerDecision, ReviewerOutcome

router = APIRouter(prefix="/cases", tags=["reviewer"])


class ReviewIn(BaseModel):
    reviewer_id: str = Field(..., examples=["clinician.sarah@example.com"])
    outcome: ReviewerOutcome
    comments: str | None = None


_OUTCOME_TO_STATE: dict[ReviewerOutcome, CaseState] = {
    ReviewerOutcome.APPROVE: CaseState.DOCUMENT_APPROVED,
    ReviewerOutcome.REJECT: CaseState.ESCALATED,
    ReviewerOutcome.ESCALATE: CaseState.ESCALATED,
}


@router.post(
    "/{case_id}/review",
    response_model=Case,
    responses={
        404: {"description": "case not found"},
        409: {"description": "case not in DOCUMENT_PENDING_REVIEW"},
    },
)
async def post_review(
    case_id: str,
    review: ReviewIn,
    conn: AsyncConnection = Depends(db_conn),
    settings: Settings = Depends(get_settings),
) -> Case:
    case = await get_case(conn, case_id)
    if case is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"case_id={case_id} not found",
        )
    if case.current_state != CaseState.DOCUMENT_PENDING_REVIEW:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "error": "case_not_in_review_state",
                "current_state": case.current_state.value,
                "expected_state": CaseState.DOCUMENT_PENDING_REVIEW.value,
            },
        )

    expires_at = datetime.now(timezone.utc) + timedelta(hours=settings.clinician_review_sla_hours)
    decision = ReviewerDecision(
        case_id=case_id,
        reviewer_id=review.reviewer_id,
        outcome=review.outcome,
        comments=review.comments,
        expires_at=expires_at,
    )

    async with conn.transaction():
        await insert_reviewer_decision(conn, decision)

    target_state = _OUTCOME_TO_STATE[review.outcome]
    refreshed = await update_case_state(
        conn,
        case_id,
        target_state,
        agent_name="clinician_review",
        reason=(
            f"reviewer={review.reviewer_id} outcome={review.outcome.value}"
            + (f"; comment={review.comments}" if review.comments else "")
        ),
        metadata={
            "reviewer_id": review.reviewer_id,
            "outcome": review.outcome.value,
            "sla_expires_at": expires_at.isoformat(),
        },
    )
    return refreshed
