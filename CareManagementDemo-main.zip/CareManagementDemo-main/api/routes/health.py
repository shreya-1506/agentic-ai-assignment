"""Health + readiness endpoints."""

from __future__ import annotations

import os

from fastapi import APIRouter, Depends
from psycopg import AsyncConnection

from api.dependencies import db_conn
from api.settings import Settings, get_settings

router = APIRouter(tags=["health"])


@router.get("/health")
async def health(
    conn: AsyncConnection = Depends(db_conn),
    settings: Settings = Depends(get_settings),
) -> dict:
    """Process alive + DB ping + Bedrock client identity probe."""
    db_ok = False
    db_error: str | None = None
    try:
        async with conn.cursor() as cur:
            await cur.execute("SELECT 1")
            await cur.fetchone()
        db_ok = True
    except Exception as exc:
        db_error = f"{type(exc).__name__}: {exc}"

    # Light check — Bedrock client init only (no API call here to keep /health cheap).
    bedrock_configured = bool(
        os.environ.get("AWS_ACCESS_KEY_ID") or os.environ.get("AWS_PROFILE")
    )

    return {
        "status": "ok" if db_ok else "degraded",
        "app": settings.app_name,
        "env": settings.env,
        "db": {"ok": db_ok, "error": db_error},
        "bedrock": {
            "region": settings.bedrock_region,
            "chat_model": settings.bedrock_model_id,
            "embed_model": settings.bedrock_embedding_model_id,
            "credentials_present": bedrock_configured,
        },
        "orchestrator": {
            "enabled": settings.orchestrator_enabled,
            "poll_seconds": settings.orchestrator_poll_seconds,
        },
    }
