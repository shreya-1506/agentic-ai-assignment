"""Clinician queue endpoint.

`GET /clinician/queue` lists cases currently in `DOCUMENT_PENDING_REVIEW`
with the number of flagged extracted fields per case, so the reviewer UI
can prioritize by complexity.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from psycopg import AsyncConnection
from pydantic import BaseModel

from api.dependencies import db_conn
from models.schemas import Case, CaseState

router = APIRouter(prefix="/clinician", tags=["clinician"])


class QueueItem(BaseModel):
    case: Case
    flagged_count: int
    total_fields: int


@router.get("/queue", response_model=list[QueueItem])
async def queue(
    limit: int = Query(default=50, ge=1, le=500),
    conn: AsyncConnection = Depends(db_conn),
) -> list[QueueItem]:
    """Cases awaiting clinician review, oldest first."""
    async with conn.cursor() as cur:
        await cur.execute(
            """
            SELECT c.*,
                   COALESCE(ef.total,   0) AS total_fields,
                   COALESCE(ef.flagged, 0) AS flagged_count
              FROM cases c
              LEFT JOIN (
                  SELECT case_id,
                         count(*)                      AS total,
                         count(*) FILTER (WHERE flagged) AS flagged
                    FROM extracted_fields
                   GROUP BY case_id
              ) ef ON ef.case_id = c.case_id
             WHERE c.current_state = %s
             ORDER BY c.created_at ASC
             LIMIT %s
            """,
            (CaseState.DOCUMENT_PENDING_REVIEW.value, limit),
        )
        rows = await cur.fetchall()
        col_names = [d[0] for d in cur.description]

    out: list[QueueItem] = []
    for row in rows:
        rec = dict(zip(col_names, row))
        flagged_count = rec.pop("flagged_count")
        total_fields = rec.pop("total_fields")
        out.append(
            QueueItem(
                case=Case.model_validate(rec),
                flagged_count=int(flagged_count),
                total_fields=int(total_fields),
            )
        )
    return out
