"""Mid-call scheduling endpoints (CM-triggered, consent-gated).

`POST /cases/{case_id}/schedule` is fired by the CM panel after verbal
consent appears in the live call transcript. Pre-conditions:
  - case exists (404)
  - case is in CM_CALLBACK_IN_PROGRESS (409)
  - latest CallSession has consent_captured=True (409)

`GET /cases/{case_id}/appointment` returns the booked appointment for the
case (the most recent, if multiple).
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from psycopg import AsyncConnection
from pydantic import BaseModel, Field

from agents import scheduling_agent
from api.dependencies import db_conn
from db.state_io import (
    get_case,
    get_latest_appointment,
    get_latest_call_session,
)
from models.exceptions import ConsentNotCaptured
from models.schemas import Appointment, CaseState

router = APIRouter(prefix="/cases", tags=["scheduling"])


class ScheduleIn(BaseModel):
    cm_id: str = Field(..., examples=["cm.sarah@example.com"])


class ScheduleOut(BaseModel):
    case_id: str
    current_state: CaseState
    appointment: Appointment


@router.post(
    "/{case_id}/schedule",
    response_model=ScheduleOut,
    status_code=status.HTTP_201_CREATED,
    responses={
        404: {"description": "case not found"},
        409: {"description": "case not in CM_CALLBACK_IN_PROGRESS or consent not captured"},
    },
)
async def schedule(
    case_id: str,
    body: ScheduleIn,
    conn: AsyncConnection = Depends(db_conn),
) -> ScheduleOut:
    case = await get_case(conn, case_id)
    if case is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"case_id={case_id} not found",
        )
    if case.current_state != CaseState.CM_CALLBACK_IN_PROGRESS:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "error": "case_not_in_callback_state",
                "current_state": case.current_state.value,
                "expected_state": CaseState.CM_CALLBACK_IN_PROGRESS.value,
            },
        )

    call = await get_latest_call_session(conn, case_id)
    if call is None or not call.consent_captured:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "error": "consent_not_captured",
                "hint": "verbal consent must appear in the live call transcript",
            },
        )

    try:
        await scheduling_agent.run(case_id, cm_id=body.cm_id, call_id=call.call_id)
    except ConsentNotCaptured as exc:
        # Defensive — the agent re-checks consent internally.
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={"error": "consent_not_captured", "message": str(exc)},
        )

    refreshed = await get_case(conn, case_id)
    appt = await get_latest_appointment(conn, case_id)
    assert refreshed is not None and appt is not None
    return ScheduleOut(
        case_id=case_id,
        current_state=refreshed.current_state,
        appointment=appt,
    )


@router.get(
    "/{case_id}/appointment",
    response_model=Appointment,
    responses={404: {"description": "no appointment for case"}},
)
async def get_appointment(
    case_id: str,
    conn: AsyncConnection = Depends(db_conn),
) -> Appointment:
    appt = await get_latest_appointment(conn, case_id)
    if appt is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"no appointment for case_id={case_id}",
        )
    return appt
