"""Discharge-extraction read endpoints.

`GET /cases/{case_id}/extraction` returns the per-field extraction map +
flag summary + a `ready_for_review` boolean. The reviewer UI (Step 10) will
poll this endpoint while building the human-gate decision.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from psycopg import AsyncConnection
from pydantic import BaseModel

from api.dependencies import db_conn
from db.state_io import get_case, list_extracted_fields
from models.schemas import CaseState, ExtractedField

router = APIRouter(prefix="/cases", tags=["extraction"])


class ExtractionView(BaseModel):
    case_id: str
    current_state: CaseState
    total_fields: int
    flagged_count: int
    flagged_field_names: list[str]
    ready_for_review: bool
    fields: list[ExtractedField]


@router.get("/{case_id}/extraction", response_model=ExtractionView)
async def get_extraction(
    case_id: str,
    conn: AsyncConnection = Depends(db_conn),
) -> ExtractionView:
    case = await get_case(conn, case_id)
    if case is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"case_id={case_id} not found",
        )

    fields = await list_extracted_fields(conn, case_id)
    flagged = [f for f in fields if f.flagged]
    return ExtractionView(
        case_id=case_id,
        current_state=case.current_state,
        total_fields=len(fields),
        flagged_count=len(flagged),
        flagged_field_names=[f.field_name for f in flagged],
        ready_for_review=case.current_state == CaseState.DOCUMENT_PENDING_REVIEW,
        fields=fields,
    )
