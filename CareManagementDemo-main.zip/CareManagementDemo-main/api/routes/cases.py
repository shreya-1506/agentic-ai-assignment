"""Case-read endpoints.

`GET /cases/{case_id}` returns the full case view (cases row + risk scores
+ extracted fields + audit log). `GET /cases` lists cases by state.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from psycopg import AsyncConnection
from pydantic import BaseModel

from api.dependencies import db_conn
from db.state_io import (
    get_case,
    get_risk_scores,
    list_audit_log,
    list_cases_in_state,
    list_compliance_findings,
    list_extracted_fields,
    list_referrals,
)
from models.schemas import (
    AuditLogEntry,
    Case,
    CaseState,
    ComplianceFinding,
    ExtractedField,
    Referral,
    RiskScores,
)

router = APIRouter(prefix="/cases", tags=["cases"])


class CaseView(BaseModel):
    """Aggregated read model for a single case."""

    case: Case
    risk_scores: RiskScores | None = None
    extracted_fields: list[ExtractedField] = []
    referrals: list[Referral] = []
    compliance_findings: list[ComplianceFinding] = []
    audit_log: list[AuditLogEntry] = []


@router.get("/{case_id}", response_model=CaseView)
async def get_case_view(
    case_id: str,
    conn: AsyncConnection = Depends(db_conn),
) -> CaseView:
    case = await get_case(conn, case_id)
    if case is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"case_id={case_id} not found",
        )
    return CaseView(
        case=case,
        risk_scores=await get_risk_scores(conn, case_id),
        extracted_fields=await list_extracted_fields(conn, case_id),
        referrals=await list_referrals(conn, case_id),
        compliance_findings=await list_compliance_findings(conn, case_id),
        audit_log=await list_audit_log(conn, case_id),
    )


@router.get("", response_model=list[Case])
async def list_cases(
    state: CaseState | None = Query(default=None, description="Filter by current state"),
    limit: int = Query(default=50, ge=1, le=500),
    conn: AsyncConnection = Depends(db_conn),
) -> list[Case]:
    if state is None:
        # Default: list cases across all dispatchable states (operational view).
        from config.orchestrator import DISPATCHABLE_STATES

        all_cases: list[Case] = []
        for s in DISPATCHABLE_STATES:
            all_cases.extend(await list_cases_in_state(conn, s, limit=limit))
        return sorted(all_cases, key=lambda c: c.created_at or "")[:limit]
    return await list_cases_in_state(conn, state, limit=limit)
