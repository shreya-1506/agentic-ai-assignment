"""Admin endpoints (auth-gated via `X-Admin-Token`)."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query

from agents.orchestration_agent import tick as orchestrator_tick
from api.dependencies import require_admin_token

router = APIRouter(prefix="/admin", tags=["admin"], dependencies=[Depends(require_admin_token)])


@router.post("/orchestrator/tick")
async def force_tick(
    limit: int = Query(default=10, ge=1, le=100),
) -> dict[str, Any]:
    """Force a single orchestrator dispatch pass. Returns the tick's stats."""
    return await orchestrator_tick(limit=limit)
