"""HL7/FHIR discharge-event intake.

`POST /cases/intake` accepts a normalized discharge event, dedupes against
the `cases_dedup_key` UNIQUE constraint, and inserts a new case in
`DISCHARGE_RECEIVED`. Returns the created Case (or 409 with the existing one
on dedup conflict).
"""

from __future__ import annotations

from datetime import date
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from psycopg import AsyncConnection
from psycopg.errors import UniqueViolation
from pydantic import BaseModel, Field

from api.dependencies import db_conn
from db.state_io import get_case, insert_case
from models.schemas import Case, CaseState
from skills._common import get_logger, mint_case_id

router = APIRouter(prefix="/cases", tags=["intake"])


class DischargeEventIn(BaseModel):
    """Normalized discharge event payload."""

    member_id: str = Field(..., examples=["MBR-00847291"])
    facility: str = Field(..., examples=["St. Mary's Medical Center"])
    admit_date: date | None = None
    discharge_date: date
    length_of_stay_days: int | None = Field(default=None, ge=0)
    primary_dx_code: str = Field(..., examples=["J44.1"])
    primary_dx_description: str | None = None
    attending_physician: str | None = None
    pcp_name: str | None = None
    pcp_id: str | None = None
    plan_name: str | None = None
    raw: dict[str, Any] | None = Field(
        default=None,
        description="Original HL7/FHIR payload for full audit trail.",
    )


@router.post(
    "/intake",
    response_model=Case,
    status_code=status.HTTP_201_CREATED,
    responses={409: {"description": "duplicate (member, facility, discharge_date)"}},
)
async def intake(
    event: DischargeEventIn,
    conn: AsyncConnection = Depends(db_conn),
) -> Case:
    case_id = mint_case_id()
    log = get_logger(case_id)

    case = Case(
        case_id=case_id,
        member_id=event.member_id,
        current_state=CaseState.DISCHARGE_RECEIVED,
        discharge_facility=event.facility,
        discharge_date=event.discharge_date,
        admit_date=event.admit_date,
        length_of_stay=event.length_of_stay_days,
        primary_dx_code=event.primary_dx_code,
        primary_dx_description=event.primary_dx_description,
        attending_physician=event.attending_physician,
        pcp_name=event.pcp_name,
        plan_name=event.plan_name,
        raw_discharge_event=event.raw or event.model_dump(mode="json"),
    )

    try:
        async with conn.transaction():
            await insert_case(conn, case)
    except UniqueViolation:
        # Find the existing case and return its id in the conflict response.
        async with conn.cursor() as cur:
            await cur.execute(
                """
                SELECT case_id FROM cases
                 WHERE member_id = %s AND discharge_date = %s AND discharge_facility = %s
                """,
                (event.member_id, event.discharge_date, event.facility),
            )
            row = await cur.fetchone()
        existing_id = row[0] if row else None
        log.info(
            "intake_duplicate",
            member_id=event.member_id,
            existing_case_id=existing_id,
        )
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "error": "duplicate_discharge_event",
                "existing_case_id": existing_id,
            },
        )

    log.info(
        "intake_accepted",
        member_id=event.member_id,
        facility=event.facility,
        discharge_date=event.discharge_date.isoformat(),
        primary_dx=event.primary_dx_code,
    )
    refreshed = await get_case(conn, case_id)
    assert refreshed is not None
    return refreshed
