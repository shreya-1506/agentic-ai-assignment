"""Outreach-session read endpoints.

`GET /cases/{case_id}/outreach` returns the most recent OutreachSession
for the case: transcript, survey, SDOH flag list, status.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from psycopg import AsyncConnection

from api.dependencies import db_conn
from db.state_io import get_outreach_by_case
from models.schemas import OutreachSession

router = APIRouter(prefix="/cases", tags=["outreach"])


@router.get("/{case_id}/outreach", response_model=OutreachSession)
async def get_outreach(
    case_id: str,
    conn: AsyncConnection = Depends(db_conn),
) -> OutreachSession:
    session = await get_outreach_by_case(conn, case_id)
    if session is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"no outreach session for case_id={case_id}",
        )
    return session
