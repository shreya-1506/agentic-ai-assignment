"""Live-call control endpoints.

`POST /cases/{case_id}/call/start` initiates a CM voice callback:
  - Transitions case OUTREACH_COMPLETE -> CM_CALLBACK_IN_PROGRESS
  - Mints a `CL-NNNNNNNN` call_id and inserts a CallSession row (status=in_progress)
  - Spawns agent_assist_agent.run(...) as a background asyncio task
  - Returns 202 with `{call_id, current_state, status}` immediately

`GET /cases/{case_id}/call` returns the latest CallSession for the case
(polled by the CM panel to watch transcript + sentiment + prompts in
real-time as the background task drives them forward).
"""

from __future__ import annotations

import asyncio

from fastapi import APIRouter, Depends, HTTPException, status
from psycopg import AsyncConnection
from pydantic import BaseModel, Field

from agents import agent_assist_agent
from api.dependencies import db_conn
from db.state import update_case_state
from db.state_io import get_case, insert_call_session, get_call_session
from models.schemas import CallSession, CallStatus, Case, CaseState
from skills._common import mint_call_id

router = APIRouter(prefix="/cases", tags=["call"])


class CallStartIn(BaseModel):
    cm_id: str = Field(..., examples=["cm.sarah@example.com"])


class CallStartOut(BaseModel):
    call_id: str
    case_id: str
    current_state: CaseState
    status: CallStatus


@router.post(
    "/{case_id}/call/start",
    response_model=CallStartOut,
    status_code=status.HTTP_202_ACCEPTED,
    responses={
        404: {"description": "case not found"},
        409: {"description": "case not in OUTREACH_COMPLETE"},
    },
)
async def call_start(
    case_id: str,
    body: CallStartIn,
    conn: AsyncConnection = Depends(db_conn),
) -> CallStartOut:
    case = await get_case(conn, case_id)
    if case is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"case_id={case_id} not found",
        )
    if case.current_state != CaseState.OUTREACH_COMPLETE:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "error": "case_not_ready_for_call",
                "current_state": case.current_state.value,
                "expected_state": CaseState.OUTREACH_COMPLETE.value,
            },
        )

    call_id = mint_call_id()

    # Persist the initial session row + transition the case state, both inside
    # the same handler's transaction (update_case_state opens its own).
    session = CallSession(
        call_id=call_id,
        case_id=case_id,
        cm_id=body.cm_id,
        status=CallStatus.IN_PROGRESS,
    )
    async with conn.transaction():
        await insert_call_session(conn, session)

    await update_case_state(
        conn,
        case_id,
        CaseState.CM_CALLBACK_IN_PROGRESS,
        agent_name="agent_assist_agent",
        reason=f"CM {body.cm_id} started callback; call_id={call_id}",
        metadata={"call_id": call_id, "cm_id": body.cm_id},
    )

    # Spawn the foreground agent as a background task. The reference is held
    # by the running event loop until completion (no GC issue for short jobs).
    asyncio.create_task(
        agent_assist_agent.run(case_id, call_id=call_id, cm_id=body.cm_id),
        name=f"agent_assist_{call_id}",
    )

    return CallStartOut(
        call_id=call_id,
        case_id=case_id,
        current_state=CaseState.CM_CALLBACK_IN_PROGRESS,
        status=CallStatus.IN_PROGRESS,
    )


@router.get(
    "/{case_id}/call",
    response_model=CallSession,
    responses={404: {"description": "no call session for case"}},
)
async def get_call(
    case_id: str,
    conn: AsyncConnection = Depends(db_conn),
) -> CallSession:
    """Return the most recent CallSession for the case."""
    async with conn.cursor() as cur:
        await cur.execute(
            "SELECT call_id FROM call_sessions WHERE case_id = %s "
            "ORDER BY created_at DESC LIMIT 1",
            (case_id,),
        )
        row = await cur.fetchone()
    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"no call session for case_id={case_id}",
        )
    session = await get_call_session(conn, row[0])
    assert session is not None
    return session
