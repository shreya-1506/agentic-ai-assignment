# HANDOFF

> What state is the project in right now? Update at the end of every working session.

## Current step

**Step 12 — `scheduling_agent` (stub) + endpoints + artifact rendering:** complete. `POST /cases/{id}/schedule` books Dr. Luis Garcia at Oct 10 14:00 (POC slot), sends SMS, renders PDF (HTML fallback), updates Patient Journey Calendar, creates follow-up task, inserts Valley CHC pulse oximeter referral, transitions to `APPOINTMENT_BOOKED`. 20-check smoke green.

## Next step

**Step 13 — `compliance_agent` (build STUB) + audit endpoint + deterministic check codes.**

Per BUILD_PROMPT_v2 + [agent_prompts/06_compliance_agent.md](agent_prompts/06_compliance_agent.md):
- Orchestrator-dispatched on `current_state = APPOINTMENT_BOOKED`. Runs 9 deterministic check codes against the persisted case data; emits `ComplianceFinding` rows with severity `pass|warn|fail`.
- Check codes (from BUILD_PROMPT §"Compliance check codes"):
  - `tcm.med_reconciliation_complete`
  - `tcm.pcp_followup_booked`
  - `tcm.pcp_followup_within_7_10_days`
  - `tcm.adherence_trending_positive`
  - `tcm.cmp_enrollment_confirmed`
  - `tcm.transport_referral_created`
  - `tcm.community_resource_shared`
  - `tcm.verbal_consent_captured_in_transcript`  ← hard requirement; failure → ESCALATED
  - `tcm.cms_99495_99496_billable`
- Transitions `APPOINTMENT_BOOKED → CARE_GOALS_MET` if all hard requirements pass; `→ ESCALATED` if the consent check fails. Warnings don't escalate.
- New endpoints:
  - `GET /cases/{id}/compliance` returns `list[ComplianceFinding]`.

Stub uses the John Martinez happy path so all 9 checks pass; teammate replaces with real reading of audit_log + case artifacts.

After Step 13, the full pipeline reaches a terminal state (`CARE_GOALS_MET`) via API only — second full end-to-end demo.

## What's live

- `uv` venv `hh/` (Python 3.11.15)
- Deps installed: psycopg[binary,pool], pgvector, pydantic, structlog, boto3, jinja2, httpx, tenacity
- Neon DB: 13 tables + pgvector + HNSW; `cases` has retry/lease columns
- 22 skill modules, knowledge corpus (40 chunks), orchestrator polling loop, admission_risk_agent stub
- **FastAPI surface live**: `/health`, `/cases`, `/cases/{id}`, `/cases/intake`, `/admin/orchestrator/tick` — Swagger at `/docs`
- Seeded for testing: John Martinez (`MBR-00847291`), `CASE-00099999` currently in **`APPOINTMENT_BOOKED`** with the full artifact set persisted
- Idempotent re-runnable scripts: `bootstrap_db`, `ingest_knowledge`, `smoke_step4_foundations`, `smoke_step4_skills`, `smoke_step5_orchestrator`, `smoke_step6_admission_risk`, `smoke_step7_api`, `smoke_step8_document_extraction`, `smoke_step9_outreach`, `smoke_step10_review`, `smoke_step11_call`, `smoke_step12_scheduling`, `run_orchestrator`
- **`smoke_step12_scheduling` is now the "demo the whole pipeline" script** — walks from `DISCHARGE_RECEIVED` to a booked appointment with full SMS + PDF + calendar artifacts via API only
- Boot the API: `.\hh\Scripts\Activate.ps1; uvicorn api.main:app --reload --port 8000` → http://localhost:8000/docs

## What's live

- `uv` venv `hh/` (Python 3.11.15)
- Deps installed: psycopg[binary,pool], pgvector, pydantic, structlog, boto3, jinja2, httpx, tenacity
- Neon DB: 13 tables + pgvector + HNSW index; `cases` extended with `agent_retry_count`, `agent_last_error`, `next_eligible_at` (Step 5)
- `knowledge_chunks` populated with 40 chunks (1024-dim Titan v2)
- Seeded for testing: John Martinez member (`MBR-00847291`), case `CASE-00099999` parked in `DISCHARGE_RECEIVED`
- 22 skill modules + foundations exercised against real Bedrock + real Neon
- **Orchestrator polling loop live and tested** — `agents.orchestration_agent.tick()` and `run(...)`; dispatch table in `config/orchestrator.py`; agent registry in `agents/_registry.py`
- Idempotent re-runnable scripts: `bootstrap_db`, `ingest_knowledge`, `smoke_step4_foundations`, `smoke_step4_skills`, `smoke_step5_orchestrator`, `run_orchestrator`

## Known deferrals (carry forward)

- WeasyPrint not installed (pdf.render falls back to HTML). Install GTK3 runtime + weasyprint when first agent needs a real PDF.
- Real WebSocket UI push not wired (`skills.ui` is log-file-only).
- STP rules — `config/stp_rules.py` not yet created; will land in Step 6 (admission_risk_agent stub).

## What's live

Nothing runnable yet. Scaffolding only.

## Open business questions (carry forward)

1. STP rules — see [agents.md](agents.md) §"Open business questions"
2. Stage 3 discharge-review-as-separate-gate — see [agents.md](agents.md)
3. Intervenability `/50` vs `/40` — see [agents.md](agents.md)

## Outstanding deferrals

See [DEFERRED.md](DEFERRED.md).
