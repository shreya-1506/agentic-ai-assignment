# COPD Exacerbation — Post-Discharge Protocol

> POC seed content summarizing GOLD (Global Initiative for Chronic Obstructive Lung Disease) post-discharge guidance for AECOPD. Review with clinical SME before production use.

## Goals of the Post-Discharge Period

The first 30 days after an acute exacerbation of COPD (AECOPD) carry the highest readmission risk. The post-discharge plan should aim to: stabilize symptoms, complete the steroid and antibiotic courses prescribed at discharge, optimize maintenance inhaler therapy, identify and address modifiable triggers, confirm appropriate oxygen and pulmonary rehabilitation referrals, and re-establish primary care follow-up within 7–14 days.

A member discharged after AECOPD with a primary diagnosis of J44.1 (COPD with acute exacerbation) should be flagged for proactive outreach within 48 hours of discharge.

## Medication Review at First Outreach

Confirm the member has filled and is taking the medications listed on the discharge medication reconciliation. For a typical AECOPD discharge this commonly includes:

- A short tapering course of systemic corticosteroid (e.g., Prednisone 40 mg daily tapering over 5–14 days). Verify the member understands the taper and end date.
- A short antibiotic course if indicated (e.g., Azithromycin 5-day course or alternative per local resistance patterns).
- A short-acting bronchodilator for as-needed relief (e.g., Albuterol metered-dose inhaler).
- A long-acting maintenance bronchodilator (e.g., Tiotropium 18 mcg daily) and/or a long-acting beta-agonist; for frequent exacerbators or eosinophil-driven phenotypes an inhaled corticosteroid may be added.

Ask about inhaler technique and pickup. If the member reports they have not yet picked up a medication, identify the barrier (cost, transport, prior-authorization confusion) and escalate to the appropriate pathway (pharmacy benefits, plan-covered transport, prior-auth coordinator).

## Symptom Surveillance and Escalation

At each outreach assess for: change in dyspnea severity vs. discharge baseline, sputum volume and color, fever, chest pain, peripheral edema, and home pulse oximetry (SpO₂) if available. Resting SpO₂ < 88% on room air, return of acute dyspnea, new fever, or new cardiac symptoms warrant urgent triage to the PCP or, if symptoms are severe, emergency department.

Document the last in-hospital SpO₂ and the discharge ambulation tolerance as reference points for follow-up calls.

## PCP Follow-Up and Pulmonary Rehab

Schedule the PCP follow-up within 7–10 days of discharge whenever feasible. The follow-up visit should include lung exam, review of inhaler technique, reconciliation of any new prescriptions, and a referral to pulmonary rehabilitation when the member is clinically appropriate. Pulmonary rehabilitation initiated within 4 weeks of an AECOPD has the strongest evidence for reducing readmissions and improving quality of life.

If smoking continues, offer tobacco cessation counseling and pharmacotherapy.

## Home Oxygen and Supportive Devices

If the member was prescribed supplemental oxygen, confirm the equipment delivery and the prescribed flow rate. For members with intermittent low SpO₂ readings or for whom a baseline is desired, consider a pulse oximeter referral (community resource directories often include local programs that provide pulse oximeters at no cost). Document the referral and the expected device delivery date as a follow-up task.
