# CMS Transitional Care Management — Billing & Clinical Requirements

> POC seed content summarizing publicly available CMS guidance (CPT 99495 / 99496). Review with billing SME before production use.

## Overview of TCM Services

Transitional Care Management (TCM) services address the hand-off period between an inpatient or qualifying outpatient discharge and the resumption of community-based primary care. The intent is to reduce avoidable readmissions by ensuring members receive timely follow-up, accurate medication reconciliation, and education on their post-discharge care plan.

A TCM service covers a 30-day period that begins on the date of discharge. Only one TCM service is billable per beneficiary per 30-day period, and the billing practitioner must be the one who furnishes (or supervises) the post-discharge face-to-face visit. The service is reportable to Medicare under CPT 99495 (moderate medical decision making) or CPT 99496 (high medical decision making), with the level driven by the complexity of the medical decision making on the date of the face-to-face visit.

## CPT 99495 — Moderate Complexity

CPT 99495 reflects TCM with moderate complexity medical decision making and a face-to-face visit within 14 calendar days of discharge. Three required elements must be met within the service window:

1. Communication (direct contact, telephone, or electronic) with the beneficiary or caregiver within two business days of discharge.
2. Medical decision making of at least moderate complexity during the service period.
3. A face-to-face visit within 14 calendar days of discharge.

Non-face-to-face services during the 30-day period (medication reconciliation, coordination with home health, referrals, patient/caregiver education) are bundled into the TCM payment and may not be separately billed.

## CPT 99496 — High Complexity

CPT 99496 reflects TCM with high complexity medical decision making and a face-to-face visit within 7 calendar days of discharge. The required two-business-day contact rule and the bundling of non-face-to-face services are identical to 99495. High complexity is documented in the medical decision making section of the encounter note; common triggers include multiple chronic conditions, recent ICU stay, new diagnosis with significant systemic implications, or polypharmacy with high-risk medications.

## Documentation Requirements

The medical record must document the date of discharge, the date and method of the two-business-day contact, the date of the face-to-face visit, the medication reconciliation, and the medical decision making level. If the practitioner attempts the two-business-day contact unsuccessfully but follows the CMS-prescribed escalation pattern, those attempts must be documented; the service may still be billable if the contact is established or if reasonable attempts are documented and the face-to-face visit occurs.

Care plan content typically includes the discharge diagnosis, problem list, current medications with reconciliation notes, identified barriers to care, the follow-up plan, and the patient/caregiver acknowledgment.

## Eligibility and Setting

TCM is billable when the patient is discharged from an inpatient acute hospital, an inpatient psychiatric hospital, a long-term care hospital, a skilled nursing facility, an inpatient rehabilitation facility, a hospital outpatient observation stay, or a partial hospitalization. The patient must return to a community setting (home, domiciliary, rest home, or assisted living). Patients discharged to another inpatient setting are not eligible for TCM by the receiving practitioner until they are subsequently discharged to community.
