# SDOH Screening and Referral Pathways

> POC seed content summarizing the CMS Accountable Health Communities Health-Related Social Needs (AHC HRSN) screening tool and referral pathways. Review with care-management SME before production use.

## Why Screen for HRSN at Discharge

Health-related social needs (HRSN) — housing instability, food insecurity, transportation barriers, utility hardship, and interpersonal safety — materially affect a member's ability to follow a post-discharge care plan. A member who cannot get to the pharmacy will not pick up the steroid taper; a member without reliable food cannot take a medication that requires meals. CMS, through the Accountable Health Communities model, developed a 10-question core screening tool to identify five core HRSN domains at any care transition.

## The Five Core Domains

1. **Housing instability** — current housing status, anticipated loss of housing, exposure to pests/mold/lead/lack of utilities.
2. **Food insecurity** — worry that food would run out before more money was available; food actually ran out.
3. **Transportation** — lack of reliable transportation has kept the member from medical appointments, getting medications, work, or getting essentials.
4. **Utility help needs** — disconnection notice or actual disconnection of electricity, gas, water, or telephone.
5. **Interpersonal safety** — physical or emotional harm from someone close; safety in the current living situation.

A positive screen in any one domain is documented as an `sdoh_flag` and routed into the case context that the live-call CM and the agent-assist co-pilot can see.

## Triage and Referral Pattern

When a flag is captured during outreach, the referral pathway follows three tiers:

- **Tier 1 — plan-covered benefit**. If the plan covers the resource directly (e.g., non-emergency medical transport, OTC food benefit, post-discharge meals), open a benefit utilization request immediately and confirm a delivery/scheduling timeline with the member.
- **Tier 2 — community resource directory**. For needs not covered by the plan benefit, search the community resources directory (Findhelp, Aunt Bertha, or a plan-internal directory). Capture the resource name, contact, and warm-handoff plan in the `referrals` table.
- **Tier 3 — escalation to social work**. For complex needs (active interpersonal safety concern, imminent housing loss), escalate to plan social work or local APS as appropriate.

## Documenting Referrals

Each referral row carries: `resource_name`, `resource_type` (device, service, transport, other), `source` (community, plan, self), and `status` (created, confirmed, received, na). The agent-assist co-pilot will surface unconfirmed referrals during the next CM voice call.

## Closing the Loop

A referral is closed by confirming the member received the service or device. For example, a pulse oximeter referral to a community health center is "confirmed" when the center acknowledges the request and "received" when the member confirms physical receipt of the device. A follow-up task is created at the time of referral to drive this closure.
