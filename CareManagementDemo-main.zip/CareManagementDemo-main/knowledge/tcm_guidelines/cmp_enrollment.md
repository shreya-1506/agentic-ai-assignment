# Care Management Program — Enrollment & Care Goal Definitions

> POC seed content describing CMP enrollment criteria, care goal definitions, and closure rules for the post-discharge cohort. Review with CMP program lead before production use.

## CMP Purpose and Member Value Proposition

The Care Management Program (CMP) pairs each enrolled member with a dedicated nurse case manager and a clinical pharmacist who follow the member for a defined period (typically 60–90 days) post-discharge. The program targets members with high Impactability and high Intervenability — that is, members where outcomes can plausibly be improved AND where the member can plausibly engage. The value proposition is: a single phone number for clinical questions, proactive scheduling support, medication-cost troubleshooting, and a clear escalation path that avoids unnecessary ED visits.

## Enrollment Criteria

A member is eligible for CMP outreach when at least one of the following is true:

- Composite Priority Score in the Medium (50–79) or High (≥ 80) tier following risk stratification.
- A primary discharge diagnosis on the high-risk ICD-10 list (see the high_risk_dx reference) regardless of score.
- Two or more inpatient admissions within the prior 12 months.
- A member-stated need that requires longitudinal coordination (e.g., new oxygen, new chemotherapy, new advanced heart failure regimen).

The member must consent verbally to enrollment during the post-discharge outreach. A declination is logged and the case is closed with disposition `CLOSED_MEMBER_DECLINED`. Members may opt back in at any future transition of care.

## Care Goals (Closure Criteria)

A case is closed with disposition `CARE_GOALS_MET` when all of the following are satisfied:

1. **Medication reconciliation complete** — a documented reconciliation note with no unresolved discrepancies and a member teach-back confirmation.
2. **PCP follow-up booked** — within the 7–10 day window appropriate for the diagnosis (7 days for high-risk discharges such as AECOPD, AHF, post-AMI; up to 14 days for lower-risk).
3. **Adherence trending positive** — pickup confirmed for new prescriptions and the member is not reporting unmanaged side effects or barriers.
4. **CMP enrollment confirmed** — verbal consent captured, welcome packet delivered (electronic or paper).
5. **HRSN needs addressed** — for each positive SDOH flag a referral row exists with status at least `created` and a follow-up task scheduled.

## Care Goal Failure / Escalation

A case escalates to a senior CM or medical director under the following triggers:

- Acute red-flag symptoms reported during outreach (chest pain, severe dyspnea, neurologic change).
- Unable to reach the member after the configured number of attempts (case closes with `CLOSED_NO_CONTACT`).
- High-risk medication discrepancy that the PCP cannot resolve within 24 hours.
- A safety concern documented during HRSN screening.

## Engagement Touchpoints

A typical 60-day engagement includes: a same-week welcome call, a within-7-day clinical check-in, a 14-day medication adherence call, a 30-day comprehensive review with adherence and symptom tracking, and a 60-day graduation discussion that hands off remaining longitudinal needs to the PCP and other ongoing programs.
