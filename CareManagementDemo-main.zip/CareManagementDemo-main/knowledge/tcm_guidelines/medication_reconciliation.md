# Medication Reconciliation — Best Practices

> POC seed content summarizing ASHP and ISMP guidance on medication reconciliation across care transitions. Review with pharmacy SME before production use.

## Why Reconciliation Matters at Discharge

Medication discrepancies are among the most frequent sources of adverse events in the first 30 days after discharge. The Joint Commission's National Patient Safety Goal NPSG.03.06.01 and the ASHP–APhA Joint Statement both call out medication reconciliation at transitions of care as a high-value patient-safety intervention. Errors most commonly involve omissions (a chronic medication dropped from the discharge list), duplications (e.g., a beta-blocker continued under both its generic and brand name), and dosing changes that were not explained to the patient.

A successful reconciliation at discharge produces a single, complete, plain-language list that the patient (or caregiver) understands and can act on.

## The Five-Step Reconciliation Process

1. **Collect the pre-admission list** — pull the most recent ambulatory medication list from the plan's pharmacy claims and the patient's stated home regimen. Include OTC, supplements, inhalers, and PRN medications.
2. **Verify and validate** — cross-check claims against the discharge summary and any new orders. Resolve discrepancies before discharge; document the source of each medication change.
3. **Compare to the discharge plan** — for each medication: continued, discontinued, dose changed, new, or held. Pair each discontinuation with a clinical reason.
4. **Communicate to the patient/caregiver** — provide a written list in the patient's preferred language at a 6th-grade reading level. Confirm understanding with a teach-back.
5. **Communicate to the next care team** — fax or push the list electronically to the PCP and any specialty providers. Notify home health if involved.

## Reconciliation at the First Post-Discharge Outreach

Call early (within 48 hours of discharge) to ask three core questions:

- Did you pick up each new prescription? If not, what is the barrier?
- Are you continuing the medications listed as "continue" on your discharge summary?
- Has anyone told you to stop a medication that is still on your home list?

Pay particular attention to **high-risk medication classes**: anticoagulants, insulins, opioids, immunosuppressants, antiplatelets, digoxin, and chemotherapy. Any discrepancy involving a high-risk medication is escalated to the PCP same day.

## Common Pitfalls

- The patient is given a steroid taper but does not understand the day-by-day dose change. Always teach the taper schedule using a calendar.
- The patient is on both a long-acting and a short-acting inhaler and conflates them. Confirm the technique and the indication of each by name, color, and intended timing.
- A medication is "held" rather than "discontinued" in the inpatient record, and the patient resumes a medication that the inpatient team intended to stop. Translate ambiguous wording to a clear instruction.

## Documentation Standards

The reconciliation note should include: source documents used, the final reconciled list with status per medication, identified discrepancies and how they were resolved, the patient's stated understanding (teach-back), and the date and method of communication to the next care team.
