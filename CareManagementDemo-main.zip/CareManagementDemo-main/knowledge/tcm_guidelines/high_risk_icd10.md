# High-Risk ICD-10 Diagnoses — TCM Escalation Reference

> POC seed reference list of ICD-10-CM categories that should bypass STP and route to clinician review and CMP outreach regardless of computed priority score. Review with clinical leadership before production use. The deterministic list of code prefixes lives in `config/high_risk_dx.csv`.

## Why a Separate High-Risk List

The composite priority score captures most acuity signals, but several conditions warrant CM oversight on every discharge irrespective of the score: they are associated with 30-day readmission rates above 18%, they typically involve regimens that change at discharge, and they benefit measurably from early structured outreach. The categories below are flagged by ICD-10-CM prefix; case management may add more specific codes over time.

## Respiratory

- **J44** — Chronic obstructive pulmonary disease, including J44.0 (with acute lower respiratory infection), J44.1 (with acute exacerbation), J44.9 (unspecified). Driver: high readmission rate; inhaler technique, oxygen needs, and pulmonary rehab referral often need same-week attention.
- **J45.5x** — Severe persistent asthma. Driver: discharge regimens often include systemic corticosteroid taper plus inhaled corticosteroid intensification that must be reconciled with the home regimen.
- **J96.x** — Acute respiratory failure. Driver: oxygen and follow-up needs.

## Cardiovascular

- **I50.x** — Heart failure (all types). Driver: weight-monitoring teaching, diuretic dose changes, sodium/fluid restriction, fast PCP follow-up within 7 days.
- **I21.x / I22.x** — Acute / subsequent MI. Driver: dual antiplatelet therapy adherence, beta-blocker + ACEI/ARB titration, cardiac rehab referral.
- **I48.x** — Atrial fibrillation/flutter, especially when newly anticoagulated. Driver: anticoagulant initiation, INR monitoring (if warfarin), bleeding risk teaching.

## Endocrine

- **E11.x with complications (E11.0–E11.8)** — Type 2 diabetes with hyperosmolarity, ketoacidosis, neurologic, ophthalmic, renal, or other complications. Driver: insulin titration, hypoglycemia teaching, frequent post-discharge changes.
- **E10.1x** — Type 1 diabetes with ketoacidosis. Driver: same as above with higher acuity.

## Neurological

- **I63.x** — Cerebral infarction (ischemic stroke). Driver: secondary-prevention regimen, dysphagia screening for medication form, rehab follow-through.
- **G45.x** — Transient ischemic attack. Driver: time-sensitive workup and antithrombotic initiation.

## Renal

- **N17.x** — Acute kidney injury. Driver: medication dose adjustment, follow-up renal panel, avoiding nephrotoxic OTC products.
- **N18.4 / N18.5** — Chronic kidney disease stage 4 or 5. Driver: medication clearance, dialysis access education when applicable.

## Oncology and Hematology

- **C00–D49** ranges actively on chemotherapy. Driver: neutropenia precautions, antiemetic regimens, mucositis monitoring.
- **D60–D64** — Aplastic and other anemias requiring transfusion or growth-factor support.

## Behavioral Health

- **F33.x / F32.x** with active suicidality (F32.A, F33.A) — Major depressive disorder severe / with suicidality. Driver: safety plan continuity, medication adherence, behavioral-health follow-up appointment confirmation.

## Operationalization

When the extracted `primary_dx_code` matches a prefix in this list, `is_stp(case)` returns `False` regardless of other STP criteria, the case is routed to the human reviewer queue, and CMP outreach is queued upon clinician approval.
