"""Configuration constants for the orchestrator + business rules."""
