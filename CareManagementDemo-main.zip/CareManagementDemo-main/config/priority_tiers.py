"""Composite-priority-score → `PriorityTier` mapping.

Single source of truth for the tiering math. Per BUILD_PROMPT_v2:
  < 50    Low
  50–79   Medium
  ≥ 80    High
"""

from __future__ import annotations

from models.schemas import PriorityTier


def tier_for(composite_score: int) -> PriorityTier:
    """Map a composite priority score (Impactability + Intervenability) to a tier."""
    if composite_score >= 80:
        return PriorityTier.HIGH
    if composite_score >= 50:
        return PriorityTier.MEDIUM
    return PriorityTier.LOW
