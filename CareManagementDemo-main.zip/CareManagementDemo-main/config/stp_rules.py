"""Straight-Through Process (STP) routing rules.

Currently a placeholder: `is_stp(case)` returns False for **every** case,
which routes every discharge through the human clinician gate. Business
has not yet signed off on the candidate rules below. Update this file once
the rules are finalized — `BUILD_PROMPT_v2.md` and `agents.md` track this
as an open question.

Candidate rules (BUSINESS TO CONFIRM):
  1. All extracted fields ≥ 90% confidence
  2. Medication changes ≤ 3 items AND all on plan formulary
  3. No high-risk ICD-10 codes (see config/high_risk_dx.csv)
  4. Prior successful TCM engagement within 24 months
  5. Composite Priority Score < 80
"""

from __future__ import annotations

from models.schemas import Case


def is_stp(case: Case) -> bool:
    """Return True iff `case` qualifies for straight-through-process.

    Currently always False — see module docstring.
    """
    # TODO(business): implement once the 5 candidate rules above are confirmed.
    return False
