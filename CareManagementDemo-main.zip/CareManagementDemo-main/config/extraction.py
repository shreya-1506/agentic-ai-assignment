"""Configuration constants for `document_extraction_agent`.

Single source of truth for:
  - the 13 fields the extractor is expected to return
  - the low-confidence threshold (below which a field is flagged for the
    clinician reviewer)
  - retry / escalation limits for the document-fetch step
  - the system prompt skeleton used by the Bedrock extractor

Kept out of [agents/document_extraction_agent.py](agents/document_extraction_agent.py)
so the prompt + thresholds can be tuned without touching agent control flow,
and so unit tests can import them without standing up the whole agent.
"""

from __future__ import annotations

# -----------------------------------------------------------------------------
# Thresholds
# -----------------------------------------------------------------------------

# A field with confidence strictly below this value is `flagged=True` and the
# reviewer UI renders a red badge. Anchored at 0.80 per `agent_prompts/02_*.md`.
LOW_CONFIDENCE_THRESHOLD: float = 0.80

# Document fetch attempts before the agent escalates the case.
# After this many failed fetches we transition to ESCALATED with a reason.
MAX_DOCUMENT_FETCH_ATTEMPTS: int = 2

# Max characters of parsed document text we pass to the LLM. Bedrock context
# windows are large but we cap here to keep latency + cost bounded and to
# avoid surprising token bills on accidentally-huge documents.
MAX_DOC_CHARS_FOR_LLM: int = 24_000


# -----------------------------------------------------------------------------
# Expected fields
# -----------------------------------------------------------------------------

# Tier hints align with `agent_prompts/02_document_extraction_agent.md`. They
# are NOT used to gate the actual flag (the threshold above is authoritative);
# they ship to the reviewer UI as expected-quality bands and to telemetry so
# we can spot regressions (e.g., a "high" tier field dropping into "medium").
class ExpectedField:
    __slots__ = ("name", "tier", "expected_low", "expected_high")

    def __init__(self, name: str, tier: str, expected_low: float, expected_high: float) -> None:
        self.name = name
        self.tier = tier
        self.expected_low = expected_low
        self.expected_high = expected_high


EXPECTED_FIELDS: tuple[ExpectedField, ...] = (
    ExpectedField("medical_center",              "high",   0.96, 0.99),
    ExpectedField("patient_name",                "high",   0.96, 0.99),
    ExpectedField("mrn",                         "high",   0.96, 0.99),
    ExpectedField("admit_date",                  "high",   0.96, 0.99),
    ExpectedField("discharge_date",              "high",   0.96, 0.99),
    ExpectedField("length_of_stay",              "high",   0.96, 0.99),
    ExpectedField("attending_physician",         "high",   0.96, 0.99),
    ExpectedField("primary_diagnosis",           "high",   0.96, 0.99),
    ExpectedField("hand_off_summary",            "medium", 0.91, 0.95),
    ExpectedField("reason_for_hospitalization",  "medium", 0.91, 0.95),
    ExpectedField("medication_changes",          "low",    0.70, 0.80),
    ExpectedField("last_spo2",                   "medium", 0.85, 0.95),
    ExpectedField("discharge_disposition",       "high",   0.90, 0.98),
)

EXPECTED_FIELD_NAMES: tuple[str, ...] = tuple(f.name for f in EXPECTED_FIELDS)


# -----------------------------------------------------------------------------
# System prompt
# -----------------------------------------------------------------------------

EXTRACTION_SYSTEM_PROMPT: str = """\
You are the document_extraction_agent for a TCM care-management pipeline.
You will receive parsed text from a Hospital Discharge Summary. Extract each
requested field and return a per-field confidence score (0.0-1.0) reflecting
how clearly the field appears in the source.

Confidence rubric:
  >= 0.95   verbatim, unambiguous, single occurrence
  0.85-0.94 clear but inferred (e.g., date format normalized)
  0.70-0.84 present but ambiguous, OCR noise, multiple candidates
  <  0.70   speculative; do NOT guess, return value=null and explain in `reason`

Return ONLY valid JSON with one object per field, exactly the keys below,
no prose outside the JSON, no markdown fences:

{
  "medical_center":              {"value": str|null, "confidence": float, "reason": str},
  "patient_name":                {"value": str|null, "confidence": float, "reason": str},
  "mrn":                         {"value": str|null, "confidence": float, "reason": str},
  "admit_date":                  {"value": "YYYY-MM-DD"|null, "confidence": float, "reason": str},
  "discharge_date":              {"value": "YYYY-MM-DD"|null, "confidence": float, "reason": str},
  "length_of_stay":              {"value": int|null, "confidence": float, "reason": str},
  "attending_physician":         {"value": str|null, "confidence": float, "reason": str},
  "primary_diagnosis":           {"value": str|null, "confidence": float, "reason": str},
  "hand_off_summary":            {"value": str|null, "confidence": float, "reason": str},
  "reason_for_hospitalization":  {"value": str|null, "confidence": float, "reason": str},
  "medication_changes":          {"value": [{"name": str, "dose": str, "instructions": str}]|null,
                                  "confidence": float, "reason": str},
  "last_spo2":                   {"value": str|null, "confidence": float, "reason": str},
  "discharge_disposition":       {"value": str|null, "confidence": float, "reason": str}
}

Notes:
- `primary_diagnosis` MUST include ICD-10 code when present in the source.
- `hand_off_summary` and `reason_for_hospitalization` MUST be <= 500 chars.
- `last_spo2` is the most recent SpO2 percentage with context (room air vs O2).
- Do NOT hallucinate. Missing -> value=null with confidence<0.70 + reason.
- Do NOT include prose outside the JSON. No code fences. No commentary.
"""


__all__ = [
    "EXPECTED_FIELDS",
    "EXPECTED_FIELD_NAMES",
    "EXTRACTION_SYSTEM_PROMPT",
    "ExpectedField",
    "LOW_CONFIDENCE_THRESHOLD",
    "MAX_DOCUMENT_FETCH_ATTEMPTS",
    "MAX_DOC_CHARS_FOR_LLM",
]
