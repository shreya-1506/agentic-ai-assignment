"""Orchestrator dispatch + retry configuration.

What the orchestrator does for each `CaseState`:
  - **DISPATCHABLE_STATES**: it picks the case up and (if registered) dispatches the agent.
  - **AUTO_TRANSITIONS**: it advances the case to the target state itself, no agent.
  - **MILESTONE_STATES**: a transition into one of these emits a `case_events` row
    for the communication_agent to fan out as SMS/email/webhook.
  - All other states (terminal, human-gate, foreground call) are skipped.
"""

from __future__ import annotations

import os

from models.schemas import CaseState

# -----------------------------------------------------------------------------
# Dispatch table: state -> agent registry name
# -----------------------------------------------------------------------------

STATE_TO_AGENT_NAME: dict[CaseState, str] = {
    CaseState.DISCHARGE_RECEIVED:        "admission_risk_agent",
    CaseState.RISK_STRATIFIED:           "document_extraction_agent",
    # DOCUMENT_PENDING_REVIEW          → no agent (human gate)
    # DOCUMENT_APPROVED                → auto-transition (see below)
    CaseState.OUTREACH_SCHEDULED:        "outreach_agent",
    # OUTREACH_COMPLETE                → no orchestrator dispatch
    #                                    (CM starts the live call via API, which
    #                                    triggers agent_assist_agent foreground)
    # CM_CALLBACK_IN_PROGRESS          → foreground (live call lifecycle)
    CaseState.APPOINTMENT_BOOKED:        "compliance_agent",
    # CARE_GOALS_MET / CLOSED_* / ESCALATED → terminal, skipped
}

DISPATCHABLE_STATES: frozenset[CaseState] = frozenset(STATE_TO_AGENT_NAME.keys()) | frozenset(
    # also include auto-transition sources
    {CaseState.DOCUMENT_APPROVED}
)

# Source state → (target state, reason). Orchestrator advances these itself.
AUTO_TRANSITIONS: dict[CaseState, tuple[CaseState, str]] = {
    CaseState.DOCUMENT_APPROVED: (
        CaseState.OUTREACH_SCHEDULED,
        "clinician gate cleared; outreach queued",
    ),
}

# Transitions into these states emit a `case_events` row.
MILESTONE_STATES: frozenset[CaseState] = frozenset(
    {
        CaseState.RISK_STRATIFIED,
        CaseState.DOCUMENT_PENDING_REVIEW,
        CaseState.DOCUMENT_APPROVED,
        CaseState.OUTREACH_SCHEDULED,
        CaseState.OUTREACH_COMPLETE,
        CaseState.APPOINTMENT_BOOKED,
        CaseState.CARE_GOALS_MET,
        CaseState.ESCALATED,
        CaseState.CLOSED_NO_CONTACT,
        CaseState.CLOSED_MEMBER_DECLINED,
    }
)


# -----------------------------------------------------------------------------
# Retry policy
# -----------------------------------------------------------------------------

# `agent_retry_count` reaches MAX_RETRIES → escalate. So MAX_RETRIES=3 means
# the case escalates on the 3rd consecutive failure (after 2 retries).
MAX_RETRIES: int = int(os.environ.get("ORCHESTRATOR_MAX_RETRIES", "3"))

# Backoff schedule. Index N is the delay BEFORE retry #N+1. If fewer entries
# than MAX_RETRIES, the last entry is reused.
RETRY_BACKOFF_SECONDS: tuple[int, ...] = (60, 300, 1800)


# -----------------------------------------------------------------------------
# Dispatch lease
# -----------------------------------------------------------------------------

# When the orchestrator claims a case it bumps `next_eligible_at` forward by
# this much, so a long-running agent isn't re-dispatched mid-flight. Cleared
# on successful `update_case_state`.
DISPATCH_LEASE_SECONDS: int = int(os.environ.get("ORCHESTRATOR_DISPATCH_LEASE_SECONDS", "300"))


# -----------------------------------------------------------------------------
# Polling
# -----------------------------------------------------------------------------

DEFAULT_POLL_SECONDS: int = int(os.environ.get("ORCHESTRATOR_POLL_SECONDS", "5"))
DEFAULT_TICK_LIMIT: int = int(os.environ.get("ORCHESTRATOR_TICK_LIMIT", "10"))
