# Teammate Prompt — Agent 05: `scheduling_agent`

> Hand this to the teammate (or to their Claude Code). Scaffolding, skills, orchestrator, DB schema, and your stub already exist. You're replacing the stub.

## Context

Multi-agent post-discharge TCM POC. This agent **books the PCP follow-up appointment** mid-call, triggered explicitly by the Case Manager during the live voice callback. It's gated on **verbal consent captured in the transcript** — a hard compliance requirement. On success it creates a CRM appointment record, updates the Patient Journey Calendar, sends an SMS confirmation, and queues a follow-up task to verify device receipt + post-PCP-visit check-in.

Read `agents.md`, `skills.md`, and `models/schemas.py` before coding.

## Your role

`scheduling_agent` is **CM-triggered**, not state-polled. The CM clicks "Book appointment" in the UI (or the agent_assist UI offers an inline action); this hits `POST /cases/{id}/schedule/book` which dispatches your agent. You verify consent from the live transcript, check PCP availability, book, and side-effect all the artifacts. State transitions to `APPOINTMENT_BOOKED`.

## Pipeline position

```
CM_CALLBACK_IN_PROGRESS  ──▶  [you, CM-triggered]  ──▶  APPOINTMENT_BOOKED
                                                              │
                                                              ▶ ESCALATED  (booking failed, consent missing)
```

- **Input state:** `CM_CALLBACK_IN_PROGRESS`
- **Output state (success):** `APPOINTMENT_BOOKED`
- **Output state (consent missing):** `CM_CALLBACK_IN_PROGRESS` (no change) — return error to CM UI
- **Output state (PCP unavailable, all options exhausted):** `ESCALATED`

## What you must do

1. **Verify verbal consent** in the live transcript. Fetch the last N=10 transcript turns via `skills.transcript.get_recent(call_id, n=10)`. Use the LLM to classify whether the member has given clear affirmative consent to schedule a PCP appointment in this call. Result schema:
   ```
   { "consent_present": bool, "consent_quote": str|null, "consent_ts": iso8601|null, "confidence": float }
   ```
   - If `consent_present == False` or `confidence < 0.85` → return error to caller, do NOT book. The CM must reaffirm consent.
   - If consent is verified, persist `case.scheduling_consent = {quote, ts, confidence}` for audit.

2. **Fetch PCP availability** via `skills.scheduling.get_availability(pcp_id, window_start, window_end)`. The window is **7–10 days from discharge_date** (per CMS TCM guideline — verify against `knowledge/tcm_guidelines/cms_99495_99496.md`). Returns a list of available slots.

3. **Pick a slot.** Prefer member's `callback_preference` (morning/afternoon/evening from outreach survey). If multiple match, pick the earliest. If none match, surface 3 options back to CM via `skills.ui.push_slot_options(call_id, slots)` and wait for selection. (Use a simple polling pattern with a 60s timeout for POC.)

4. **Book the slot** via `skills.scheduling.book_appointment(pcp_id, slot, case_id)`. Returns `appointment_id`.

5. **Side-effects (all deterministic, all logged):**
   - Create CRM appointment record: `skills.crm.create_appointment(case_id, appointment_id, slot, pcp_id)`
   - Update Patient Journey Calendar: `skills.calendar.add_event(member_id, slot, "PCP follow-up: Dr. <name>")`
   - Send SMS confirmation: `skills.sms.send(member_phone, render_sms_confirmation(...))` using `templates/sms_appointment_confirmation.j2`
   - Queue follow-up task: `skills.crm.create_task(case_id, due=slot+1day, title="Follow up after PCP visit and confirm device receipt", links=[referral_ids from case.referrals])`
   - Generate PDF appointment confirmation: `skills.pdf.render("appointment_confirmation.j2", context)` → save to `data/documents/{case_id}_appt_confirmation.pdf` (using WeasyPrint)

6. **Transition state** to `APPOINTMENT_BOOKED` via `update_case_state`.

## Reasoning vs. determinism

- **LLM-driven**: verbal consent classification (the only LLM call in this agent)
- **Deterministic Python**: window calculation, slot selection, booking, all 5 side-effects, state transition

The CMS 7–10 day window is a hard rule; don't let the LLM decide it. The consent classifier is the only place where reasoning enters.

## System prompt skeleton (for consent classification only)

```
You are verifying whether a patient has given clear verbal consent to schedule a
PCP follow-up appointment during this call. You will receive the last 10 turns of
a transcript between a Case Manager and a patient.

Consent must be:
  - Affirmative ("yes", "sure", "please do", "go ahead", "that's fine")
  - Specific to scheduling (not consent to be on the call, not consent for CMP)
  - Given by the patient (speaker label confirms)
  - Within the current call

Ambiguous, conditional ("maybe later"), or third-party consent does NOT qualify.

Return JSON:
{
  "consent_present": bool,
  "consent_quote": str|null,       // exact patient words from transcript
  "consent_ts": iso8601|null,      // timestamp of the consent turn
  "confidence": float              // 0–1
}
```

## Tools you can call

- `skills.transcript.get_recent(call_id, n)`
- `skills.scheduling.get_availability`, `skills.scheduling.book_appointment`
- `skills.crm.create_appointment`, `skills.crm.create_task`
- `skills.calendar.add_event`
- `skills.sms.send`
- `skills.pdf.render`
- `skills.ui.push_slot_options`

## File you're editing

```
agents/scheduling_agent.py
```

Stub already implements signature, dummy booking, and the state transition.

## Test case (John Martinez)

Expected from POC:
- Verbal consent quote: "Yes, please." (within the last 10 transcript turns)
- Booked: Dr. Luis Garcia, **Oct 10, 2026 at 2:00 PM** (within 7–10 days of Oct 5 discharge)
- CRM appointment record created
- SMS sent to `+15558472910`
- Patient Journey Calendar event added
- Follow-up task created: "Follow up after PCP visit and confirm device receipt" linked to the pulse oximeter referral from `case.referrals`
- PDF confirmation rendered
- State → `APPOINTMENT_BOOKED`

Fixture: `data/samples/john_martinez_callback_transcript.json` (the consent quote sits around turn 14). Unit test asserts all 5 side-effects fired and state advanced.

**Negative test:** swap in a transcript fixture without the consent quote — assert state did NOT advance and an error returned.

## What you must NOT do

- Don't book without verified consent (hard gate; this is a compliance requirement that `compliance_agent` will audit)
- Don't pick a slot outside the 7–10 day window without explicit override
- Don't send the SMS before the booking succeeds (would create a notification with no real appointment)
- Don't proceed if any side-effect fails — roll forward best-effort, but mark `case.scheduling_side_effects_status` with what succeeded/failed so compliance can audit
- Don't log PII in cleartext

## Definition of done

- [ ] `agents/scheduling_agent.py` implemented end-to-end
- [ ] Stub TODO marker removed
- [ ] Idempotent re-entry (if `APPOINTMENT_BOOKED` already, log and exit)
- [ ] Consent classifier unit test (positive + negative cases) passes
- [ ] All 5 side-effects fire in the happy path test
- [ ] PDF artifact renders (visually checked by you — drop a sample in PR)
- [ ] `agents.md` "scheduling_agent" section updated
- [ ] `BUILD_LOG.md` entry added
- [ ] PR description includes the SMS body, PDF screenshot, and the audit_log row showing consent_quote
