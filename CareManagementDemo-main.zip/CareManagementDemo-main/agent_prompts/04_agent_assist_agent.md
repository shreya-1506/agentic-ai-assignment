# Teammate Prompt — Agent 04: `agent_assist_agent`

> Hand this to the teammate (or to their Claude Code). Scaffolding, skills, orchestrator, DB schema, and your stub already exist. You're replacing the stub.

## Context

Multi-agent post-discharge TCM POC. This agent is the **real-time co-pilot** that runs alongside a Case Manager during a **live voice callback** with the member. Unlike the other agents, it doesn't drive a conversation — the CM does. The agent watches a streaming transcript and **surfaces sequential AI prompts** to the CM's UI as the conversation hits expected beats (clinical check-in → adherence → transport → scheduling readiness). It also tracks **sentiment trend** turn-by-turn.

Read `agents.md`, `skills.md`, and `models/schemas.py` before coding.

## Your role

`agent_assist_agent` is **event-driven**, not state-polled. The orchestrator marks the case `CM_CALLBACK_IN_PROGRESS` when the CM picks up the call (signalled via `POST /cases/{id}/callback/start`); your agent then subscribes to a transcript stream and pushes prompts + sentiment to the UI via WebSocket. When the call ends (`POST /cases/{id}/callback/end`), you finalize and exit. State usually doesn't change here — it changes when `scheduling_agent` books the appointment (triggered mid-call by the CM) or when the CM explicitly closes the case.

## Pipeline position

```
OUTREACH_COMPLETE ──▶ CM_CALLBACK_IN_PROGRESS ──▶ [you assist live]
                                                       │
                                                       ▶ APPOINTMENT_BOOKED (via scheduling_agent)
                                                       ▶ ESCALATED  (CM escalates)
                                                       ▶ CLOSED_MEMBER_DECLINED  (member declines on call)
```

- **Input state:** `CM_CALLBACK_IN_PROGRESS`
- **Output state:** usually unchanged by you; scheduling_agent or the CM moves it next
- Your agent does not write `update_case_state` directly except on hard failures (e.g., transcript stream dies → escalate the case with reason)

## The 4 sequential AI prompts (from the POC)

The CM sees these in a right-side panel as the call progresses. Each prompt has a **trigger condition** (what conversation beat fires it) and a **payload** (what data to surface). Fire each prompt **once per call**.

| # | Trigger (LLM-classified intent in transcript) | Prompt payload |
|---|---|---|
| 1 | CM asks how member is breathing / symptom check | Last SpO₂ (93%), Prednisone taper schedule, meds picked up confirmation |
| 2 | CM discusses inhaler / medication adherence | Community resource: Valley Community Health Center → free pulse oximeter referral |
| 3 | CM asks about transport / mobility | Transport gap flagged in outreach session; medical transport covered under plan (BlueCross Premier) |
| 4 | CM offers PCP scheduling | No PCP appt on file; Dr. Garcia available; `scheduling_agent` armed and awaiting verbal consent |

The mapping `trigger intent → prompt content` is in `config/agent_assist_prompts.py` — your agent looks up the prompt template, fills in case-specific data, pushes to UI.

## Sentiment tracking

Each transcript turn (member side only) gets a sentiment score: `very_negative | negative | neutral | positive | very_positive`. Use `skills.sentiment.score_turn(text)` (mocked). Maintain a rolling trend on `case.sentiment_trend` (array of `{ts, label, score_0_100}`). The POC's expected arc for John Martinez: starts Neutral (50%), ends Very Positive (90%).

## Reasoning vs. determinism

- **LLM-driven**: classifying transcript-turn intent ("is this the breathing check-in?"), summarizing what to put in each prompt
- **Deterministic Python**: WebSocket plumbing, one-prompt-per-call dedupe, sentiment-trend storage, the prompt template lookup, the case-state write on failure

## System prompt skeleton

```
You are the agent_assist_agent, a real-time co-pilot for a Case Manager on a live
voice call with a patient. You receive a streaming transcript (CM and member turns,
labeled). Your job is to detect when the conversation hits one of FOUR specific
beats and emit the corresponding prompt for the CM's UI.

The 4 beats:
  beat_1_breathing_check   — CM asks about breathing, symptoms, how the member is feeling physically
  beat_2_adherence         — CM discusses medication adherence, inhalers, taking meds correctly
  beat_3_transport         — CM asks about getting to appointments, transport, mobility
  beat_4_scheduling        — CM offers to schedule a PCP follow-up

For each new transcript turn, return JSON:
{
  "beat_detected": "beat_1_breathing_check" | ... | null,
  "confidence": float,        // 0–1
  "rationale": str            // ≤ 1 sentence
}

Only fire a beat once you are ≥ 0.75 confident. Each beat fires AT MOST ONCE per call.
If you have already fired all 4 beats, return null until end-of-call.
```

A separate (smaller) LLM call summarizes what to surface inside each prompt template — see `config/agent_assist_prompts.py` for the template format.

## Tools you can call

- `skills.transcript.subscribe(call_id)` → async iterator of `{ts, speaker, text}`
- `skills.sentiment.score_turn(text)`
- `skills.ui.push_prompt(case_id, prompt_id, payload)` — WebSocket push to CM's panel
- `skills.ui.push_sentiment(case_id, sentiment_event)`
- `skills.knowledge.search_guidelines(query)` (occasional, if a prompt needs grounding)

## File you're editing

```
agents/agent_assist_agent.py
```

Stub already implements the WebSocket scaffold and pushes a hardcoded prompt for testing.

## Test case (John Martinez)

A scripted transcript fixture lives at `data/samples/john_martinez_callback_transcript.json` — turns alternating between CM Sarah and John, hitting the 4 beats in order. Your unit test feeds the fixture turn-by-turn and asserts:

- All 4 prompts fired, in order, exactly once each
- Sentiment trend ends at `very_positive` (≥ 85)
- `case.agent_assist_summary` populated with `{prompts_fired, sentiment_arc, beats_detected}`
- No state transition unless transcript stream raised an error

## What you must NOT do

- Don't book the appointment yourself — that's `scheduling_agent`, triggered explicitly by the CM mid-call
- Don't change case state unless the transcript stream dies (then escalate with reason)
- Don't fire the same prompt twice in a call
- Don't surface raw member quotes to the UI (PII) — surface synthesized prompt payloads
- Don't block the call if a prompt fails to push — log + continue

## Definition of done

- [ ] `agents/agent_assist_agent.py` implemented end-to-end
- [ ] Stub TODO marker removed
- [ ] Idempotent re-entry (resumes if already mid-call)
- [ ] Unit test against transcript fixture passes (4 prompts, correct order)
- [ ] Sentiment trend visible in `case.sentiment_trend`
- [ ] WebSocket push works against the dev UI harness
- [ ] `agents.md` "agent_assist_agent" section updated
- [ ] `BUILD_LOG.md` entry added
- [ ] PR description shows a screenshot or transcript-by-transcript walk of the 4 prompts firing
