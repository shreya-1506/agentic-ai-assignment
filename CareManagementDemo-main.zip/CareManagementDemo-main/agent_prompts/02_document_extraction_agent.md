# Teammate Prompt — Agent 02: `document_extraction_agent`

> Hand this to the teammate (or to their Claude Code). Scaffolding, skills, orchestrator, DB schema, and a stub of your agent already exist. You're replacing the stub.

## Context

Multi-agent post-discharge TCM POC. This agent is the **primary human gate** in the pipeline: it extracts structured fields from a Hospital Discharge Summary PDF with per-field confidence scores, flags low-confidence fields, and **blocks** the pipeline until a clinician explicitly approves. The same reviewer surface is also where the CM verifies clinical readiness (last SpO₂, PCP follow-up window, med reconciliation status) before authorizing outreach.

Read `agents.md`, `skills.md`, and `models/schemas.py` before coding.

## Your role

`document_extraction_agent` does the **extraction half**. It runs autonomously to extract + score, then sets state to `DOCUMENT_PENDING_REVIEW` and stops. The orchestrator does not re-dispatch it; the clinician acts through the review endpoint (built in Step 10). On approval, state advances to `DOCUMENT_APPROVED` and the orchestrator dispatches the next agent.

## Pipeline position

```
RISK_STRATIFIED  ──▶  [you extract]  ──▶  DOCUMENT_PENDING_REVIEW
                                                  │
                                          (clinician approves
                                            via review endpoint)
                                                  ▼
                                          DOCUMENT_APPROVED
```

- **Input state:** `RISK_STRATIFIED`
- **Output state (success):** `DOCUMENT_PENDING_REVIEW`
- **Output state (failure to retrieve doc):** `ESCALATED` with reason

## What you must do

1. **Retrieve the discharge summary PDF** via `skills.ehr.fetch_discharge_summary(case_id, member_id)` (mocked; returns a PDF path under `data/documents/`).
2. **Parse the PDF** via `skills.documents.parse_pdf(path)` — wraps `unstructured` + Tesseract OCR fallback.
3. **Extract structured fields with confidence**. Use Haiku 4.5 with a prompt that returns JSON with `value` + `confidence` (0.0–1.0) per field. The fields and POC-expected confidence ranges:

   | Field | Expected confidence | Tier |
   |---|---|---|
   | `medical_center` | 96–99% | high |
   | `patient_name` | 96–99% | high |
   | `mrn` | 96–99% | high |
   | `admit_date` | 96–99% | high |
   | `discharge_date` | 96–99% | high |
   | `length_of_stay` | 96–99% | high |
   | `attending_physician` | 96–99% | high |
   | `primary_diagnosis` | 96–99% | high |
   | `hand_off_summary` | 91–95% | medium |
   | `reason_for_hospitalization` | 91–95% | medium |
   | `medication_changes` | 70–80% | **low — must flag** |
   | `last_spo2` | 85–95% | medium |
   | `discharge_disposition` | 90–98% | high |

4. **Flag low-confidence fields** (`confidence < 0.80`) with a red badge in `case.extraction_flags` (JSON array of `{field, confidence, reason}`).
5. **Check STP eligibility** by calling `config.stp_rules.is_stp(case)`. Currently always `False` (per business). Persist `case.is_stp` for visibility.
6. **Set state to `DOCUMENT_PENDING_REVIEW`** via `update_case_state`. Done. Stop.

## Reasoning vs. determinism

The LLM extracts and scores confidence. The threshold check, flag aggregation, state transition, and (eventual) STP routing are deterministic Python. The clinician approval endpoint is **not** part of your file — it lives in `api/routes/review.py` (Step 10). You only emit the data the reviewer UI consumes.

## System prompt skeleton

```
You are the document_extraction_agent for a TCM care-management pipeline. You will
receive parsed text from a Hospital Discharge Summary. Extract each requested field
and return a per-field confidence score (0.0–1.0) reflecting how clearly the field
appears in the source.

Confidence rubric:
  ≥ 0.95 — verbatim, unambiguous, single occurrence
  0.85–0.94 — clear but inferred (e.g., date format normalized)
  0.70–0.84 — present but ambiguous, OCR noise, multiple candidates
  < 0.70 — speculative; do NOT guess, return value=null and explain in `reason`

Return ONLY valid JSON:
{
  "medical_center":       {"value": str|null, "confidence": float, "reason": str},
  "patient_name":         { ... },
  "mrn":                  { ... },
  "admit_date":           { ... iso 8601 },
  "discharge_date":       { ... iso 8601 },
  "length_of_stay":       { ... int days },
  "attending_physician":  { ... },
  "primary_diagnosis":    { ... include ICD-10 if present },
  "hand_off_summary":     { ... ≤ 500 chars },
  "reason_for_hospitalization": { ... ≤ 500 chars },
  "medication_changes":   { "value": [{"name": str, "dose": str, "instructions": str}], ... },
  "last_spo2":            { ... percent on room air if specified },
  "discharge_disposition":{ ... }
}

Do NOT hallucinate values. Do NOT include prose outside the JSON.
```

## Tools you can call

- `skills.ehr.fetch_discharge_summary`
- `skills.documents.parse_pdf`
- `config.stp_rules.is_stp`

## File you're editing

```
agents/document_extraction_agent.py
```

The stub already implements signature, reads the case, writes dummy fields, and sets state. Keep the signature.

## Test case (John Martinez)

Discharge summary lives at `data/documents/john_martinez_discharge_summary.pdf` (seeded).

Expected extraction (from POC):
- High-confidence fields: medical_center="St. Mary's Medical Center", primary_diagnosis="J44.1 COPD Exacerbation", admit/discharge dates, LOS, etc.
- `medication_changes` field is the one to **flag low** — value should include Prednisone taper, Albuterol PRN, Tiotropium 18mcg, Azithromycin
- `last_spo2` = 93% (room air, Day 3)
- `extraction_flags` array contains at least one entry for `medication_changes`
- State transitions to `DOCUMENT_PENDING_REVIEW`

Unit test: load the fixture PDF, run the agent against a test DB, assert that (a) all 13 fields are extracted, (b) `medication_changes` is flagged, (c) state is `DOCUMENT_PENDING_REVIEW`.

## What you must NOT do

- Don't approve the document yourself — that's the clinician's job via the review endpoint
- Don't transition past `DOCUMENT_PENDING_REVIEW`
- Don't retry indefinitely on PDF parse failure — after 2 attempts, escalate
- Don't log PII in cleartext — use `redact_pii`
- Don't bypass `update_case_state`

## Definition of done

- [ ] `agents/document_extraction_agent.py` implemented end-to-end
- [ ] Stub TODO marker removed
- [ ] Idempotent re-entry
- [ ] Unit test against John Martinez PDF passes
- [ ] `extraction_flags` correctly identifies low-confidence fields
- [ ] `agents.md` "document_extraction_agent" section updated
- [ ] `BUILD_LOG.md` entry added
- [ ] PR description shows a sample reviewer-queue payload (JSON) the UI would render
