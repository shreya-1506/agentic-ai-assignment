# Teammate Prompt — Agent 03: `outreach_agent`

> Hand this to the teammate (or to their Claude Code). Scaffolding, skills, orchestrator, DB schema, and your stub already exist. You're replacing the stub.

## Context

Multi-agent post-discharge TCM POC. This agent is the **TCM Care Assistant** — it runs an **async messaging conversation** with the member (NOT a voice call; that's Agent 04) to verify identity, do a light clinical check-in, pitch the Care Management Program (CMP), and capture survey data. It surfaces SDOH flags that downstream agents act on.

Read `agents.md`, `skills.md`, and `models/schemas.py` before coding.

## Your role

`outreach_agent` orchestrates the conversation turn by turn. Member responses arrive via the messaging channel webhook (mocked by `skills.messaging`). The agent decides what to say next given conversation state + member context. It uses **RAG over `knowledge/tcm_guidelines/`** to ground its clinical check-in language and CMP pitch in plan-specific guidance.

## Pipeline position

```
DOCUMENT_APPROVED  ──▶  OUTREACH_SCHEDULED  ──▶  [you]  ──▶  OUTREACH_COMPLETE
                                                       │
                                                       ▶  CLOSED_NO_CONTACT  (3 attempts, no reply)
                                                       ▶  CLOSED_MEMBER_DECLINED  (member declines CMP)
```

- **Input state:** `OUTREACH_SCHEDULED`
- **Output state (success):** `OUTREACH_COMPLETE`
- **Output state (no contact):** `CLOSED_NO_CONTACT`
- **Output state (declined):** `CLOSED_MEMBER_DECLINED`

## The 6-step conversation flow (from the POC)

The session ID format is `MS-NNNNNNNN`. The conversation has a fixed structure; the agent uses the LLM to phrase each step naturally and handle off-script member replies.

1. **Identity verification** — confirm name + DOB. Hard requirement; abandon if mismatch.
2. **Introduction** — explain who's calling, mention recent discharge, set expectations.
3. **Clinical check-in** — symptom check (esp. dyspnea for COPD), medication pickup confirmation, PCP follow-up status.
4. **CMP enrollment pitch** — RAG-grounded explanation of the Care Management Program: dedicated nurse + CM, home support.
5. **Outcome & closing** — capture verbal-equivalent consent (since this is messaging, treat explicit "yes" as enrollment), schedule CM callback, give emergency guidance (911 / nearest ER for worsening symptoms).
6. **Survey form auto-population** — write structured fields to `case.outreach_survey`.

### Survey form fields to populate

```python
{
  "language": str,                # e.g., "English"
  "communication_assistance": str,# e.g., "None" | "Interpreter" | "Large print"
  "symptoms": str,                # ≤ 200 chars, member's own words summarized
  "medication_pickup": bool,
  "follow_up_appt_scheduled": bool,  # ⚠ if False → emit SDOH flag "no_pcp_appt"
  "cmp_enrollment": bool,
  "contact_phone": str,           # normalized E.164
  "callback_preference": str,     # "morning" | "afternoon" | "evening"
}
```

### SDOH flags to emit

Append to `case.sdoh_flags` (JSON array):
- `no_pcp_appt` — if `follow_up_appt_scheduled` is False
- `transport_gap` — if member mentions transport difficulty
- `med_affordability_gap` — if member mentions cost/copay concerns
- `language_barrier` — if `language != "English"` AND `communication_assistance == "None"`
- `lives_alone` — if member mentions no caregiver support

Downstream agents (agent_assist, scheduling, compliance) read these flags.

## Reasoning vs. determinism

The LLM drives conversation phrasing, off-script handling, and survey extraction from natural-language replies. The conversation step machine, retry/no-contact logic (3 messaging attempts with 4-hour gaps), state transitions, and SDOH flag detection are deterministic Python. RAG retrieval is deterministic.

## System prompt skeleton

```
You are the TCM Care Assistant, an outreach agent for a health plan's post-discharge
care management program. You are conducting an async messaging conversation with a
member who was recently discharged from the hospital.

Your goals, in order:
  1. Verify the member's identity (name + DOB)
  2. Briefly check in on how they're feeling (symptom-aware, given their diagnosis)
  3. Confirm they picked up their medications
  4. Confirm or detect that a PCP follow-up is scheduled
  5. Pitch the Care Management Program (CMP) using the guideline excerpts provided
  6. Capture their decision and arrange a callback with their Case Manager

Conversation rules:
  - Warm, plain language. No clinical jargon.
  - Short messages (≤ 2 sentences). This is text, not a voice call.
  - Never give medical advice beyond "if symptoms worsen, call 911 or go to ER."
  - If the member asks something outside scope, gently redirect: "Your CM Sarah can
    answer that on your callback — would you like me to schedule it?"
  - Track conversation state. You will receive {state, history, member_context,
    guideline_excerpts}. Return ONLY the next message you would send to the member,
    plus a structured update for the agent's state machine.

Return JSON:
{
  "next_message": str,            // what to send to the member
  "step_complete": bool,          // did we just finish the current step?
  "next_step": str|null,          // which step to move to next
  "survey_updates": dict,         // partial survey fields you just learned
  "sdoh_signals": [str],          // any flags detected in this turn
  "should_terminate": bool,       // are we done?
  "termination_reason": str|null  // "completed" | "declined" | "identity_mismatch"
}
```

## Tools you can call

- `skills.messaging.open_session(case_id, member_phone)` → returns `session_id`
- `skills.messaging.send_message(session_id, text)`
- `skills.messaging.poll_for_reply(session_id, timeout_seconds)` → returns reply or None
- `skills.knowledge.search_guidelines(query, k=5)` — RAG over `knowledge/tcm_guidelines/`
- `skills.member.get_profile(member_id)` (for context)

## File you're editing

```
agents/outreach_agent.py
```

Stub already implements signature and dummy data writes.

## Test case (John Martinez)

Member context loaded from earlier stages:
- COPD exacerbation, discharged Oct 5
- 4 medications (Prednisone taper, Albuterol PRN, Tiotropium, Azithromycin)
- No PCP appointment yet

Expected conversation outcome (from POC):

```
Survey:
  language: "English"
  communication_assistance: "None"
  symptoms: "Mild dyspnea, morning SOB"
  medication_pickup: true       # picked up at CVS yesterday
  follow_up_appt_scheduled: false   ⚠ → emit no_pcp_appt SDOH flag
  cmp_enrollment: true
  contact_phone: "+15558472910"
  callback_preference: <captured>

SDOH flags: ["no_pcp_appt"]
State: OUTREACH_COMPLETE
```

A scripted member-reply fixture lives at `data/samples/john_martinez_messaging_replies.json` — your unit test loads it, runs the agent with `skills.messaging` patched to return canned replies, and asserts the survey and SDOH flags match.

## What you must NOT do

- Don't book the PCP appointment yourself — that's `scheduling_agent`'s job on the live call
- Don't make medical recommendations beyond the 911/ER fallback line
- Don't proceed past identity verification on a name/DOB mismatch — terminate with `identity_mismatch`
- Don't loop forever — cap at 30 turns total
- Don't log PII in cleartext
- Don't bypass `update_case_state`

## Definition of done

- [ ] `agents/outreach_agent.py` implemented end-to-end
- [ ] Stub TODO marker removed
- [ ] Idempotent re-entry (resumes mid-conversation if state has progressed)
- [ ] Unit test against the scripted replies fixture passes
- [ ] SDOH flag detection works (test with at least 3 flag types)
- [ ] RAG-grounded CMP pitch citations recorded in `case.outreach_rag_citations`
- [ ] `agents.md` "outreach_agent" section updated
- [ ] `BUILD_LOG.md` entry added
- [ ] PR description shows a full sample transcript + survey JSON
