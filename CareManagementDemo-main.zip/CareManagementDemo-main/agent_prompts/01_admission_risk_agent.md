# Teammate Prompt — Agent 01: `admission_risk_agent`

> Hand this to the teammate (or to their Claude Code). The scaffolding, skills, orchestrator, DB schema, and a stub of your file already exist on `main`. You're replacing the stub with the real implementation.

## Context

We're building a multi-agent post-discharge Transitional Care Management (TCM) POC. A hospital fires an HL7/FHIR discharge event; the pipeline routes the case through 7 agents to land the member in a Care Management Program with a booked PCP follow-up. Each agent reads/writes a `cases` row in Postgres — agents never call each other directly. An orchestration agent polls and dispatches by state.

Read `agents.md`, `skills.md`, and `models/schemas.py` before coding. These are the contracts.

## Your role

`admission_risk_agent` is the first work-agent in the pipeline. It runs **fully autonomously** — no human gate. It turns a raw discharge event into a stratified, prioritized case with a CRM record and workflow tasks ready for the next stage.

## Pipeline position

```
DISCHARGE_RECEIVED   ──▶  [you]  ──▶   RISK_STRATIFIED
```

- **Input state:** `DISCHARGE_RECEIVED`
- **Output state (success):** `RISK_STRATIFIED`
- **Output state (failure):** `ESCALATED` with reason in `case.escalation_reason`

## What the orchestrator hands you

A `case_id`. The case row already has the parsed HL7/FHIR payload in `case.discharge_event` (JSON). Fields available:

```
member_id, admit_date, discharge_date, primary_dx_icd10,
attending_physician, pcp_name, pcp_id, medical_center
```

## What you must do (6 steps, all autonomous)

1. **Create CRM case record** via `skills.crm.create_case(case_id, member_id, ...)`. Store returned `crm_case_number` (format `CASE-NNNNNNNN`) on `case.crm_case_number`.
2. **Fetch member profile** via `skills.member.get_profile(member_id)`. Persist key fields on the case row.
3. **Pull claims + care gaps + prior engagement** via `skills.claims.get_member_history(member_id)`. Persist a summary blob on `case.claims_summary`.
4. **Compute Impactability score (/50)** — sum 5 subcomponents, each 0–10:
   - `clinical_severity` (LOS, ICU days, dx severity)
   - `utilization` (ED visits + admits last 12mo)
   - `med_complexity` (count + high-risk meds)
   - `care_gaps` (open gaps from claims)
   - `prior_engagement` (prior TCM/CMP touches — inverse: higher score = less prior engagement)
5. **Compute Intervenability score (/40)** — sum 4 subcomponents, each 0–10:
   - `sdoh` (transport, housing, food, language flags from member profile)
   - `insurance_pharmacy` (plan tier, formulary fit, copay sensitivity)
   - `cognitive_behavioral` (cognitive flags, MH dx, adherence history)
   - `contactability` (valid phone, email, recent contact success)
   - ⚠ POC labels this `/50` but lists 4 components. Treat as `/40` and log a `data_quality` note.
6. **Composite Priority** = Impactability + Intervenability. Tier: `< 50` Low, `50–79` Medium, `≥ 80` High. Write `case.impactability`, `case.intervenability`, `case.composite_priority`, `case.priority_tier`.

Then:

- Create 4 CRM workflow tasks via `skills.crm.create_task(...)`:
  - "Verify member contactability"
  - "Schedule discharge summary review"
  - "Prepare TCM outreach materials"
  - "Confirm PCP follow-up window (7–10 days)"
- Call `update_case_state(case_id, RISK_STRATIFIED, agent="admission_risk_agent")`.

## Reasoning vs. determinism

The 5 + 4 subcomponent scores are computed by **LLM reasoning** (Haiku 4.5) over the member profile + claims summary, using your system prompt to anchor the 0–10 rubric per dimension. The composite math, tiering, state transition, and CRM/task side-effects are **deterministic Python** — never let the LLM do arithmetic or trigger writes.

## System prompt skeleton

```
You are the admission_risk_agent for a TCM care-management pipeline. Given a member
profile, claims history, care gaps, and a discharge event, you score the member on
9 dimensions (5 Impactability + 4 Intervenability), each from 0 to 10.

Anchors per dimension:
  clinical_severity:
    0 = elective admission, no comorbidities, LOS ≤ 1 day
    5 = moderate acuity, 1–2 comorbidities, LOS 3–5 days
    10 = ICU stay, multiple severe comorbidities, LOS > 7 days
  utilization:
    0 = no ED/admits last 12mo
    5 = 1–2 ED visits OR 1 prior admit
    10 = ≥ 3 ED visits or ≥ 2 admits last 12mo
  [...continue for med_complexity, care_gaps, prior_engagement,
       sdoh, insurance_pharmacy, cognitive_behavioral, contactability]

Return ONLY valid JSON matching this schema:
  {
    "impactability": {
      "clinical_severity": int, "utilization": int, "med_complexity": int,
      "care_gaps": int, "prior_engagement": int,
      "rationale": str  // ≤ 2 sentences per dimension justifying the score
    },
    "intervenability": { ... same shape with the 4 dimensions ... }
  }

Do NOT compute totals. Do NOT make tool calls. Do NOT include prose outside the JSON.
```

## Tools you can call (from `/skills/`)

- `skills.crm.create_case`, `skills.crm.create_task`
- `skills.member.get_profile`
- `skills.claims.get_member_history`
- All mocked — they return realistic shapes. Don't add new skills; if you need something, propose it in `skills.md` first.

## File you're editing

```
agents/admission_risk_agent.py
```

The stub already imports the Strands SDK, defines `run(case_id: str) -> None`, reads the case, and writes dummy scores. Keep the function signature. Remove the `# TODO(<teammate>)` line when done.

## Test case from the POC (John Martinez)

```
member_id: MBR-00847291
primary_dx_icd10: J44.1 (COPD exacerbation)
discharge_date: 2026-10-05
medical_center: St. Mary's Medical Center
attending_physician: (per discharge event)
pcp_name: Dr. Luis Garcia
plan: BlueCross Premier
```

Expected output (from the POC; treat as ground truth for your unit test):

- Impactability = 42/50 (Clinical Severity 9, Utilization 8, Med Complexity 9, Care Gaps 8, Prior Engagement 8)
- Intervenability = 31/40 (SDOH 7, Insurance/Pharmacy 8, Cognitive/Behavioral 8, Contactability 8)
- Composite = 73 → Medium
- CRM case number assigned
- 4 workflow tasks created
- State transitions to `RISK_STRATIFIED`

A seeded fixture for John Martinez lives at `data/samples/john_martinez_discharge.json`. Your unit test should load it, run the agent against a test DB, and assert the scores land within ±1 of the POC values (LLM nondeterminism).

## What you must NOT do

- Don't call other agents.
- Don't write to other agents' state fields.
- Don't add cross-skill imports inside `/skills/`.
- Don't make the LLM compute totals or trigger side-effects — only score.
- Don't log PII (member name, DOB, MRN) in cleartext — use the `redact_pii` helper from `skills/_common.py`.
- Don't bypass `update_case_state`; it enforces `ALLOWED_TRANSITIONS` and writes the audit log.

## Definition of done

- [ ] `agents/admission_risk_agent.py` implemented end-to-end
- [ ] Stub TODO marker removed
- [ ] Idempotent re-entry: if state is already `RISK_STRATIFIED`, the agent logs and exits
- [ ] Unit test against `john_martinez_discharge.json` passes (scores within ±1)
- [ ] `agents.md` "admission_risk_agent" section updated to match your implementation
- [ ] `BUILD_LOG.md` gets a "Step 6 (real impl)" entry
- [ ] PR description shows a sample `audit_log` row demonstrating the transition
