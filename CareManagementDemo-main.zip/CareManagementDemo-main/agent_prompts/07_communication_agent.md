# Teammate Prompt — Agent 07: `communication_agent`

> Hand this to the teammate (or to their Claude Code). Scaffolding, skills, orchestrator, DB schema, and your stub already exist. You're replacing the stub.

## Context

Multi-agent post-discharge TCM POC. This agent is the **notifications hub**. As cases move through the pipeline, milestone events fire (case created, document approved, member enrolled, appointment booked, case closed, escalated). This agent listens for those events, renders the right template, and dispatches via the right channel (SMS / email / webhook).

It's **event-driven**, not state-polled. The orchestrator emits events on every state transition; your agent consumes from a queue and dispatches. SMTP and SMS are stubbed by default; webhook is a real POST in dev.

Read `agents.md`, `skills.md`, and `models/schemas.py` before coding.

## Your role

`communication_agent` runs as a **lifespan-managed daemon** inside the same uvicorn process as the API + orchestrator. It polls `case_events` (a table populated by `update_case_state`) every 5 seconds, picks up unprocessed events, renders templates, dispatches, marks the event processed.

## How it plugs in

```
update_case_state(case_id, new_state, agent=...)
   │
   ├──▶ writes audit_log row
   └──▶ writes case_event row (case_id, event_type, ts, processed=false)
              │
              ▼
       [communication_agent daemon polls every 5s]
              │
              ├──▶ resolves event → template + channel + recipient
              ├──▶ renders template (Jinja2)
              ├──▶ dispatches (SMS / email / webhook)
              └──▶ marks event processed=true with delivery_status
```

This agent does **not** change case state.

## Events and notifications matrix

| Event (state transition) | Channel | Recipient | Template |
|---|---|---|---|
| `DISCHARGE_RECEIVED → RISK_STRATIFIED` | email | CM queue | `cm_new_case.j2` |
| `RISK_STRATIFIED → DOCUMENT_PENDING_REVIEW` | email | clinician queue | `clinician_review_pending.j2` |
| `DOCUMENT_PENDING_REVIEW → DOCUMENT_APPROVED` | webhook | CRM | `crm_case_ready.j2` (JSON) |
| `OUTREACH_SCHEDULED → OUTREACH_COMPLETE` | email | CM | `cm_outreach_summary.j2` |
| `* → APPOINTMENT_BOOKED` | sms | member | `member_appt_confirmation.j2` |
| `* → APPOINTMENT_BOOKED` | email | PCP office | `pcp_appt_notification.j2` |
| `* → CARE_GOALS_MET` | email | CM | `cm_case_closed.j2` |
| `* → CARE_GOALS_MET` | webhook | CRM | `crm_case_closed.j2` (JSON) |
| `* → ESCALATED` | email | CM + supervisor | `cm_escalation.j2` |
| `* → CLOSED_NO_CONTACT` | email | CM | `cm_no_contact.j2` |
| `* → CLOSED_MEMBER_DECLINED` | email | CM | `cm_member_declined.j2` |

Templates live in `templates/communication/`. **Member-facing SMS may be sent by `scheduling_agent` first** (the booking confirmation); this agent sends a **secondary** SMS only if scheduling_agent didn't (idempotency via `case_events.delivery_status`).

## Reasoning vs. determinism

**Mostly deterministic.** The event → template mapping is a config dict. Template rendering is Jinja2. Dispatch is mocked HTTP/SMTP.

The one place LLM **may** be used (optional, behind a feature flag): rewriting a generated email subject line or the body of `cm_case_closed.j2` to sound more natural per case context. Default behavior: use the deterministic template verbatim. Add the LLM path only if you have time — and gate it behind `ENABLE_LLM_NOTIFICATIONS=false` by default.

## Channels (all mocked for POC)

- **SMS** → `skills.sms.send(phone, body)` — mocked; logs to `data/outbox/sms.log`
- **Email** → `skills.email.send(to, subject, body)` — mocked when `SMTP_OFF=true` (default); logs to `data/outbox/email.log`
- **Webhook** → `skills.webhook.post(url, payload)` — real httpx POST in dev; defaults to `http://localhost:9999/sink` for testing

## Tools you can call

- `skills.sms.send`, `skills.email.send`, `skills.webhook.post`
- `skills.templates.render(template_name, context)` — Jinja2 wrapper
- `skills.events.pop_unprocessed(limit)` — fetches up to N unprocessed case_event rows
- `skills.events.mark_processed(event_id, delivery_status)`

## File you're editing

```
agents/communication_agent.py
templates/communication/*.j2        (12 templates total, listed above)
```

Stub already implements the daemon polling loop and renders a hardcoded email for testing. The 12 templates start as placeholders — you flesh them out.

## Test case (John Martinez)

Run the full pipeline against the John Martinez fixture end-to-end. The expected event sequence (from POC):

```
1. DISCHARGE_RECEIVED → RISK_STRATIFIED               → email to CM queue
2. RISK_STRATIFIED → DOCUMENT_PENDING_REVIEW          → email to clinician queue
3. DOCUMENT_PENDING_REVIEW → DOCUMENT_APPROVED        → webhook to CRM
4. DOCUMENT_APPROVED → OUTREACH_SCHEDULED             → (no notification — internal hop)
5. OUTREACH_SCHEDULED → OUTREACH_COMPLETE             → email to CM
6. OUTREACH_COMPLETE → CM_CALLBACK_IN_PROGRESS        → (no notification)
7. CM_CALLBACK_IN_PROGRESS → APPOINTMENT_BOOKED       → SMS to member (skip — already sent by scheduling_agent),
                                                        email to PCP office
8. APPOINTMENT_BOOKED → CARE_GOALS_MET                → email to CM + webhook to CRM
```

Expected total notifications dispatched: **7** (1 SMS skipped due to idempotency).

Unit tests:
- Each template renders without error against a sample context
- Event → template mapping resolves correctly for all 11 listed transitions
- Idempotency: re-running the daemon over already-processed events sends nothing
- A "no notification" transition (e.g., `DOCUMENT_APPROVED → OUTREACH_SCHEDULED`) is correctly skipped

## What you must NOT do

- Don't change case state — ever
- Don't dispatch on already-processed events (idempotency via `delivery_status`)
- Don't send SMS to a number that already received the booking confirmation (check `case_events.delivery_status` for prior SMS sends on this case)
- Don't block the daemon on a single failed dispatch — log, mark `delivery_status=failed`, move on
- Don't include PII in webhook payloads beyond what's already in the CRM payload contract (member_id is OK; member_name is not)
- Don't log raw email/SMS bodies — log subjects + recipient + delivery_status only

## Definition of done

- [ ] `agents/communication_agent.py` daemon implemented
- [ ] All 12 templates filled in with realistic copy
- [ ] Stub TODO marker removed
- [ ] Daemon registered in `api/main.py` lifespan
- [ ] Unit tests pass (per-template + per-event-mapping + idempotency)
- [ ] End-to-end test on John Martinez fixture produces the expected 7 notifications in the outbox logs
- [ ] `agents.md` "communication_agent" section updated with the event→template matrix
- [ ] `BUILD_LOG.md` entry added
- [ ] PR description shows the contents of `data/outbox/{sms.log, email.log}` after the E2E run
