# Teammate Prompt — Agent 06: `compliance_agent`

> Hand this to the teammate (or to their Claude Code). Scaffolding, skills, orchestrator, DB schema, and your stub already exist. You're replacing the stub.

## Context

Multi-agent post-discharge TCM POC. This agent runs **post-closure**: after the appointment is booked and care goals are met, it audits the case end-to-end against a fixed set of deterministic compliance checks. Each check emits a severity (`pass | warn | fail`) and a check code. The final audit blob lands on `case.compliance_audit` and is what the plan's QA team would review for CMS TCM billing eligibility (CPT 99495 / 99496) and internal quality scoring.

Read `agents.md`, `skills.md`, and `models/schemas.py` before coding.

## Your role

`compliance_agent` is **state-driven**: it fires when a case enters `APPOINTMENT_BOOKED` (or any terminal state — failed cases get audited too). It runs **9 deterministic checks**, aggregates results, sets state to `CARE_GOALS_MET` if all hard checks pass, or `ESCALATED` if a hard check fails.

## Pipeline position

```
APPOINTMENT_BOOKED  ──▶  [you audit]  ──▶  CARE_GOALS_MET   (all hard checks pass)
                                       ▶  ESCALATED         (any hard check fails)
                                       ▶  CARE_GOALS_MET    (warnings only)

Also runs on:
  CLOSED_NO_CONTACT, CLOSED_MEMBER_DECLINED  (audit-only, no state change)
```

- **Input state:** `APPOINTMENT_BOOKED` (primary), `CLOSED_NO_CONTACT`, `CLOSED_MEMBER_DECLINED`
- **Output state (all pass):** `CARE_GOALS_MET`
- **Output state (hard fail):** `ESCALATED` with `escalation_reason`

## The 9 deterministic checks

Each check is a pure function in `agents/compliance_checks.py` taking the case row and returning `{code, severity, evidence, message}`. **No LLM involvement** — these are SQL/JSON inspections of the case state already built up by prior agents.

| # | Check code | Hardness | What it inspects |
|---|---|---|---|
| 1 | `tcm.med_reconciliation_complete` | hard | `case.extraction.medication_changes` is non-empty AND `case.outreach_survey.medication_pickup == True` |
| 2 | `tcm.pcp_followup_booked` | hard | `case.appointment_id` is set AND `case.state == APPOINTMENT_BOOKED` (or terminal) |
| 3 | `tcm.pcp_followup_within_7_10_days` | warn | appointment slot is between discharge_date+7 and discharge_date+10 (warn if outside) |
| 4 | `tcm.adherence_trending_positive` | warn | `case.sentiment_trend` ends at `positive` or `very_positive` (warn otherwise) |
| 5 | `tcm.cmp_enrollment_confirmed` | warn | `case.outreach_survey.cmp_enrollment == True` (warn if False — member opted out is OK) |
| 6 | `tcm.transport_referral_created` | warn | if `transport_gap` in `case.sdoh_flags`, then a `referral` of type `transport` exists |
| 7 | `tcm.community_resource_shared` | warn | at least one `referral` of type `device` or `service` exists on the case |
| 8 | `tcm.verbal_consent_captured_in_transcript` | **hard** | `case.scheduling_consent.consent_quote` is non-null AND `case.scheduling_consent.confidence >= 0.85` |
| 9 | `tcm.cms_99495_99496_billable` | warn | composite of: discharge documented + 2-business-day contact + face-to-face visit booked in window — derive from the prior checks |

**Hard fail** → state goes to `ESCALATED` with the failing check code as the reason.
**Warn fail(s) only** → state goes to `CARE_GOALS_MET` with the warnings logged for QA review.

## Side effects

- Write `case.compliance_audit` as a JSON array of all 9 check results
- Write `case.compliance_severity_max` = `max(severity)` across all checks (`pass | warn | fail`)
- Append an `audit_log` entry summarizing the audit
- If hard fail, also call `skills.crm.create_task(case_id, title=f"Compliance escalation: {failing_code}", priority="high")`

## Reasoning vs. determinism

**Entirely deterministic.** Zero LLM calls. This agent's value is auditability — every result must be reproducible from the case row alone.

## Tools you can call

- `skills.crm.create_task` (for escalation task)
- No others. All check logic reads from `case.*` directly.

## File you're editing

```
agents/compliance_agent.py           (the agent orchestration)
agents/compliance_checks.py          (the 9 check functions — split for testability)
```

Stub already implements signature and writes dummy audit results.

## Test case (John Martinez)

Expected from POC (all checks pass):

```json
{
  "compliance_audit": [
    {"code": "tcm.med_reconciliation_complete",       "severity": "pass", ...},
    {"code": "tcm.pcp_followup_booked",               "severity": "pass", ...},
    {"code": "tcm.pcp_followup_within_7_10_days",     "severity": "pass",
       "evidence": "Discharge 2026-10-05, appt 2026-10-10 (+5 days)"},
    {"code": "tcm.adherence_trending_positive",       "severity": "pass",
       "evidence": "Final sentiment: very_positive (90)"},
    {"code": "tcm.cmp_enrollment_confirmed",          "severity": "pass"},
    {"code": "tcm.transport_referral_created",        "severity": "pass",
       "evidence": "Plan transport benefit confirmed; no separate referral needed"},
    {"code": "tcm.community_resource_shared",         "severity": "pass",
       "evidence": "Pulse oximeter referral to Valley Community Health Center"},
    {"code": "tcm.verbal_consent_captured_in_transcript", "severity": "pass",
       "evidence": "Quote: 'Yes, please.' at 2026-10-05T14:32:14Z (conf 0.94)"},
    {"code": "tcm.cms_99495_99496_billable",          "severity": "pass"}
  ],
  "compliance_severity_max": "pass",
  "state": "CARE_GOALS_MET"
}
```

Unit tests:
- **Happy path**: load a fully-built John Martinez case fixture → assert all 9 pass and state → `CARE_GOALS_MET`
- **Hard-fail (consent)**: mutate fixture to remove `scheduling_consent` → assert state → `ESCALATED`, escalation_reason mentions `tcm.verbal_consent_captured_in_transcript`
- **Warn-only**: mutate fixture so appointment is on day 12 → assert state still `CARE_GOALS_MET` but `compliance_severity_max == "warn"`

## What you must NOT do

- Don't call any LLM (this agent must be 100% deterministic)
- Don't modify case data beyond `compliance_audit`, `compliance_severity_max`, and state
- Don't read external systems (no fresh fetches — audit against the case row as-is)
- Don't catch and swallow check exceptions — let them surface so QA can investigate
- Don't bypass `update_case_state`

## Definition of done

- [ ] `agents/compliance_agent.py` + `agents/compliance_checks.py` implemented
- [ ] All 9 check functions individually unit-tested (one test per check, positive + negative)
- [ ] Integration test against John Martinez fixture passes
- [ ] Hard-fail and warn-only tests pass
- [ ] Stub TODO marker removed
- [ ] `agents.md` "compliance_agent" section updated (list the 9 check codes)
- [ ] `BUILD_LOG.md` entry added
- [ ] PR description includes the full audit JSON for the happy path
