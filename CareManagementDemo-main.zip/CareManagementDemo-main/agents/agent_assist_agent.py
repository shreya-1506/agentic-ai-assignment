"""Agent 04 — agent_assist_agent (STUB).

# TODO(teammate): implement per agent_prompts/04_agent_assist_agent.md
#
# This stub is a *foreground* agent — the orchestrator does NOT dispatch it.
# Instead, the API endpoint POST /cases/{id}/call/start transitions the case
# to CM_CALLBACK_IN_PROGRESS, mints a call_id, and spawns this run() as an
# asyncio task on the FastAPI event loop. The CM polls GET /cases/{id}/call
# while it runs.
#
# What the stub does (matches poc.md Stage 5):
#   - Streams the canned 12-turn John Martinez transcript via
#     skills.transcript.subscribe (one turn every 50ms).
#   - For each member turn: skills.sentiment.score_turn → appends to
#     sentiment_trend. (Score arc: ~50 at open → ~85 at "Yes, please.")
#   - For each CM turn: checks against 4 trigger keywords and fires the
#     matching prompt via skills.ui.push_prompt + records to prompts_fired.
#   - Detects verbal consent on "yes, please." → sets consent_captured=True
#     and stores the excerpt.
#   - Persists the CallSession progressively (every N turns) so the GET
#     endpoint can show real-time progress.
#   - Marks status=complete + sets ended_at when the stream finishes.
#   - **Does NOT transition state.** scheduling_agent (Step 12) — triggered
#     mid-call by the CM when consent is captured — moves the case to
#     APPOINTMENT_BOOKED.
#
# Notes for the teammate:
#   - Real impl drives prompt selection with an LLM keyed on conversation
#     beats + member context (last SpO2, meds, SDOH flags from outreach).
#   - Real-time sentiment + prompts push over WebSocket; the POC uses an
#     in-memory ring buffer + log file (skills.ui).
#   - 30-turn cap should be honored to prevent runaway.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from db.pool import connection
from db.state_io import get_call_session, update_call_session
from models.schemas import CallSession, CallStatus, CallTurn, PromptFired
from skills import sentiment as sentiment_skill
from skills import transcript as transcript_skill
from skills import ui as ui_skill
from skills._common import get_logger

AGENT_NAME = "agent_assist_agent"


@dataclass(frozen=True)
class _PromptDef:
    prompt_idx: int
    prompt_id: str
    trigger_keyword: str  # lowercase substring match against CM turn text
    content: str


# The 4 sequential POC prompts, keyed to conversation beats from poc.md.
_PROMPTS: tuple[_PromptDef, ...] = (
    _PromptDef(
        prompt_idx=1,
        prompt_id="p1_breathing",
        trigger_keyword="how have you been",
        content=(
            "Member's last in-hospital SpO2 was 93% on room air. On day 7 of "
            "Prednisone taper. All discharge meds (Prednisone, Albuterol, "
            "Tiotropium, Azithromycin) picked up at CVS yesterday."
        ),
    ),
    _PromptDef(
        prompt_idx=2,
        prompt_id="p2_oximeter",
        trigger_keyword="inhaler",
        content=(
            "Valley Community Health Center runs a free pulse oximeter program "
            "for COPD members in 94101. Member has no home device on file. "
            "Offer the referral."
        ),
    ),
    _PromptDef(
        prompt_idx=3,
        prompt_id="p3_transport",
        trigger_keyword="transportation",
        content=(
            "Outreach flagged 'no_pcp_appt' SDOH risk and member mentions "
            "intermittent ride availability. Plan covers non-emergency medical "
            "transport — eligible for upcoming PCP follow-ups."
        ),
    ),
    _PromptDef(
        prompt_idx=4,
        prompt_id="p4_schedule",
        trigger_keyword="next week",
        content=(
            "No PCP follow-up scheduled. Dr. Garcia has slots Oct 8 / 9 / 10 "
            "(within the 7–10 day TCM follow-up window). scheduling_agent is "
            "armed — verbal consent in transcript will trigger the booking."
        ),
    ),
)


def _match_prompt(cm_text: str, remaining: list[_PromptDef]) -> _PromptDef | None:
    lower = cm_text.lower()
    for p in remaining:
        if p.trigger_keyword in lower:
            return p
    return None


async def _persist(call_session: CallSession) -> None:
    async with connection() as conn:
        async with conn.transaction():
            await update_call_session(conn, call_session)


async def run(case_id: str, *, call_id: str, cm_id: str) -> None:
    """Stream the canned transcript, score sentiment, fire prompts, capture consent.

    Called by the POST /cases/{id}/call/start route as a background asyncio task.
    Does not transition case state — scheduling_agent owns the next transition.
    """
    log = get_logger(case_id, agent=AGENT_NAME, call_id=call_id, cm_id=cm_id)

    async with connection() as conn:
        session = await get_call_session(conn, call_id)
    if session is None:
        # Route should have inserted the session before spawning us; if not, abort.
        log.error("call_session_missing", call_id=call_id)
        return

    transcript: list[CallTurn] = []
    sentiment_trend: list[dict] = []
    prompts_fired: list[PromptFired] = []
    remaining_prompts = list(_PROMPTS)
    consent_captured = False
    consent_excerpt: str | None = None

    turn_count = 0
    async for turn in transcript_skill.subscribe(case_id, call_id, interval_s=0.05):
        turn_count += 1
        if turn_count > 30:  # safety cap
            log.warning("transcript_30_turn_cap_hit")
            break

        # Score sentiment for member turns only.
        if turn.speaker == "member":
            sc = sentiment_skill.score_turn(case_id, turn.text)
            sentiment_trend.append(
                {
                    "ts": turn.timestamp.isoformat(),
                    "speaker": "member",
                    "score_0_100": sc["score_0_100"],
                    "label": sc["label"],
                }
            )
            # turn.sentiment is on the -1..1 scale; map from 0..100.
            turn = turn.model_copy(update={"sentiment": (sc["score_0_100"] / 50.0) - 1.0})

            if not consent_captured and "yes, please" in turn.text.lower():
                consent_captured = True
                consent_excerpt = turn.text
                log.info("consent_captured", excerpt=consent_excerpt)

        # Fire a prompt if this CM turn triggers one (and that prompt hasn't fired).
        if turn.speaker == "cm":
            match = _match_prompt(turn.text, remaining_prompts)
            if match is not None:
                remaining_prompts.remove(match)
                fired = PromptFired(
                    prompt_idx=match.prompt_idx,
                    fired_at=datetime.now(timezone.utc),
                    content=match.content,
                    triggered_by=turn.text[:80],
                )
                prompts_fired.append(fired)
                ui_skill.push_prompt(case_id, match.prompt_id, {"text": match.content})
                log.info(
                    "prompt_fired",
                    prompt_idx=match.prompt_idx,
                    prompt_id=match.prompt_id,
                )

        transcript.append(turn)

        # Push a sentiment update to the CM panel (for live UI).
        if turn.speaker == "member" and sentiment_trend:
            ui_skill.push_sentiment(case_id, sentiment_trend[-1])

        # Persist progress every other turn so polled GETs see motion.
        if turn_count % 2 == 0:
            in_progress = session.model_copy(
                update={
                    "status": CallStatus.IN_PROGRESS,
                    "transcript": transcript,
                    "sentiment_trend": sentiment_trend,
                    "prompts_fired": prompts_fired,
                    "consent_captured": consent_captured,
                    "consent_excerpt": consent_excerpt,
                }
            )
            await _persist(in_progress)

    # Finalize the session.
    final = session.model_copy(
        update={
            "status": CallStatus.COMPLETE,
            "transcript": transcript,
            "sentiment_trend": sentiment_trend,
            "prompts_fired": prompts_fired,
            "consent_captured": consent_captured,
            "consent_excerpt": consent_excerpt,
            "ended_at": datetime.now(timezone.utc),
        }
    )
    await _persist(final)

    log.info(
        "stub_executed",
        agent=AGENT_NAME,
        input_state="OUTREACH_COMPLETE",
        output_state="CM_CALLBACK_IN_PROGRESS",
        call_id=call_id,
        turns=len(transcript),
        prompts=len(prompts_fired),
        consent=consent_captured,
        final_sentiment=sentiment_trend[-1] if sentiment_trend else None,
    )


# NOT registered in _registry — this agent is foreground (API-driven), not
# orchestrator-dispatched.
