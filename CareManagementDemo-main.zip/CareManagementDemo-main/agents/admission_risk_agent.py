"""Agent 01 — admission_risk_agent (STUB).

# TODO(teammate): implement per agent_prompts/01_admission_risk_agent.md
#
# This stub:
#   - Reads the discharge event from the case row.
#   - Calls the (mocked) member + claims skills so downstream stubs see realistic data.
#   - Mirrors the case into CRM via skills.crm.create_case (returns CRM-NNNNNNNN).
#   - Writes a fixed John-Martinez-shaped RiskScores row (Impactability 42,
#     Intervenability 31, Composite 73 → Medium). The real implementation
#     replaces this with LLM-scored subcomponents per the system prompt in
#     agent_prompts/01_admission_risk_agent.md.
#   - Creates 4 CRM workflow tasks.
#   - Transitions DISCHARGE_RECEIVED → RISK_STRATIFIED via update_case_state.
#
# Notes for the teammate:
#   - Use Strands Agents SDK (`from strands import Agent, tool`) for the LLM
#     scoring step. The stub doesn't import strands because it does no LLM work.
#   - The canonical case schema is `models/schemas.py`. The teammate's spec
#     mentions case-level fields like `case.impactability` that do NOT exist
#     in this schema — write to the `risk_scores` table instead (see
#     `db.state_io.insert_risk_scores`).
#   - The composite math, tiering, state transition, and CRM/task side-effects
#     are deterministic — never let the LLM compute totals or trigger writes.
"""

from __future__ import annotations

from agents._registry import register
from config.priority_tiers import tier_for
from db.pool import connection
from db.state import update_case_state
from db.state_io import get_case, insert_risk_scores, update_case_fields
from models.exceptions import CaseNotFound
from models.schemas import (
    CaseState,
    ImpactabilitySubscores,
    IntervenabilitySubscores,
    RiskScores,
)
from skills import claims as claims_skill
from skills import crm as crm_skill
from skills import member as member_skill
from skills._common import get_logger

AGENT_NAME = "admission_risk_agent"
INPUT_STATE = CaseState.DISCHARGE_RECEIVED
OUTPUT_STATE = CaseState.RISK_STRATIFIED

# POC scoring values (from poc.md, John Martinez case). Real impl computes these.
_POC_IMPACTABILITY = ImpactabilitySubscores(
    clinical_severity=9,
    utilization=8,
    med_complexity=9,
    care_gaps=8,
    prior_engagement=8,
)
_POC_INTERVENABILITY = IntervenabilitySubscores(
    sdoh=7,
    insurance_pharmacy=8,
    cognitive_behavioral=8,
    contactability=8,
)

_POC_WORKFLOW_TASKS = (
    "Verify member contactability",
    "Schedule discharge summary review",
    "Prepare TCM outreach materials",
    "Confirm PCP follow-up window (7-10 days)",
)


async def run(case_id: str) -> None:
    """Entry point dispatched by the orchestrator."""
    log = get_logger(case_id, agent=AGENT_NAME)

    # Read + idempotency check
    async with connection() as conn:
        case = await get_case(conn, case_id)
    if case is None:
        raise CaseNotFound(f"no case with case_id={case_id}", case_id=case_id)
    if case.current_state != INPUT_STATE:
        log.info(
            "stub_already_past",
            current_state=case.current_state.value,
            expected_input_state=INPUT_STATE.value,
        )
        return

    # Pull realistic upstream data so downstream stubs see something coherent.
    _ = member_skill.get_profile(case_id, case.member_id)
    _ = claims_skill.get_member_history(case_id, case.member_id)

    # Mirror the case into CRM (mocked).
    crm_case_number = crm_skill.create_case(
        case_id,
        case.member_id,
        primary_dx=case.primary_dx_code,
        facility=case.discharge_facility,
        plan=case.plan_name,
    )

    # Composite math is deterministic — stays in Python regardless of LLM scoring.
    impactability_total = sum(_POC_IMPACTABILITY.model_dump().values())
    intervenability_total = sum(_POC_INTERVENABILITY.model_dump().values())
    composite = impactability_total + intervenability_total
    tier = tier_for(composite)

    risk = RiskScores(
        case_id=case_id,
        impactability_total=impactability_total,
        impactability_subscores=_POC_IMPACTABILITY,
        intervenability_total=intervenability_total,
        intervenability_subscores=_POC_INTERVENABILITY,
        composite_priority=composite,
        priority_tier=tier,
    )

    # Persist scores + denormalize convenience fields onto the case row.
    async with connection() as conn:
        async with conn.transaction():
            await insert_risk_scores(conn, risk)
            await update_case_fields(
                conn,
                case_id,
                {
                    "crm_case_record_id": crm_case_number,
                    "composite_priority": composite,
                    "priority_tier": tier.value,
                },
            )

    # CRM workflow tasks (4 per the POC).
    for title in _POC_WORKFLOW_TASKS:
        crm_skill.create_task(case_id, title=title)

    # Advance the state machine.
    async with connection() as conn:
        await update_case_state(
            conn,
            case_id,
            OUTPUT_STATE,
            agent_name=AGENT_NAME,
            reason=f"risk stratified (stub): composite={composite}, tier={tier.value}",
            metadata={
                "composite_priority": composite,
                "priority_tier": tier.value,
                "crm_case_record_id": crm_case_number,
            },
        )

    log.info(
        "stub_executed",
        agent=AGENT_NAME,
        input_state=INPUT_STATE.value,
        output_state=OUTPUT_STATE.value,
        composite_priority=composite,
        priority_tier=tier.value,
        crm_case_record_id=crm_case_number,
    )


# Register at import time
register(AGENT_NAME, run)
