"""Agent 03 — outreach_agent (STUB).

# TODO(teammate): implement per agent_prompts/03_outreach_agent.md
#
# This stub:
#   - Opens a messaging session via skills.messaging.open_session.
#   - Walks the canned 6-step TCM conversation (identity verification →
#     clinical check-in → CMP pitch → outcome capture → callback preference)
#     by sending fixed prompts and reading skills.messaging.poll_for_reply,
#     which returns John Martinez's canned replies in order.
#   - Issues one skills.knowledge.search_guidelines call to exercise the
#     RAG corpus (CMP enrollment criteria for COPD).
#   - Builds the survey form with the POC's exact field values, derives the
#     `no_pcp_appt` SDOH flag from the "no follow-up" reply, persists the
#     OutreachSession via db.state_io.insert_outreach_session.
#   - Closes the messaging session.
#   - Transitions OUTREACH_SCHEDULED -> OUTREACH_COMPLETE.
#
# Notes for the teammate:
#   - The real implementation drives the conversation turn-by-turn with an LLM
#     (per the system prompt skeleton in the teammate spec) and handles 3-
#     attempt no-contact retries with 4-hour gaps. The stub fast-paths through
#     it with hard-coded prompts to leave plausible artifacts for downstream
#     stubs (agent_assist, scheduling).
#   - Identity verification is the only hard gate — name/DOB mismatch goes to
#     CLOSED_MEMBER_DECLINED (currently treated as terminal).
"""

from __future__ import annotations

from datetime import datetime, timezone

from agents._registry import register
from db.pool import connection
from db.state import update_case_state
from db.state_io import (
    get_case,
    get_member,
    get_outreach_by_case,
    insert_outreach_session,
)
from models.exceptions import CaseNotFound
from models.schemas import (
    CaseState,
    OutreachChannel,
    OutreachSession,
    OutreachStatus,
    OutreachTurn,
    SurveyForm,
)
from skills import knowledge as knowledge_skill
from skills import messaging as messaging_skill
from skills._common import get_logger

AGENT_NAME = "outreach_agent"
INPUT_STATE = CaseState.OUTREACH_SCHEDULED
OUTPUT_STATE = CaseState.OUTREACH_COMPLETE


# The 6-step canned outbound script. Paired 1:1 with the 7 canned replies in
# skills._fixtures.JOHN_MARTINEZ_MESSAGING_REPLIES; the first prompt covers
# identity + DOB so it consumes 2 replies.
_OUTBOUND_SCRIPT: list[tuple[str, str]] = [
    ("identity_verification",     "Hi, may I speak with John Martinez?"),
    ("identity_verification",     "Could you please confirm your date of birth?"),
    ("clinical_checkin",          "I'm calling on behalf of BlueCross Premier following your recent discharge from St. Mary's. How are you feeling? Any shortness of breath?"),
    ("clinical_checkin",          "Have you picked up your medications - the Prednisone and inhalers?"),
    ("clinical_checkin",          "And do you have a follow-up with Dr. Garcia scheduled?"),
    ("cmp_pitch",                 "Our Care Management Program provides a dedicated nurse and case manager to support you at home - would you like to hear more?"),
    ("callback_preference",       "Great. What time of day usually works best for your CM to call you back?"),
]


def _build_survey() -> SurveyForm:
    """Canned John Martinez survey (matches poc.md)."""
    return SurveyForm(
        language="English",
        communication_assistance="None",
        symptoms="Mild dyspnea, morning SOB",
        medication_pickup=True,
        pcp_followup_scheduled=False,    # triggers `no_pcp_appt` SDOH flag
        cmp_enrollment=True,
        contact_phone="+15558472910",
        callback_preference="afternoon",  # canned reply turn 7 ("Afternoon usually works best...")
    )


def _derive_sdoh_flags(survey: SurveyForm) -> list[str]:
    flags: list[str] = []
    if survey.pcp_followup_scheduled is False:
        flags.append("no_pcp_appt")
    if survey.medication_pickup is False:
        flags.append("med_pickup_gap")
    # Other flags (transport_gap, lives_alone, language_barrier) are populated
    # by the LLM in the real impl; stub only emits the gate-detected one.
    return flags


async def run(case_id: str) -> None:
    log = get_logger(case_id, agent=AGENT_NAME)

    async with connection() as conn:
        case = await get_case(conn, case_id)
    if case is None:
        raise CaseNotFound(f"no case with case_id={case_id}", case_id=case_id)
    if case.current_state != INPUT_STATE:
        log.info(
            "stub_already_past",
            current_state=case.current_state.value,
            expected_input_state=INPUT_STATE.value,
        )
        return

    # If an outreach session already exists for this case, skip re-running.
    async with connection() as conn:
        prior = await get_outreach_by_case(conn, case_id)
    if prior is not None and prior.status == OutreachStatus.COMPLETE:
        log.info("outreach_already_complete", session_id=prior.session_id)
        async with connection() as conn:
            await update_case_state(
                conn,
                case_id,
                OUTPUT_STATE,
                agent_name=AGENT_NAME,
                reason="outreach session already complete; advancing",
            )
        return

    # Member context (used for the messaging open_session call).
    async with connection() as conn:
        member = await get_member(conn, case.member_id)
    member_phone = member.phone if member else "(unknown)"

    # Exercise the RAG corpus once so a real teammate-built citation list has
    # at least one entry on the audit trail.
    rag_hits = await knowledge_skill.search_guidelines(
        case_id,
        query="Care Management Program enrollment criteria for COPD post-discharge",
        k=3,
    )
    log.info(
        "rag_grounding",
        top_hit=rag_hits[0].section_title if rag_hits else None,
        top_sim=rag_hits[0].similarity if rag_hits else None,
    )

    # Open the messaging session + run the canned exchange.
    session_id = messaging_skill.open_session(case_id, case.member_id, member_phone)
    transcript: list[OutreachTurn] = []
    for step_label, prompt in _OUTBOUND_SCRIPT:
        ts = datetime.now(timezone.utc)
        messaging_skill.send_message(case_id, session_id, prompt)
        transcript.append(OutreachTurn(role="tcm", text=prompt, timestamp=ts))
        reply = messaging_skill.poll_for_reply(case_id, session_id, timeout_seconds=10)
        if reply is None:
            log.info("no_reply_received", step=step_label)
            break
        transcript.append(
            OutreachTurn(
                role="member",
                text=reply,
                timestamp=datetime.now(timezone.utc),
            )
        )

    messaging_skill.close_session(case_id, session_id)

    survey = _build_survey()
    sdoh = _derive_sdoh_flags(survey)

    outreach = OutreachSession(
        session_id=session_id,
        case_id=case_id,
        channel=OutreachChannel.MESSAGING,
        status=OutreachStatus.COMPLETE,
        transcript=transcript,
        survey=survey,
        sdoh_flags=sdoh,
        completed_at=datetime.now(timezone.utc),
    )

    async with connection() as conn:
        async with conn.transaction():
            await insert_outreach_session(conn, outreach)

    async with connection() as conn:
        await update_case_state(
            conn,
            case_id,
            OUTPUT_STATE,
            agent_name=AGENT_NAME,
            reason=f"outreach complete: cmp_enrollment={survey.cmp_enrollment}, sdoh_flags={sdoh}",
            metadata={
                "session_id": session_id,
                "turns": len(transcript),
                "sdoh_flags": sdoh,
                "cmp_enrollment": survey.cmp_enrollment,
            },
        )

    log.info(
        "stub_executed",
        agent=AGENT_NAME,
        input_state=INPUT_STATE.value,
        output_state=OUTPUT_STATE.value,
        session_id=session_id,
        turns=len(transcript),
        sdoh_flags=sdoh,
    )


register(AGENT_NAME, run)
