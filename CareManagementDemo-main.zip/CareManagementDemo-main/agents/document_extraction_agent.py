"""Agent 02 -- document_extraction_agent.

Pipeline position
-----------------
    RISK_STRATIFIED  -->  [this agent extracts + scores + flags]
                                       |
                              DOCUMENT_PENDING_REVIEW
                                       |
                          (clinician approves via review endpoint)
                                       v
                              DOCUMENT_APPROVED

The orchestrator does NOT re-dispatch us. After we transition into
`DOCUMENT_PENDING_REVIEW` we stop. The clinician moves the case forward
via the human-gate endpoint (`api/routes/review.py`).

What we do
----------
1. Retrieve the Hospital Discharge Summary PDF (mocked under data/documents/).
2. Parse the PDF (Unstructured + Tesseract OCR in real impl; markdown text
   for the POC stand-in).
3. Extract 13 fields + confidence per `agent_prompts/02_*.md` via Bedrock
   (`skills.documents.extract_fields_llm`). LLM failures (BedrockError,
   ExtractionParseError) are not caught -- they propagate to the
   orchestrator, which owns retry-with-backoff-then-escalate.
4. Apply the 0.80 confidence threshold deterministically. Build the
   denormalized `case.extraction_flags` array `[{field, confidence, reason}, ...]`
   for the reviewer UI.
5. Check STP eligibility via `config.stp_rules.is_stp(case)` and persist
   `case.is_stp` for visibility (currently always False).
6. Transition state to `DOCUMENT_PENDING_REVIEW`. Stop.

What we do NOT do
-----------------
- Approve the document. That is the clinician's job via `review.py`.
- Transition past `DOCUMENT_PENDING_REVIEW`. Same reason.
- Retry document fetch indefinitely -- two attempts then escalate.
- Log PII in cleartext -- the structlog redactor processor (installed via
  `skills._common`) auto-masks known PII keys (name, MRN, DOB, phone, email)
  on every log line. We only emit counts + state values, never raw field
  values, so the redactor doesn't have to do heroics.
- Bypass `update_case_state`. All state changes flow through it.

Idempotency
-----------
We guard at the state level (skip if current_state != RISK_STRATIFIED), and at
the data level (skip re-extraction if `extracted_fields` already exists). Both
have to hold because the orchestrator can re-dispatch on transient failure.
"""

from __future__ import annotations

from typing import Any

from agents._registry import register
from config import stp_rules
from config.extraction import (
    EXPECTED_FIELDS,
    LOW_CONFIDENCE_THRESHOLD,
    MAX_DOCUMENT_FETCH_ATTEMPTS,
)
from db.pool import connection
from db.state import update_case_state
from db.state_io import (
    get_case,
    insert_extracted_fields,
    list_extracted_fields,
    update_case_fields,
)
from models.exceptions import (
    CaseNotFound,
    DocumentNotFound,
)
from models.schemas import Case, CaseState, ExtractedField
from skills import documents as documents_skill
from skills import ehr as ehr_skill
from skills._common import get_logger

AGENT_NAME = "document_extraction_agent"
INPUT_STATE = CaseState.RISK_STRATIFIED
OUTPUT_STATE = CaseState.DOCUMENT_PENDING_REVIEW
ESCALATED_STATE = CaseState.ESCALATED


# Lookup so the flag payload can carry the tier ("high"|"medium"|"low") to
# the reviewer UI without re-importing config.extraction there.
_TIER_BY_FIELD: dict[str, str] = {f.name: f.tier for f in EXPECTED_FIELDS}


async def run(case_id: str) -> None:
    """Entry point dispatched by the orchestrator."""
    log = get_logger(case_id, agent=AGENT_NAME)

    # ---- 1. Load case + idempotency guards ---------------------------------
    async with connection() as conn:
        case = await get_case(conn, case_id)
    if case is None:
        raise CaseNotFound(f"no case with case_id={case_id}", case_id=case_id)
    if case.current_state != INPUT_STATE:
        log.info(
            "skip_already_past_input_state",
            current_state=case.current_state.value,
            expected_input_state=INPUT_STATE.value,
        )
        return

    # If extraction has already produced rows for this case, don't duplicate
    # them. The state guard above is the primary gate, but a partial prior run
    # could have inserted rows + crashed before the state transition. Trust
    # the rows we already have, recompute flags + STP, then advance state.
    async with connection() as conn:
        existing = await list_extracted_fields(conn, case_id)
    if existing:
        log.info("extraction_already_present", existing_count=len(existing))
        fields = existing
    else:
        # ---- 2/3. Fetch + parse + extract --------------------------------
        fields = await _fetch_and_extract(case, log)
        if fields is None:
            # Document fetch exhausted retries -> agent already escalated below.
            return

        async with connection() as conn:
            async with conn.transaction():
                await insert_extracted_fields(conn, fields)
        log.info(
            "fields_persisted",
            total=len(fields),
            flagged=sum(1 for f in fields if f.flagged),
        )

    # ---- 4. Build extraction_flags payload ---------------------------------
    extraction_flags = _build_extraction_flags(fields)

    # ---- 5. STP eligibility check ------------------------------------------
    # Use a shallow case copy with the freshly extracted data so the rule
    # function sees the post-extraction view.
    case_for_stp = case.model_copy(update={
        "extraction_flags": extraction_flags,
        "is_stp": False,  # placeholder so the rule function doesn't see stale state
    })
    try:
        is_stp = bool(stp_rules.is_stp(case_for_stp))
    except Exception as exc:  # pragma: no cover - defensive: stp rule shouldn't raise
        log.warning("stp_rule_failed", error=str(exc), error_type=type(exc).__name__)
        is_stp = False

    # ---- Persist denormalized columns + ---- 6. Advance state -------------
    async with connection() as conn:
        async with conn.transaction():
            await update_case_fields(
                conn,
                case_id,
                {
                    "extraction_flags": extraction_flags,
                    "is_stp": is_stp,
                },
            )

    async with connection() as conn:
        await update_case_state(
            conn,
            case_id,
            OUTPUT_STATE,
            agent_name=AGENT_NAME,
            reason=(
                f"extracted {len(fields)} fields "
                f"({len(extraction_flags)} flagged); "
                f"awaiting clinician review"
            ),
            metadata={
                "low_confidence_threshold": LOW_CONFIDENCE_THRESHOLD,
                "human_gate": "clinician_review",
                "extracted_field_count": len(fields),
                "flagged_field_count": len(extraction_flags),
                "is_stp": is_stp,
            },
        )

    log.info(
        "extraction_complete",
        input_state=INPUT_STATE.value,
        output_state=OUTPUT_STATE.value,
        extracted_field_count=len(fields),
        flagged_field_count=len(extraction_flags),
        is_stp=is_stp,
    )


# =============================================================================
# Document fetch + extraction with retry/escalation
# =============================================================================


async def _fetch_and_extract(case: Case, log: Any) -> list[ExtractedField] | None:
    """Fetch + parse + extract.

    Returns the extracted field list on success. Returns None and escalates
    the case if we cannot retrieve the discharge summary after
    `MAX_DOCUMENT_FETCH_ATTEMPTS` tries.
    """
    case_id = case.case_id

    last_error: Exception | None = None
    for attempt in range(1, MAX_DOCUMENT_FETCH_ATTEMPTS + 1):
        try:
            doc_path = ehr_skill.fetch_discharge_summary(
                case_id, case.member_id, case.discharge_date
            )
            text = documents_skill.parse_pdf(case_id, doc_path)
            break
        except DocumentNotFound as exc:
            # 404 from the EHR mock -- retry won't fix a permanent miss, but
            # the spec says "after 2 attempts, escalate", so honor that.
            last_error = exc
            log.warning(
                "document_fetch_failed",
                attempt=attempt,
                max_attempts=MAX_DOCUMENT_FETCH_ATTEMPTS,
                error=str(exc),
                error_type=type(exc).__name__,
            )
        except Exception as exc:
            last_error = exc
            log.warning(
                "document_parse_failed",
                attempt=attempt,
                max_attempts=MAX_DOCUMENT_FETCH_ATTEMPTS,
                error=str(exc),
                error_type=type(exc).__name__,
            )
    else:
        # All attempts exhausted -> escalate.
        reason = f"discharge summary fetch failed after {MAX_DOCUMENT_FETCH_ATTEMPTS} attempts"
        log.error(
            "document_fetch_exhausted",
            attempts=MAX_DOCUMENT_FETCH_ATTEMPTS,
            last_error=str(last_error) if last_error else None,
        )
        async with connection() as conn:
            await update_case_state(
                conn,
                case_id,
                ESCALATED_STATE,
                agent_name=AGENT_NAME,
                reason=reason,
                metadata={
                    "attempts": MAX_DOCUMENT_FETCH_ATTEMPTS,
                    "last_error": str(last_error) if last_error else None,
                    "last_error_type": type(last_error).__name__ if last_error else None,
                },
            )
        return None

    # ---- Run the real LLM extractor ----------------------------------------
    # BedrockError (transport / credentials) and ExtractionParseError (model
    # returned non-JSON) both propagate to the orchestrator, which owns the
    # retry-with-backoff-then-escalate policy. We do NOT silently fall back
    # to the deterministic mock -- a fallback at this layer would hide LLM
    # outages from the on-call surface.
    return documents_skill.extract_fields_llm(case_id, text)


# =============================================================================
# Flag aggregation (deterministic Python -- not an LLM job)
# =============================================================================


def _build_extraction_flags(
    fields: list[ExtractedField],
) -> list[dict[str, Any]]:
    """Build the denormalized `case.extraction_flags` payload.

    One entry per flagged field, in the same order they appear in `fields`.
    Each entry is `{field, confidence, reason, tier}`. `reason` is best-effort:
    we surface the LLM's per-field rationale (carried via `source_bbox.reason`
    on the row) if present, else we fall back to a generic threshold message.

    The payload stored in the DB carries the raw extracted value because the
    reviewer UI needs the clinician-readable text. Log lines that surface
    these payloads stay redacted by the structlog PII processor.
    """
    flagged: list[dict[str, Any]] = []
    for f in fields:
        if not f.flagged:
            continue
        reason = _reason_for_flag(f)
        flagged.append(
            {
                "field": f.field_name,
                "confidence": round(float(f.confidence), 3),
                "reason": reason,
                "tier": _TIER_BY_FIELD.get(f.field_name, "unknown"),
            }
        )
    return flagged


def _reason_for_flag(field: ExtractedField) -> str:
    """Best-effort human-readable reason for the red badge.

    Order of preference:
      1. LLM-supplied `reason` (stored in `source_bbox.reason` by the
         LLM extractor).
      2. A generic "below threshold" string carrying the threshold value
         so the reviewer knows the bar.
    """
    if isinstance(field.source_bbox, dict):
        raw_reason = field.source_bbox.get("reason")
        if isinstance(raw_reason, str) and raw_reason.strip():
            return raw_reason.strip()
    return (
        f"confidence {field.confidence:.2f} is below the "
        f"{LOW_CONFIDENCE_THRESHOLD:.2f} threshold; clinician review required"
    )


register(AGENT_NAME, run)
