"""Orchestrator — the only agent built fully in Step 5.

Polls `cases.current_state`, dispatches to the agent registered for that
state, enforces idempotency + retries, and emits milestone events for the
communication_agent to deliver.

Public API:
  - `tick(limit=...)` — run one pass; returns a stats dict
  - `run(poll_interval_s=..., max_ticks=..., stop_event=...)` — continuous loop

The orchestrator is itself an agent (it writes to `audit_log` under
`agent_name="orchestration_agent"`) but is not registered in `_registry` —
nothing dispatches to it; it dispatches everyone else.
"""

from __future__ import annotations

import asyncio
import os
from datetime import datetime, timedelta, timezone
from typing import Any

from psycopg.rows import dict_row
from psycopg.types.json import Jsonb

from agents._registry import get as get_agent
from config.orchestrator import (
    AUTO_TRANSITIONS,
    DEFAULT_POLL_SECONDS,
    DEFAULT_TICK_LIMIT,
    DISPATCH_LEASE_SECONDS,
    DISPATCHABLE_STATES,
    MAX_RETRIES,
    MILESTONE_STATES,
    RETRY_BACKOFF_SECONDS,
    STATE_TO_AGENT_NAME,
)
from db.pool import connection
from db.state import update_case_state
from db.state_io import get_case, update_case_fields
from models.exceptions import InvalidStateTransition
from models.schemas import Case, CaseState
from skills._common import get_logger

AGENT_NAME = "orchestration_agent"


# =============================================================================
# Claim
# =============================================================================


async def _claim_cases(limit: int) -> list[Case]:
    """Pick the next batch of dispatchable cases and lease them.

    Lease = bump `next_eligible_at` forward by `DISPATCH_LEASE_SECONDS` so
    a long-running agent (or a crashed orchestrator) doesn't double-dispatch.
    The lease is cleared by `update_case_state` on a successful transition.
    """
    states_array = [s.value for s in DISPATCHABLE_STATES]
    async with connection() as conn:
        async with conn.transaction():
            async with conn.cursor(row_factory=dict_row) as cur:
                await cur.execute(
                    """
                    SELECT * FROM cases
                     WHERE current_state = ANY(%s)
                       AND (next_eligible_at IS NULL OR next_eligible_at <= now())
                     ORDER BY created_at
                     LIMIT %s
                     FOR UPDATE SKIP LOCKED
                    """,
                    (states_array, limit),
                )
                rows = await cur.fetchall()
                cases = [Case.model_validate(r) for r in rows]
                if cases:
                    lease = datetime.now(timezone.utc) + timedelta(
                        seconds=DISPATCH_LEASE_SECONDS
                    )
                    await cur.execute(
                        "UPDATE cases SET next_eligible_at = %s WHERE case_id = ANY(%s)",
                        (lease, [c.case_id for c in cases]),
                    )
                return cases


# =============================================================================
# Milestone emission
# =============================================================================


# Milestone emission moved into `db.state.update_case_state` so every
# transition path (agent, API, auto-transition) emits exactly once. This
# module no longer needs a local _emit_milestone helper.


# =============================================================================
# Failure handling
# =============================================================================


async def _record_transient_failure(
    case: Case, agent_name: str, exc: Exception, next_count: int
) -> None:
    idx = min(next_count - 1, len(RETRY_BACKOFF_SECONDS) - 1)
    delay = RETRY_BACKOFF_SECONDS[idx]
    next_eligible = datetime.now(timezone.utc) + timedelta(seconds=delay)
    error_str = f"{type(exc).__name__}: {exc}"

    async with connection() as conn:
        async with conn.transaction():
            await update_case_fields(
                conn,
                case.case_id,
                {
                    "agent_retry_count": next_count,
                    "agent_last_error": error_str,
                    "next_eligible_at": next_eligible,
                },
            )
            async with conn.cursor() as cur:
                await cur.execute(
                    """
                    INSERT INTO audit_log
                        (case_id, from_state, to_state, agent_name, reason, metadata)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    """,
                    (
                        case.case_id,
                        case.current_state.value,
                        case.current_state.value,
                        AGENT_NAME,
                        f"transient_failure retry={next_count}/{MAX_RETRIES}",
                        Jsonb(
                            {
                                "failing_agent": agent_name,
                                "error": error_str,
                                "backoff_seconds": delay,
                            }
                        ),
                    ),
                )
    get_logger(case.case_id).info(
        "agent_transient_failure",
        agent=agent_name,
        retry=f"{next_count}/{MAX_RETRIES}",
        backoff_seconds=delay,
    )


async def _escalate(case: Case, agent_name: str, exc: Exception, attempts: int) -> None:
    error_str = f"{type(exc).__name__}: {exc}"
    async with connection() as conn:
        try:
            await update_case_state(
                conn,
                case.case_id,
                CaseState.ESCALATED,
                agent_name=AGENT_NAME,
                reason=(
                    f"retries exhausted ({attempts}/{MAX_RETRIES}) in "
                    f"{agent_name}: {error_str}"
                ),
                metadata={
                    "failing_agent": agent_name,
                    "error": error_str,
                    "attempts": attempts,
                },
            )
        except InvalidStateTransition as ex:
            get_logger(case.case_id).error(
                "escalation_blocked_by_state_machine",
                agent=agent_name,
                from_state=case.current_state.value,
                error=str(ex),
            )
            return

    get_logger(case.case_id).warning(
        "agent_escalated_after_retries",
        agent=agent_name,
        attempts=attempts,
    )


async def _handle_agent_failure(case: Case, agent_name: str, exc: Exception) -> None:
    next_count = case.agent_retry_count + 1
    if next_count >= MAX_RETRIES:
        await _escalate(case, agent_name, exc, attempts=next_count)
    else:
        await _record_transient_failure(case, agent_name, exc, next_count)


# =============================================================================
# Dispatch
# =============================================================================


async def _dispatch_case(case: Case) -> None:
    lg = get_logger(case.case_id)

    # 1) Auto-transitions take precedence (no agent needed)
    if case.current_state in AUTO_TRANSITIONS:
        target, reason = AUTO_TRANSITIONS[case.current_state]
        async with connection() as conn:
            await update_case_state(
                conn, case.case_id, target, agent_name=AGENT_NAME, reason=reason
            )
        # Milestone emission is now handled inside update_case_state.
        lg.info(
            "auto_transition",
            from_state=case.current_state.value,
            to_state=target.value,
        )
        return

    # 2) Look up registered agent for this state
    agent_name = STATE_TO_AGENT_NAME.get(case.current_state)
    if not agent_name:
        lg.info("no_agent_for_state", state=case.current_state.value)
        return

    agent_fn = get_agent(agent_name)
    if not agent_fn:
        lg.info(
            "agent_not_registered",
            agent=agent_name,
            state=case.current_state.value,
        )
        return

    # 3) Dispatch
    lg.info(
        "agent_dispatch_start",
        agent=agent_name,
        state=case.current_state.value,
        retry_count=case.agent_retry_count,
    )
    try:
        await agent_fn(case.case_id)
    except Exception as exc:
        lg.error(
            "agent_dispatch_failed",
            agent=agent_name,
            error_type=type(exc).__name__,
            error=str(exc),
        )
        await _handle_agent_failure(case, agent_name, exc)
        return

    # 4) Inspect post-dispatch state; emit milestone if transitioned to one
    async with connection() as conn:
        refreshed = await get_case(conn, case.case_id)

    if refreshed and refreshed.current_state != case.current_state:
        lg.info(
            "agent_dispatch_done",
            agent=agent_name,
            from_state=case.current_state.value,
            to_state=refreshed.current_state.value,
        )
        # Milestone emission is now handled inside update_case_state (the agent's
        # own call). Nothing to do here besides log the outcome.
    else:
        # The agent ran but didn't change state — idempotent re-entry or no-op.
        lg.info(
            "agent_dispatch_noop",
            agent=agent_name,
            state=case.current_state.value,
        )


# =============================================================================
# Public entrypoints
# =============================================================================


async def tick(*, limit: int = DEFAULT_TICK_LIMIT) -> dict[str, Any]:
    """Run one dispatch pass. Returns a small stats dict."""
    cases = await _claim_cases(limit=limit)
    log = get_logger(case_id="-")
    log.info("orchestrator_tick", claimed=len(cases))
    for case in cases:
        await _dispatch_case(case)
    return {
        "claimed": len(cases),
        "case_ids": [c.case_id for c in cases],
        "ts": datetime.now(timezone.utc).isoformat(),
    }


async def run(
    *,
    poll_interval_s: int | None = None,
    max_ticks: int | None = None,
    stop_event: asyncio.Event | None = None,
) -> None:
    """Continuous polling loop. Stops on `stop_event`, on `max_ticks`, or on cancel."""
    poll = poll_interval_s if poll_interval_s is not None else DEFAULT_POLL_SECONDS
    log = get_logger(case_id="-")
    log.info("orchestrator_run_start", poll_interval_s=poll, max_ticks=max_ticks)

    ticks = 0
    while True:
        if stop_event is not None and stop_event.is_set():
            log.info("orchestrator_stop_requested")
            return
        await tick()
        ticks += 1
        if max_ticks is not None and ticks >= max_ticks:
            log.info("orchestrator_max_ticks_reached", ticks=ticks)
            return
        # Sleep with cooperative stop support
        if stop_event is None:
            await asyncio.sleep(poll)
        else:
            try:
                await asyncio.wait_for(stop_event.wait(), timeout=poll)
                log.info("orchestrator_stop_during_sleep")
                return
            except asyncio.TimeoutError:
                continue
