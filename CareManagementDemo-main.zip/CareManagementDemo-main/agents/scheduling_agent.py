"""Agent 05 — scheduling_agent (STUB).

# TODO(teammate): implement per agent_prompts/05_scheduling_agent.md
#
# CM-triggered mid-call (via POST /cases/{id}/schedule) once verbal consent
# has been captured in the live transcript. NOT orchestrator-dispatched.
#
# Side-effects (per poc.md Stage 5):
#   1. Book the PCP appointment via skills.scheduling.book_appointment.
#   2. Send an SMS confirmation (Twilio stub appends to data/outbox/sms.log).
#   3. Render the appointment confirmation PDF (or HTML fallback on Windows).
#   4. Mirror the appointment into CRM via skills.crm.create_appointment.
#   5. Update the Patient Journey Calendar.
#   6. Queue a follow-up CRM task ("Follow up after PCP visit and confirm device receipt").
#   7. Insert a referrals row for the Valley CHC pulse oximeter (community/device).
#   8. Transition CM_CALLBACK_IN_PROGRESS -> APPOINTMENT_BOOKED.
#
# Notes for the teammate:
#   - The real impl uses skills.scheduling.get_availability + a slot picker that
#     honors callback_preference; selects the EARLIEST matching slot in the
#     7-14 day TCM window. The stub fast-paths to the John Martinez canonical
#     Oct 10 14:00 slot through that same picker (matches poc.md).
#   - Verbal consent verification is currently a flag check on the latest
#     CallSession. Real impl re-verifies the last N transcript turns via the
#     LLM in case the CM clicked Book without confirming.
#   - All side effects above should be wrapped so a failure in (say) PDF
#     rendering does NOT block the state transition — the appointment IS
#     booked; the artifact list is best-effort and re-triable.
"""

from __future__ import annotations

from datetime import datetime, time, timedelta, timezone

from agents._registry import register
from db.pool import connection
from db.state import update_case_state
from db.state_io import (
    get_case,
    get_latest_appointment,
    get_latest_call_session,
    get_member,
    get_outreach_by_case,
    insert_appointment,
    insert_referral,
)
from models.exceptions import CaseNotFound, ConsentNotCaptured
from models.schemas import (
    AppointmentStatus,
    CaseState,
    Referral,
    ReferralStatus,
    ResourceSource,
    ResourceType,
)
from skills import calendar as calendar_skill
from skills import crm as crm_skill
from skills import pdf as pdf_skill
from skills import scheduling as scheduling_skill
from skills import sms as sms_skill
from skills import templates as templates_skill
from skills._common import get_logger

AGENT_NAME = "scheduling_agent"
INPUT_STATE = CaseState.CM_CALLBACK_IN_PROGRESS
OUTPUT_STATE = CaseState.APPOINTMENT_BOOKED


def _pick_slot(
    slots: list[datetime],
    callback_preference: str | None,
) -> datetime | None:
    """Earliest slot matching the member's preferred time of day."""
    if not slots:
        return None
    pref = (callback_preference or "").lower()
    if pref == "morning":
        candidates = [s for s in slots if s.hour < 12]
    elif pref == "afternoon":
        candidates = [s for s in slots if 12 <= s.hour < 17]
    elif pref == "evening":
        candidates = [s for s in slots if s.hour >= 17]
    else:
        candidates = list(slots)
    if not candidates:
        candidates = list(slots)  # fallback: any slot
    return min(candidates)


def _humanize(when: datetime) -> str:
    """Render `Oct 10, 2026 at 2:00 PM`."""
    return when.strftime("%b %d, %Y at %-I:%M %p") if hasattr(when, "strftime") else str(when)


def _humanize_safe(when: datetime) -> str:
    """Windows strftime doesn't support `%-I` (no leading zero). Roll our own."""
    hour12 = when.hour % 12 or 12
    ampm = "AM" if when.hour < 12 else "PM"
    return f"{when.strftime('%b %d, %Y')} at {hour12}:{when.strftime('%M')} {ampm}"


async def run(case_id: str, *, cm_id: str, call_id: str | None = None) -> None:
    """Book the PCP appointment + render artifacts + transition state."""
    log = get_logger(case_id, agent=AGENT_NAME, cm_id=cm_id, call_id=call_id)

    # 1) Read case + verify pre-conditions
    async with connection() as conn:
        case = await get_case(conn, case_id)
        if case is None:
            raise CaseNotFound(f"no case with case_id={case_id}", case_id=case_id)
        if case.current_state != INPUT_STATE:
            log.info(
                "stub_already_past",
                current_state=case.current_state.value,
                expected_input_state=INPUT_STATE.value,
            )
            return
        call = await get_latest_call_session(conn, case_id)
        if call is None:
            raise ConsentNotCaptured(
                "no call session for this case", case_id=case_id
            )
        if not call.consent_captured:
            raise ConsentNotCaptured(
                "verbal consent not captured in transcript", case_id=case_id
            )

        member = await get_member(conn, case.member_id)
        outreach = await get_outreach_by_case(conn, case_id)

    callback_preference = (
        outreach.survey.callback_preference if outreach and outreach.survey else None
    )

    # 2) Get availability — 7-day window starting the day after discharge.
    window_start = datetime.combine(
        case.discharge_date + timedelta(days=1), time.min, tzinfo=timezone.utc
    )
    window_end = datetime.combine(
        case.discharge_date + timedelta(days=10), time.max, tzinfo=timezone.utc
    )
    slots = scheduling_skill.get_availability(
        case_id,
        pcp_id=case.pcp_name and "PCP-00042100" or "PCP-00042100",
        window_start=window_start,
        window_end=window_end,
    )
    slot = _pick_slot(slots, callback_preference)
    if slot is None:
        # In the real impl this would surface a list back to the CM via
        # skills.ui.push_slot_options. For the stub we treat as unrecoverable.
        log.error("no_available_slot", window_start=window_start.isoformat())
        return

    # 3) Book it.
    appt = scheduling_skill.book_appointment(
        case_id,
        pcp_id="PCP-00042100",
        slot=slot,
        provider_name=case.pcp_name or "Dr. Luis Garcia",
        location="Springfield Primary Care Clinic, 250 Main St.",
        specialty="Primary Care",
    )

    # 4) SMS confirmation (stub mode appends to data/outbox/sms.log).
    member_phone = member.phone if member else "(unknown)"
    member_first_name = member.first_name if member else "John"
    sms_body = templates_skill.render(
        case_id,
        "sms_appointment_confirmation.j2",
        {
            "member_first_name": member_first_name,
            "provider_name": appt.provider_name,
            "slot_human": _humanize_safe(slot),
            "location": appt.location,
        },
    )
    sms_sid = sms_skill.send(case_id, member_phone, sms_body)
    appt.sms_confirmation_sent = True

    # 5) Persist appointment row.
    async with connection() as conn:
        async with conn.transaction():
            appointment_id = await insert_appointment(conn, appt)

    # 6) Mirror to CRM.
    crm_appt_id = crm_skill.create_appointment(
        case_id,
        appointment_id=appointment_id,
        slot=slot,
        pcp_id="PCP-00042100",
    )

    # 7) Patient Journey Calendar entry.
    cal_event_id = calendar_skill.add_event(
        case_id,
        member_id=case.member_id,
        when=slot,
        title=f"PCP follow-up: {appt.provider_name}",
        kind="appointment",
    )

    # 8) Render appointment confirmation PDF (or HTML fallback when WeasyPrint isn't installed).
    pdf_path = pdf_skill.render(
        case_id,
        "appointment_confirmation.j2",
        {
            "case_id": case_id,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "member_name": f"{member.first_name} {member.last_name}" if member else "John Martinez",
            "member_id": case.member_id,
            "plan_name": case.plan_name or "BlueCross Premier",
            "provider_name": appt.provider_name,
            "specialty": appt.specialty,
            "slot_human": _humanize_safe(slot),
            "location": appt.location,
        },
    )

    # 9) Follow-up CRM task.
    task_id = crm_skill.create_task(
        case_id,
        title="Follow up after PCP visit and confirm device receipt",
        due_at=slot + timedelta(days=1),
        priority="normal",
    )

    # 10) Community resource referral — Valley CHC pulse oximeter.
    referral = Referral(
        case_id=case_id,
        resource_name="Valley Community Health Center - Pulse Oximeter Program",
        resource_type=ResourceType.DEVICE,
        source=ResourceSource.COMMUNITY,
        status=ReferralStatus.CREATED,
        notes=(
            "Member has no home pulse oximeter on file. Referred during CM "
            "callback per Prompt 2. Follow-up task tracks confirmation."
        ),
    )
    async with connection() as conn:
        async with conn.transaction():
            referral_id = await insert_referral(conn, referral)

    # 11) Transition state.
    async with connection() as conn:
        await update_case_state(
            conn,
            case_id,
            OUTPUT_STATE,
            agent_name=AGENT_NAME,
            reason=(
                f"appointment booked: {appt.provider_name} @ {_humanize_safe(slot)} "
                f"(consent: {call.consent_excerpt!r})"
            ),
            metadata={
                "appointment_id": appointment_id,
                "scheduled_at": slot.isoformat(),
                "crm_appt_id": crm_appt_id,
                "calendar_event_id": cal_event_id,
                "sms_sid": sms_sid,
                "follow_up_task_id": task_id,
                "referral_id": referral_id,
                "pdf_artifact": str(pdf_path),
            },
        )

    log.info(
        "stub_executed",
        agent=AGENT_NAME,
        input_state=INPUT_STATE.value,
        output_state=OUTPUT_STATE.value,
        appointment_id=appointment_id,
        scheduled_at=slot.isoformat(),
        referral_id=referral_id,
        follow_up_task_id=task_id,
        pdf_artifact=str(pdf_path),
    )


# Registered for parity with other stubs, though it's invoked directly by the
# POST /cases/{id}/schedule route (CM-triggered, not orchestrator-dispatched).
register(AGENT_NAME, run)
