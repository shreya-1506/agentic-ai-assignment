"""Agent registry.

Each work-agent module calls `register(name, fn)` at import time. The
orchestrator looks the function up by name (from `config.orchestrator.STATE_TO_AGENT_NAME`)
and `await`s it for each dispatchable case.

Agent function shape:  `async def run(case_id: str) -> None`
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable

AgentFn = Callable[[str], Awaitable[None]]

_REGISTRY: dict[str, AgentFn] = {}


def register(name: str, fn: AgentFn) -> None:
    """Register an agent under `name`. Re-registering overrides (test-friendly)."""
    _REGISTRY[name] = fn


def get(name: str) -> AgentFn | None:
    return _REGISTRY.get(name)


def all_registered() -> dict[str, AgentFn]:
    return dict(_REGISTRY)


def unregister(name: str) -> None:
    """Test helper — drop a registration."""
    _REGISTRY.pop(name, None)


def _reset() -> None:
    """Test helper — clear the registry."""
    _REGISTRY.clear()
