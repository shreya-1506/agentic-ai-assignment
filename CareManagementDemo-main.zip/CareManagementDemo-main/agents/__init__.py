"""Agent modules.

The orchestrator dispatches by `CaseState` via [`config.orchestrator.STATE_TO_AGENT_NAME`](config/orchestrator.py).
Each work-agent module registers its handler with `agents._registry.register(...)`
at import time. The orchestration_agent loads this package on startup, which
imports every sibling module and triggers their `register()` calls.

For Step 5 only the orchestrator itself is here. Stubs land in Steps 6, 8, 9,
11, 12, 13, 14.
"""

from __future__ import annotations

# Importing sub-modules here is what triggers their `register()` side-effects.
# Add new agent modules to this list as they land.
from . import _registry  # noqa: F401
from . import admission_risk_agent  # noqa: F401  registers admission_risk_agent
from . import agent_assist_agent  # noqa: F401  foreground (API-driven)
from . import document_extraction_agent  # noqa: F401  registers document_extraction_agent
from . import outreach_agent  # noqa: F401  registers outreach_agent
from . import scheduling_agent  # noqa: F401  CM-triggered mid-call

__all__ = [
    "_registry",
    "admission_risk_agent",
    "agent_assist_agent",
    "document_extraction_agent",
    "outreach_agent",
    "scheduling_agent",
]
