# Multi-Agent Transitional Care Management (TCM) POC

A multi-agent care management system that automates post-discharge Transitional Care Management for a health plan. Cases flow through a fixed pipeline of specialist agents, with state persisted to Postgres between every hop. Straight-through cases run autonomously; complex cases escalate to a human Case Manager.

> **Status:** Step 1 of 15 complete (project scaffold). See [BUILD_LOG.md](BUILD_LOG.md) for progress.

## Architecture at a glance

```
HL7/FHIR discharge event
        │
        ▼
┌──────────────────────┐
│ orchestration_agent  │  ← polls cases, routes by state, enforces transitions | Varun
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│ admission_risk_agent │  Impactability + Intervenability + Composite Priority | Lahari
└──────────┬───────────┘
           ▼
┌────────────────────────────┐
│ document_extraction_agent  │  Discharge summary → per-field confidence | Shreya
└──────────┬─────────────────┘
           ▼
    ╔═══════════════╗
    ║  HUMAN GATE   ║  clinician approves + authorizes outreach (SLA 4h) | Varun
    ╚═══════╤═══════╝
            ▼
┌──────────────────────┐
│ outreach_agent       │  async messaging: identity → check-in → CMP pitch → SDOH | Shreya
└──────────┬───────────┘
           ▼
┌──────────────────────┐
│ agent_assist_agent   │  real-time co-pilot during live CM voice callback | Varun
└──────────┬───────────┘
           ▼
┌──────────────────────┐
│ scheduling_agent     │  verbal-consent-gated mid-call PCP booking | Lahari
└──────────┬───────────┘
           ▼
┌──────────────────────┐
│ compliance_agent     │  post-closure deterministic audit | [Any]
└──────────────────────┘

communication_agent: event-driven (SMS / email / webhook) at every milestone.
```

All state lives in the `cases` table. Agents never call each other in-process — the orchestrator dispatches based on `current_state`. Allowed transitions are enforced in [models/schemas.py](models/schemas.py) (`ALLOWED_TRANSITIONS`).

## Prerequisites

- Windows + PowerShell 5.1 (target dev env)
- Python 3.11+
- Postgres 15+ with the `pgvector` extension
- AWS credentials with access to Amazon Bedrock (Claude Haiku 4.5 + Titan v2 embeddings)
- (Optional) GTK3 runtime for WeasyPrint PDF rendering

## Quick start

```powershell
# from project root — uses uv (https://github.com/astral-sh/uv)
uv venv hh --python 3.11
.\hh\Scripts\Activate.ps1
uv pip install -r requirements.txt
Copy-Item .env.example .env
# edit .env: set DATABASE_URL, BEDROCK_REGION, and AWS credentials

# Step 2+ will add: schema bootstrap, knowledge ingestion, and uvicorn launch
```

> Postgres can be a local install or a Neon serverless DB. Either way the connection string goes in `.env` as `DATABASE_URL=...`. For Neon, keep the `?sslmode=require&channel_binding=require` query params.

See [USAGE.md](USAGE.md) for run instructions as the build progresses, and [workflow.md](workflow.md) for the full PowerShell walkthrough.

## Project layout

```
project/
├── agents.md, skills.md, README.md, BUILD_LOG.md, HANDOFF.md,
│   DEFERRED.md, workflow.md, USAGE.md
├── .env.example, .gitignore, requirements.txt
├── agents/              one .py per agent (orchestrator + 7 specialists)
├── skills/              deterministic @tool functions + _common.py
├── models/              schemas.py (Pydantic + enums + ALLOWED_TRANSITIONS), exceptions.py
├── api/
│   ├── main.py          FastAPI app + lifespan-managed daemons
│   └── routes/          one file per resource
├── config/              stp_rules.py, priority_tiers.py, sdoh_flags.py, high_risk_dx.csv
├── db/
│   ├── schema.sql       idempotent DDL
│   └── migrations/      reserved for Alembic (currently unused)
├── knowledge/tcm_guidelines/   markdown chunks for RAG over TCM clinical guidance
├── data/{documents,samples}/   sample discharge summaries + seed JSON
├── templates/           Jinja2 per artifact (care plan, appt confirmation, CMP welcome)
├── scripts/             ingest_knowledge.py, seed_data.py
└── agent_prompts/       per-agent spec handed to each teammate (01–07)
```

## Tech stack

- **Runtime:** FastAPI + uvicorn (single process; orchestrator + comms daemons via lifespan)
- **Agents:** Strands Agents SDK
- **LLM:** Claude Haiku 4.5 on Amazon Bedrock (default `BEDROCK_MODEL_ID=us.anthropic.claude-haiku-4-5-20251001-v1:0`)
- **Embeddings:** Amazon Titan v2 (1024 dims) into Postgres + pgvector with HNSW index
- **Models:** Pydantic v2 (string-valued enums matching DB enums)
- **DB driver:** psycopg with connection pool; idempotent DDL in [db/schema.sql](db/schema.sql)
- **Observability:** structlog (PII redaction enforced)
- **PDFs:** Jinja2 + WeasyPrint
- **OCR / extraction:** Unstructured + Tesseract
- **Comms:** aiosmtplib (SMTP-off default), Twilio stub (default)

## Working conventions

- **Doc-driven contracts.** [agents.md](agents.md) and [skills.md](skills.md) are updated *before* code changes.
- **Skills are deterministic.** No LLM calls in `skills/`. Reasoning lives in agents.
- **State machine in DB, not memory.** All hand-off via `cases` state + audit log.
- **Idempotent agents.** Each agent reads current state on entry and exits cleanly if already past.
- **Mocks are honest.** Every stubbed external integration is marked `# MOCK:` with a TODO naming the real system.

## Build order

15-step build laid out in `BUILD_PROMPT_v2.md`. Current status: see [BUILD_LOG.md](BUILD_LOG.md) "At a glance" table.

Agents 01, 02, 03, 04, 05, 06, 07 are scaffolded as stubs that walk the John Martinez sample case through all states end-to-end. Each stub references its full spec in [agent_prompts/](agent_prompts/), which is what the assigned teammate replaces with a real implementation. When a teammate's PR lands, the orchestrator routes through the real agent automatically — no other code changes needed.

## Open business questions

See [agents.md](agents.md) §"Open business questions" and [DEFERRED.md](DEFERRED.md).
