# USAGE

> User-facing "how to run this thing." Short, hands-on, no architecture deep-dives — those live in [README.md](README.md).

## Run the API

```powershell
.\hh\Scripts\Activate.ps1
uvicorn api.main:app --reload --port 8000
```

- Swagger UI: http://localhost:8000/docs
- Health: http://localhost:8000/health
- The orchestrator polling loop starts automatically (set `ORCHESTRATOR_ENABLED=false` in `.env` to disable).

## Trigger a case

```powershell
$body = @{
  member_id          = "MBR-99000001"
  facility           = "St. Mary's Medical Center"
  discharge_date     = "2026-11-03"
  primary_dx_code    = "J44.1"
} | ConvertTo-Json
Invoke-RestMethod -Method POST -Uri "http://localhost:8000/cases/intake" `
  -Body $body -ContentType "application/json"
```

Duplicate intake (same `member_id + facility + discharge_date`) → 409 with `existing_case_id`.

## Walk a sample case through the pipeline

Once submitted, the orchestrator picks the case up on its 5-second timer. To skip the wait, force a tick:

```powershell
$h = @{ "X-Admin-Token" = "<value of ADMIN_TOKEN in .env>" }
Invoke-RestMethod -Method POST -Headers $h `
  -Uri "http://localhost:8000/admin/orchestrator/tick?limit=10"
```

Inspect:

```powershell
Invoke-RestMethod "http://localhost:8000/cases/CASE-00099999" | ConvertTo-Json -Depth 8
```

You'll see the case, the populated `risk_scores`, the `audit_log` trail, and any `extracted_fields`, `referrals`, `compliance_findings`.

## Reviewer queue

```powershell
Invoke-RestMethod "http://localhost:8000/clinician/queue" | ConvertTo-Json -Depth 5
```

Returns the list of cases currently in `DOCUMENT_PENDING_REVIEW` with `flagged_count` and `total_fields` per case so the UI can prioritize. Once the clinician acts, POST the decision:

```powershell
$review = @{
  reviewer_id = "clinician.sarah@example.com"
  outcome     = "approve"   # or "reject" -> ESCALATED, "escalate" -> ESCALATED
  comments    = "Medication taper confirmed. Authorize outreach."
} | ConvertTo-Json
Invoke-RestMethod -Method POST -ContentType "application/json" `
  -Uri "http://localhost:8000/cases/CASE-00099999/review" -Body $review
```

On `approve`, the case lands in `DOCUMENT_APPROVED`; the orchestrator's next tick auto-transitions it to `OUTREACH_SCHEDULED` and the tick after that dispatches `outreach_agent` to `OUTREACH_COMPLETE`.
