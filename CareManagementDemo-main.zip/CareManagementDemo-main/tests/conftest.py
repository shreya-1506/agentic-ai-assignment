"""Shared pytest fixtures.

The Care Management POC talks to Postgres via async psycopg, Bedrock via
boto3, and a couple of mocked external services. The test suite for the
document_extraction_agent does NOT touch any of those: we mock the DB
helpers + the Bedrock skill at the agent boundary so the tests are fast,
deterministic, and run offline.
"""

from __future__ import annotations

import contextlib
import sys
from datetime import date
from pathlib import Path

import pytest

# Make the project root importable when pytest is invoked from any cwd.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


@pytest.fixture
def john_martinez_case():
    """Return a `Case` row matching the POC's seeded John Martinez."""
    from models.schemas import Case, CaseState

    return Case(
        case_id="CASE-00099999",
        member_id="MBR-00847291",
        current_state=CaseState.RISK_STRATIFIED,
        discharge_facility="St. Mary's Medical Center",
        discharge_date=date(2026, 10, 5),
        admit_date=date(2026, 10, 2),
        length_of_stay=3,
        primary_dx_code="J44.1",
        primary_dx_description="COPD with acute exacerbation",
        attending_physician="Dr. Priya Patel",
        plan_name="BlueCross Premier",
    )


@pytest.fixture
def fake_connection(monkeypatch):
    """A no-op async connection that satisfies the helpers we patch.

    We patch the helpers (`get_case`, `insert_extracted_fields`, ...) so the
    connection object is never actually used. We still need `db.pool.connection`
    to be an async context manager that yields *something* so the agent's
    `async with connection() as conn:` blocks don't blow up.
    """

    class _FakeTxn:
        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

    class _FakeConn:
        def transaction(self):
            # psycopg's `AsyncConnection.transaction()` returns an async
            # context manager (NOT a coroutine), and the agent uses it as
            # `async with conn.transaction(): ...`.
            return _FakeTxn()

    @contextlib.asynccontextmanager
    async def _connection():
        yield _FakeConn()

    # Patch at every callsite agents/document_extraction_agent.py uses:
    monkeypatch.setattr(
        "agents.document_extraction_agent.connection",
        _connection,
    )
    return _FakeConn
