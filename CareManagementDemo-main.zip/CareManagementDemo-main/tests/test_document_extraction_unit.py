"""Unit tests for `document_extraction_agent` building blocks.

No DB. No Bedrock. Pure-Python paths only:
  - config.extraction constants
  - skills.documents JSON parsing + payload normalization
  - agent's flag-aggregation helpers
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from agents.document_extraction_agent import (
    _build_extraction_flags,
    _reason_for_flag,
    _TIER_BY_FIELD,
)
from config.extraction import (
    EXPECTED_FIELD_NAMES,
    EXPECTED_FIELDS,
    EXTRACTION_SYSTEM_PROMPT,
    LOW_CONFIDENCE_THRESHOLD,
    MAX_DOCUMENT_FETCH_ATTEMPTS,
)
from models.schemas import ExtractedField
from skills import documents as documents_skill
from skills._fixtures import JOHN_MARTINEZ_EXTRACTED_FIELDS


# =============================================================================
# config.extraction sanity
# =============================================================================


class TestConfigExtraction:
    def test_threshold_is_080(self):
        assert LOW_CONFIDENCE_THRESHOLD == 0.80

    def test_max_fetch_attempts_is_2(self):
        # Spec: "after 2 attempts, escalate"
        assert MAX_DOCUMENT_FETCH_ATTEMPTS == 2

    def test_thirteen_expected_fields(self):
        assert len(EXPECTED_FIELDS) == 13
        assert len(EXPECTED_FIELD_NAMES) == 13

    def test_expected_field_names_match_spec(self):
        # Order matters -- the LLM extractor returns rows in this order.
        assert EXPECTED_FIELD_NAMES == (
            "medical_center",
            "patient_name",
            "mrn",
            "admit_date",
            "discharge_date",
            "length_of_stay",
            "attending_physician",
            "primary_diagnosis",
            "hand_off_summary",
            "reason_for_hospitalization",
            "medication_changes",
            "last_spo2",
            "discharge_disposition",
        )

    def test_medication_changes_is_low_tier(self):
        med = next(f for f in EXPECTED_FIELDS if f.name == "medication_changes")
        assert med.tier == "low"
        assert med.expected_high <= 0.80

    def test_high_tier_fields_have_high_confidence_bounds(self):
        for f in EXPECTED_FIELDS:
            if f.tier == "high":
                assert f.expected_low >= 0.90, f"{f.name} expected_low={f.expected_low}"

    def test_prompt_mentions_all_fields(self):
        for name in EXPECTED_FIELD_NAMES:
            assert name in EXTRACTION_SYSTEM_PROMPT, f"missing {name} in prompt"

    def test_prompt_includes_confidence_rubric(self):
        assert "0.95" in EXTRACTION_SYSTEM_PROMPT  # high band
        assert "0.70" in EXTRACTION_SYSTEM_PROMPT  # low band


# =============================================================================
# skills.documents.parse_pdf
# =============================================================================


class TestParsePdf:
    def test_reads_markdown_standin(self, tmp_path: Path):
        p = tmp_path / "doc.md"
        p.write_text("# Discharge Summary\n\nPatient: J. Doe\n", encoding="utf-8")

        text = documents_skill.parse_pdf("CASE-T1", p)
        assert "Discharge Summary" in text
        assert "J. Doe" in text

    def test_missing_file_raises_document_not_found(self, tmp_path: Path):
        from models.exceptions import DocumentNotFound

        with pytest.raises(DocumentNotFound):
            documents_skill.parse_pdf("CASE-T2", tmp_path / "nope.pdf")


# =============================================================================
# skills.documents.extract_fields  (deterministic mock / fallback)
# =============================================================================


class TestExtractFieldsMock:
    def test_returns_13_fields(self):
        fields = documents_skill.extract_fields("CASE-T3", "any text")
        assert len(fields) == 13

    def test_exactly_one_flagged_medication_changes(self):
        fields = documents_skill.extract_fields("CASE-T3", "any text")
        flagged = [f for f in fields if f.flagged]
        assert len(flagged) == 1
        assert flagged[0].field_name == "medication_changes"
        assert flagged[0].confidence < LOW_CONFIDENCE_THRESHOLD

    def test_field_names_match_fixture(self):
        fields = documents_skill.extract_fields("CASE-T3", "any text")
        assert {f.field_name for f in fields} == {
            f["field_name"] for f in JOHN_MARTINEZ_EXTRACTED_FIELDS
        }

    def test_includes_last_spo2_and_discharge_disposition(self):
        names = {f.field_name for f in documents_skill.extract_fields("CASE-T3", "x")}
        assert "last_spo2" in names
        assert "discharge_disposition" in names


# =============================================================================
# skills.documents JSON parsing helpers
# =============================================================================


class TestJsonParsing:
    @staticmethod
    def _well_formed_payload() -> dict:
        return {
            name: {
                "value": "stub" if name != "length_of_stay" else 3,
                "confidence": 0.97,
                "reason": "verbatim",
            }
            for name in EXPECTED_FIELD_NAMES
        }

    def test_parse_plain_json(self):
        raw = json.dumps(self._well_formed_payload())
        out = documents_skill._parse_extractor_json("CASE-T4", raw)
        assert isinstance(out, dict)
        assert set(out.keys()) == set(EXPECTED_FIELD_NAMES)

    def test_parse_strips_code_fences(self):
        raw = "```json\n" + json.dumps(self._well_formed_payload()) + "\n```"
        out = documents_skill._parse_extractor_json("CASE-T4", raw)
        assert "medical_center" in out

    def test_parse_handles_leading_prose(self):
        raw = "Here is the JSON you asked for:\n" + json.dumps(
            self._well_formed_payload()
        )
        out = documents_skill._parse_extractor_json("CASE-T4", raw)
        assert "medical_center" in out

    def test_parse_empty_raises(self):
        with pytest.raises(documents_skill.ExtractionParseError):
            documents_skill._parse_extractor_json("CASE-T4", "")

    def test_parse_malformed_raises(self):
        with pytest.raises(documents_skill.ExtractionParseError):
            documents_skill._parse_extractor_json("CASE-T4", "{not real json")

    def test_payload_to_fields_returns_one_per_expected_field(self):
        payload = self._well_formed_payload()
        rows = documents_skill._payload_to_fields("CASE-T4", payload)
        assert len(rows) == len(EXPECTED_FIELD_NAMES)
        assert [r.field_name for r in rows] == list(EXPECTED_FIELD_NAMES)

    def test_payload_to_fields_marks_missing_as_flagged_zero_confidence(self):
        payload = self._well_formed_payload()
        del payload["mrn"]
        rows = documents_skill._payload_to_fields("CASE-T4", payload)
        mrn_row = next(r for r in rows if r.field_name == "mrn")
        assert mrn_row.value is None
        assert mrn_row.confidence == 0.0
        assert mrn_row.flagged is True

    def test_payload_stringifies_list_values(self):
        payload = self._well_formed_payload()
        payload["medication_changes"] = {
            "value": [
                {"name": "Prednisone", "dose": "40mg", "instructions": "taper 14d"}
            ],
            "confidence": 0.74,
            "reason": "OCR noise on dose",
        }
        rows = documents_skill._payload_to_fields("CASE-T5", payload)
        med = next(r for r in rows if r.field_name == "medication_changes")
        assert isinstance(med.value, str)
        # Round-trip to verify it's valid JSON
        parsed = json.loads(med.value)
        assert parsed[0]["name"] == "Prednisone"
        assert med.flagged is True   # 0.74 < 0.80

    def test_payload_clamps_confidence_out_of_range(self):
        payload = self._well_formed_payload()
        payload["mrn"] = {"value": "MRN-1", "confidence": 1.5, "reason": "x"}
        payload["patient_name"] = {
            "value": "Anon",
            "confidence": -0.2,
            "reason": "x",
        }
        rows = documents_skill._payload_to_fields("CASE-T6", payload)
        mrn_row = next(r for r in rows if r.field_name == "mrn")
        name_row = next(r for r in rows if r.field_name == "patient_name")
        assert mrn_row.confidence == 1.0
        assert name_row.confidence == 0.0

    def test_payload_to_fields_flags_below_threshold(self):
        payload = self._well_formed_payload()
        payload["last_spo2"] = {"value": "93%", "confidence": 0.79, "reason": "noise"}
        rows = documents_skill._payload_to_fields("CASE-T7", payload)
        spo2 = next(r for r in rows if r.field_name == "last_spo2")
        assert spo2.flagged is True

    def test_payload_to_fields_does_not_flag_at_or_above_threshold(self):
        payload = self._well_formed_payload()
        payload["last_spo2"] = {"value": "93%", "confidence": 0.80, "reason": "ok"}
        rows = documents_skill._payload_to_fields("CASE-T8", payload)
        spo2 = next(r for r in rows if r.field_name == "last_spo2")
        assert spo2.flagged is False


# =============================================================================
# agent flag-aggregation helpers
# =============================================================================


def _field(name: str, confidence: float, *, flagged: bool, bbox=None) -> ExtractedField:
    return ExtractedField(
        case_id="CASE-T9",
        field_name=name,
        value="x",
        confidence=confidence,
        flagged=flagged,
        source_bbox=bbox,
    )


class TestBuildExtractionFlags:
    def test_returns_only_flagged(self):
        fields = [
            _field("medical_center", 0.98, flagged=False),
            _field("mrn", 0.97, flagged=False),
            _field(
                "medication_changes",
                0.72,
                flagged=True,
                bbox={"reason": "ambiguous dose"},
            ),
        ]
        flags = _build_extraction_flags(fields)
        assert len(flags) == 1
        assert flags[0]["field"] == "medication_changes"

    def test_each_flag_carries_confidence_reason_tier(self):
        fields = [
            _field(
                "medication_changes",
                0.72,
                flagged=True,
                bbox={"reason": "ambiguous dose"},
            ),
        ]
        flag = _build_extraction_flags(fields)[0]
        assert flag["confidence"] == 0.72
        assert flag["reason"] == "ambiguous dose"
        assert flag["tier"] == _TIER_BY_FIELD["medication_changes"]

    def test_falls_back_to_generic_reason_when_llm_silent(self):
        fields = [
            _field("last_spo2", 0.55, flagged=True, bbox=None),
        ]
        flag = _build_extraction_flags(fields)[0]
        assert "threshold" in flag["reason"]

    def test_empty_when_no_fields_flagged(self):
        fields = [
            _field("medical_center", 0.99, flagged=False),
        ]
        assert _build_extraction_flags(fields) == []

    def test_reason_helper_prefers_llm_reason(self):
        f = _field("mrn", 0.5, flagged=True, bbox={"reason": "multiple candidates"})
        assert _reason_for_flag(f) == "multiple candidates"

    def test_reason_helper_falls_back_when_reason_missing(self):
        f = _field("mrn", 0.5, flagged=True, bbox={})
        assert "threshold" in _reason_for_flag(f)

    def test_reason_helper_falls_back_when_bbox_none(self):
        f = _field("mrn", 0.5, flagged=True, bbox=None)
        assert "threshold" in _reason_for_flag(f)
