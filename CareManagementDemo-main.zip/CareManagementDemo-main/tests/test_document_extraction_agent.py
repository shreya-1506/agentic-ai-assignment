"""Integration tests for `document_extraction_agent.run`.

The orchestrator's `run(case_id)` contract is the boundary we test. We mock:
  - the DB pool + helpers so no Postgres is needed
  - the EHR + documents skills so no FS / Bedrock is needed

The "happy path" exercises both the John Martinez fixture (mock fallback)
and an injected LLM-shaped response. The retry path exercises the
escalation transition after 2 failed fetches. The idempotency path
verifies a re-entry past `RISK_STRATIFIED` is a no-op.
"""

from __future__ import annotations

import json
from datetime import date
from pathlib import Path

import pytest

from agents import document_extraction_agent as agent
from config.extraction import EXPECTED_FIELD_NAMES, MAX_DOCUMENT_FETCH_ATTEMPTS
from models.exceptions import DocumentNotFound, BedrockError
from models.schemas import Case, CaseState, ExtractedField


# =============================================================================
# Helpers: in-memory stand-ins for the DB helpers the agent imports
# =============================================================================


class _FakeDb:
    """A tiny in-memory mirror of the DB helpers `agents/document_extraction_agent.py` calls.

    Every helper the agent imports from `db.state_io` / `db.state` is replaced
    by a method on this class so we can assert behavior (state transitions,
    persisted fields, denormalized columns) without spinning up Postgres.
    """

    def __init__(self, case: Case):
        self.case = case
        self.extracted_fields: list[ExtractedField] = []
        self.state_transitions: list[dict] = []
        self.case_field_updates: list[dict] = []

    async def get_case(self, _conn, case_id: str) -> Case | None:
        if case_id != self.case.case_id:
            return None
        return self.case

    async def list_extracted_fields(self, _conn, case_id: str) -> list[ExtractedField]:
        return list(self.extracted_fields)

    async def insert_extracted_fields(
        self, _conn, fields: list[ExtractedField]
    ) -> None:
        self.extracted_fields.extend(fields)

    async def update_case_fields(
        self, _conn, case_id: str, fields: dict
    ) -> None:
        self.case_field_updates.append({"case_id": case_id, **fields})
        # Mirror onto the in-memory case so subsequent reads see the update.
        for k, v in fields.items():
            setattr(self.case, k, v)

    async def update_case_state(
        self,
        _conn,
        case_id: str,
        new_state: CaseState,
        *,
        agent_name: str,
        reason: str,
        metadata: dict | None = None,
    ) -> Case:
        self.state_transitions.append(
            {
                "case_id": case_id,
                "from_state": self.case.current_state,
                "to_state": new_state,
                "agent_name": agent_name,
                "reason": reason,
                "metadata": metadata or {},
            }
        )
        self.case = self.case.model_copy(update={"current_state": new_state})
        return self.case


@pytest.fixture
def fake_db(john_martinez_case, monkeypatch, fake_connection):
    """Install the in-memory DB into the agent module."""
    db = _FakeDb(john_martinez_case)
    monkeypatch.setattr(agent, "get_case", db.get_case)
    monkeypatch.setattr(agent, "list_extracted_fields", db.list_extracted_fields)
    monkeypatch.setattr(
        agent, "insert_extracted_fields", db.insert_extracted_fields
    )
    monkeypatch.setattr(agent, "update_case_fields", db.update_case_fields)
    monkeypatch.setattr(agent, "update_case_state", db.update_case_state)
    return db


@pytest.fixture
def mock_document(monkeypatch, tmp_path: Path):
    """Patch the ehr/documents skills to read a markdown stand-in from disk."""
    p = tmp_path / "doc.md"
    p.write_text("# Discharge Summary\n\nPatient: J. Doe", encoding="utf-8")

    def _fetch(case_id, member_id, discharge_date):
        return p

    monkeypatch.setattr(agent.ehr_skill, "fetch_discharge_summary", _fetch)
    return p


def _well_formed_llm_payload() -> dict:
    """A complete LLM-shaped payload covering all 13 fields."""
    payload = {
        name: {
            "value": f"value-for-{name}",
            "confidence": 0.97,
            "reason": "verbatim match in source",
        }
        for name in EXPECTED_FIELD_NAMES
    }
    # Override medication_changes to look realistic + flag as low-confidence.
    payload["medication_changes"] = {
        "value": [
            {"name": "Prednisone", "dose": "40mg", "instructions": "taper 14d"},
            {"name": "Albuterol", "dose": "90mcg", "instructions": "PRN"},
            {"name": "Tiotropium", "dose": "18mcg", "instructions": "daily"},
            {"name": "Azithromycin", "dose": "500mg", "instructions": "x5d"},
        ],
        "confidence": 0.73,
        "reason": "OCR noise on prednisone dose; multiple candidates",
    }
    payload["last_spo2"] = {
        "value": "93% on room air (Day 3)",
        "confidence": 0.90,
        "reason": "explicit in hand-off summary",
    }
    return payload


# =============================================================================
# Happy path - LLM extraction succeeds
# =============================================================================


class TestHappyPathLlm:
    async def test_extracts_all_13_fields(
        self, fake_db, mock_document, monkeypatch
    ):
        def _llm_ok(case_id, text, **_kwargs):
            return agent.documents_skill._payload_to_fields(
                case_id, _well_formed_llm_payload()
            )

        monkeypatch.setattr(
            agent.documents_skill, "extract_fields_llm", _llm_ok
        )

        await agent.run("CASE-00099999")

        assert len(fake_db.extracted_fields) == 13
        names = [f.field_name for f in fake_db.extracted_fields]
        assert names == list(EXPECTED_FIELD_NAMES)

    async def test_medication_changes_is_flagged(
        self, fake_db, mock_document, monkeypatch
    ):
        def _llm_ok(case_id, text, **_kwargs):
            return agent.documents_skill._payload_to_fields(
                case_id, _well_formed_llm_payload()
            )

        monkeypatch.setattr(agent.documents_skill, "extract_fields_llm", _llm_ok)

        await agent.run("CASE-00099999")

        flagged = [f for f in fake_db.extracted_fields if f.flagged]
        assert len(flagged) >= 1
        assert any(f.field_name == "medication_changes" for f in flagged)

    async def test_state_transitions_to_document_pending_review(
        self, fake_db, mock_document, monkeypatch
    ):
        def _llm_ok(case_id, text, **_kwargs):
            return agent.documents_skill._payload_to_fields(
                case_id, _well_formed_llm_payload()
            )

        monkeypatch.setattr(agent.documents_skill, "extract_fields_llm", _llm_ok)

        await agent.run("CASE-00099999")

        assert len(fake_db.state_transitions) == 1
        trans = fake_db.state_transitions[0]
        assert trans["from_state"] == CaseState.RISK_STRATIFIED
        assert trans["to_state"] == CaseState.DOCUMENT_PENDING_REVIEW
        assert trans["agent_name"] == "document_extraction_agent"

    async def test_extraction_flags_persisted_on_case(
        self, fake_db, mock_document, monkeypatch
    ):
        def _llm_ok(case_id, text, **_kwargs):
            return agent.documents_skill._payload_to_fields(
                case_id, _well_formed_llm_payload()
            )

        monkeypatch.setattr(agent.documents_skill, "extract_fields_llm", _llm_ok)

        await agent.run("CASE-00099999")

        # The agent writes extraction_flags + is_stp before transitioning.
        assert fake_db.case_field_updates, "expected update_case_fields call"
        update = fake_db.case_field_updates[-1]
        assert "extraction_flags" in update
        assert "is_stp" in update
        flags = update["extraction_flags"]
        assert isinstance(flags, list)
        assert any(f["field"] == "medication_changes" for f in flags)
        # Schema: each flag entry must have field, confidence, reason
        for f in flags:
            assert "field" in f
            assert "confidence" in f
            assert "reason" in f

    async def test_is_stp_is_false_per_business_placeholder(
        self, fake_db, mock_document, monkeypatch
    ):
        def _llm_ok(case_id, text, **_kwargs):
            return agent.documents_skill._payload_to_fields(
                case_id, _well_formed_llm_payload()
            )

        monkeypatch.setattr(agent.documents_skill, "extract_fields_llm", _llm_ok)

        await agent.run("CASE-00099999")

        assert fake_db.case_field_updates[-1]["is_stp"] is False


# =============================================================================
# LLM failure - exceptions propagate to the orchestrator (no silent fallback)
# =============================================================================


class TestLlmFailurePropagates:
    """The agent must NOT silently fall back to the deterministic mock on
    Bedrock failure or JSON-parse failure. Those exceptions propagate so the
    orchestrator's retry-then-escalate policy runs and on-call sees the
    outage. Nothing is persisted, and the state does NOT advance.
    """

    async def test_bedrock_error_propagates(
        self, fake_db, mock_document, monkeypatch
    ):
        def _llm_boom(*_args, **_kwargs):
            raise BedrockError("region unreachable", case_id="CASE-00099999")

        monkeypatch.setattr(
            agent.documents_skill, "extract_fields_llm", _llm_boom
        )

        with pytest.raises(BedrockError):
            await agent.run("CASE-00099999")

        # Nothing persisted, state not advanced -- the orchestrator's retry
        # policy will re-dispatch us, or escalate after MAX_RETRIES.
        assert fake_db.extracted_fields == []
        assert fake_db.state_transitions == []

    async def test_parse_error_propagates(
        self, fake_db, mock_document, monkeypatch
    ):
        def _llm_garbage(case_id, *_args, **_kwargs):
            raise agent.documents_skill.ExtractionParseError(
                "bad JSON", case_id=case_id
            )

        monkeypatch.setattr(
            agent.documents_skill, "extract_fields_llm", _llm_garbage
        )

        with pytest.raises(agent.documents_skill.ExtractionParseError):
            await agent.run("CASE-00099999")

        assert fake_db.extracted_fields == []
        assert fake_db.state_transitions == []

    async def test_mock_extractor_not_invoked_on_failure(
        self, fake_db, mock_document, monkeypatch
    ):
        """Belt-and-suspenders: verify the deterministic mock extractor is
        NEVER called as a fallback path inside the agent."""
        def _llm_boom(*_args, **_kwargs):
            raise BedrockError("offline", case_id="CASE-00099999")

        mock_called: list[int] = []

        def _mock_should_not_run(*_args, **_kwargs):
            mock_called.append(1)
            raise AssertionError("mock extractor must not run as a fallback")

        monkeypatch.setattr(
            agent.documents_skill, "extract_fields_llm", _llm_boom
        )
        monkeypatch.setattr(
            agent.documents_skill, "extract_fields", _mock_should_not_run
        )

        with pytest.raises(BedrockError):
            await agent.run("CASE-00099999")

        assert mock_called == []


# =============================================================================
# Failure path - document fetch exhausts retries
# =============================================================================


class TestDocumentFetchEscalation:
    async def test_escalates_after_max_attempts(
        self, fake_db, monkeypatch
    ):
        calls: list[int] = []

        def _always_404(case_id, member_id, discharge_date):
            calls.append(1)
            raise DocumentNotFound(
                f"no doc for {member_id}", case_id=case_id
            )

        monkeypatch.setattr(
            agent.ehr_skill, "fetch_discharge_summary", _always_404
        )

        await agent.run("CASE-00099999")

        assert len(calls) == MAX_DOCUMENT_FETCH_ATTEMPTS
        # The agent transitioned to ESCALATED instead of DOCUMENT_PENDING_REVIEW
        assert fake_db.state_transitions[-1]["to_state"] == CaseState.ESCALATED
        assert "fetch failed" in fake_db.state_transitions[-1]["reason"]

    async def test_no_fields_persisted_when_fetch_fails(
        self, fake_db, monkeypatch
    ):
        def _always_404(case_id, member_id, discharge_date):
            raise DocumentNotFound("nope", case_id=case_id)

        monkeypatch.setattr(
            agent.ehr_skill, "fetch_discharge_summary", _always_404
        )

        await agent.run("CASE-00099999")
        assert fake_db.extracted_fields == []

    async def test_succeeds_on_second_attempt(
        self, fake_db, mock_document, monkeypatch
    ):
        # Wrap the working fetch with a one-shot failure on the first call.
        original_fetch = agent.ehr_skill.fetch_discharge_summary
        calls: list[int] = []

        def _flaky(case_id, member_id, discharge_date):
            calls.append(1)
            if len(calls) == 1:
                raise DocumentNotFound("transient", case_id=case_id)
            return original_fetch(case_id, member_id, discharge_date)

        monkeypatch.setattr(agent.ehr_skill, "fetch_discharge_summary", _flaky)

        # Stub the LLM extractor so we don't reach Bedrock; agent.run still
        # walks the full success path (fetch -> parse -> extract -> persist
        # -> transition) once the second fetch attempt succeeds.
        def _llm_ok(case_id, text, **_kwargs):
            return agent.documents_skill._payload_to_fields(
                case_id, _well_formed_llm_payload()
            )

        monkeypatch.setattr(agent.documents_skill, "extract_fields_llm", _llm_ok)

        await agent.run("CASE-00099999")

        assert len(calls) == 2
        assert (
            fake_db.state_transitions[-1]["to_state"]
            == CaseState.DOCUMENT_PENDING_REVIEW
        )


# =============================================================================
# Idempotency
# =============================================================================


class TestIdempotency:
    async def test_already_past_input_state_is_no_op(
        self, john_martinez_case, monkeypatch, fake_connection
    ):
        already_past = john_martinez_case.model_copy(
            update={"current_state": CaseState.DOCUMENT_PENDING_REVIEW}
        )
        db = _FakeDb(already_past)
        monkeypatch.setattr(agent, "get_case", db.get_case)
        monkeypatch.setattr(
            agent, "list_extracted_fields", db.list_extracted_fields
        )
        monkeypatch.setattr(
            agent, "insert_extracted_fields", db.insert_extracted_fields
        )
        monkeypatch.setattr(agent, "update_case_fields", db.update_case_fields)
        monkeypatch.setattr(agent, "update_case_state", db.update_case_state)

        await agent.run("CASE-00099999")

        assert db.extracted_fields == []
        assert db.state_transitions == []

    async def test_existing_fields_skip_reextraction(
        self, fake_db, mock_document, monkeypatch
    ):
        # Pre-seed the in-memory DB so list_extracted_fields returns rows.
        seed_payload = _well_formed_llm_payload()
        seeded = agent.documents_skill._payload_to_fields(
            "CASE-00099999", seed_payload
        )
        fake_db.extracted_fields = list(seeded)
        seeded_count = len(seeded)

        # Make the LLM blow up if it ever gets called -- we should not re-extract.
        def _should_not_run(*_args, **_kwargs):
            raise AssertionError("LLM should not be called on re-entry")

        monkeypatch.setattr(
            agent.documents_skill, "extract_fields_llm", _should_not_run
        )
        # Same for the fallback mock.
        monkeypatch.setattr(
            agent.documents_skill,
            "extract_fields",
            lambda *a, **kw: (_ for _ in ()).throw(
                AssertionError("fallback should not be called on re-entry")
            ),
        )
        # ...and the document fetch shouldn't happen either.
        monkeypatch.setattr(
            agent.ehr_skill,
            "fetch_discharge_summary",
            lambda *a, **kw: (_ for _ in ()).throw(
                AssertionError("doc fetch should not be called on re-entry")
            ),
        )

        await agent.run("CASE-00099999")

        # No new rows inserted, but state still advanced.
        assert len(fake_db.extracted_fields) == seeded_count
        assert fake_db.state_transitions[-1]["to_state"] == (
            CaseState.DOCUMENT_PENDING_REVIEW
        )


# =============================================================================
# Unknown case
# =============================================================================


class TestUnknownCase:
    async def test_raises_case_not_found(
        self, monkeypatch, fake_connection
    ):
        from models.exceptions import CaseNotFound

        async def _no_case(_conn, _case_id):
            return None

        monkeypatch.setattr(agent, "get_case", _no_case)

        with pytest.raises(CaseNotFound):
            await agent.run("CASE-NO-EXIST")
