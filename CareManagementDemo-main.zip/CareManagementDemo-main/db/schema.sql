-- =============================================================================
-- TCM POC — Postgres schema (idempotent)
-- =============================================================================
-- Tested against Postgres 15+ with pgvector. Compatible with Neon.
-- Every statement is safe to re-run; enum creation uses DO-blocks to avoid
-- "type already exists" errors.
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS vector;

-- ---- Enum types -------------------------------------------------------------

DO $$ BEGIN
    CREATE TYPE case_state AS ENUM (
        'DISCHARGE_RECEIVED',
        'RISK_STRATIFIED',
        'DOCUMENT_PENDING_REVIEW',
        'DOCUMENT_APPROVED',
        'OUTREACH_SCHEDULED',
        'OUTREACH_COMPLETE',
        'CM_CALLBACK_IN_PROGRESS',
        'APPOINTMENT_BOOKED',
        'CARE_GOALS_MET',
        'CLOSED_NO_CONTACT',
        'CLOSED_MEMBER_DECLINED',
        'ESCALATED'
    );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE priority_tier AS ENUM ('low', 'medium', 'high');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE reviewer_outcome AS ENUM ('approve', 'reject', 'escalate');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE compliance_severity AS ENUM ('pass', 'warn', 'fail');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE outreach_channel AS ENUM ('messaging', 'sms', 'whatsapp');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE outreach_status AS ENUM ('queued', 'in_progress', 'complete', 'expired');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE call_status AS ENUM ('pending', 'in_progress', 'complete');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE appointment_status AS ENUM ('booked', 'cancelled', 'completed');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE resource_type AS ENUM ('device', 'service', 'transport', 'other');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE resource_source AS ENUM ('community', 'plan', 'self');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE referral_status AS ENUM ('created', 'confirmed', 'received', 'na');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;


-- ---- members ----------------------------------------------------------------

CREATE TABLE IF NOT EXISTS members (
    member_id           TEXT PRIMARY KEY,                       -- format MBR-NNNNNNNN
    first_name          TEXT NOT NULL,
    last_name           TEXT NOT NULL,
    dob                 DATE NOT NULL,
    phone               TEXT NOT NULL,
    email               TEXT,
    preferred_language  TEXT NOT NULL DEFAULT 'English',
    plan_name           TEXT NOT NULL,
    pcp_name            TEXT,
    pcp_id              TEXT,
    address             JSONB,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);


-- ---- cases ------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS cases (
    case_id                 TEXT PRIMARY KEY,                   -- format CASE-NNNNNNNN
    member_id               TEXT NOT NULL REFERENCES members(member_id),
    current_state           case_state NOT NULL DEFAULT 'DISCHARGE_RECEIVED',
    priority_tier           priority_tier,
    composite_priority      INTEGER,
    discharge_facility      TEXT NOT NULL,
    discharge_date          DATE NOT NULL,
    admit_date              DATE,
    length_of_stay          INTEGER,
    primary_dx_code         TEXT NOT NULL,                      -- ICD-10
    primary_dx_description  TEXT,
    attending_physician     TEXT,
    pcp_name                TEXT,
    plan_name               TEXT,
    crm_case_record_id      TEXT,
    raw_discharge_event     JSONB,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- Dedup key for HL7/FHIR discharge events
    CONSTRAINT cases_dedup_key UNIQUE (member_id, discharge_date, discharge_facility)
);

-- Orchestrator retry/lease bookkeeping (added Step 5; idempotent ALTERs).
ALTER TABLE cases ADD COLUMN IF NOT EXISTS agent_retry_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE cases ADD COLUMN IF NOT EXISTS agent_last_error  TEXT;
ALTER TABLE cases ADD COLUMN IF NOT EXISTS next_eligible_at  TIMESTAMPTZ;

-- document_extraction_agent bookkeeping (added Step 8 real impl).
--  - `extraction_flags`: denormalized array of {field, confidence, reason}
--    rows for the reviewer UI to render red badges without re-fetching every
--    extracted field row. Source of truth remains `extracted_fields.flagged`.
--  - `is_stp`: snapshot of `config.stp_rules.is_stp(case)` at extraction time
--    so the reviewer surface can show whether STP fast-path applied.
ALTER TABLE cases ADD COLUMN IF NOT EXISTS extraction_flags JSONB;
ALTER TABLE cases ADD COLUMN IF NOT EXISTS is_stp           BOOLEAN NOT NULL DEFAULT FALSE;

CREATE INDEX IF NOT EXISTS idx_cases_current_state ON cases (current_state);
CREATE INDEX IF NOT EXISTS idx_cases_member_id      ON cases (member_id);
CREATE INDEX IF NOT EXISTS idx_cases_created_at     ON cases (created_at);
CREATE INDEX IF NOT EXISTS idx_cases_next_eligible
    ON cases (next_eligible_at) WHERE next_eligible_at IS NOT NULL;


-- ---- risk_scores ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS risk_scores (
    case_id                     TEXT PRIMARY KEY REFERENCES cases(case_id) ON DELETE CASCADE,
    impactability_total         INTEGER NOT NULL CHECK (impactability_total BETWEEN 0 AND 50),
    impactability_subscores     JSONB   NOT NULL,
    intervenability_total       INTEGER NOT NULL CHECK (intervenability_total BETWEEN 0 AND 40),
    intervenability_subscores   JSONB   NOT NULL,
    composite_priority          INTEGER NOT NULL CHECK (composite_priority BETWEEN 0 AND 90),
    priority_tier               priority_tier NOT NULL,
    computed_at                 TIMESTAMPTZ NOT NULL DEFAULT now()
);


-- ---- extracted_fields -------------------------------------------------------

CREATE TABLE IF NOT EXISTS extracted_fields (
    field_id      BIGSERIAL PRIMARY KEY,
    case_id       TEXT NOT NULL REFERENCES cases(case_id) ON DELETE CASCADE,
    field_name    TEXT NOT NULL,
    value         TEXT,
    confidence    NUMERIC(4, 3) NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    flagged       BOOLEAN NOT NULL DEFAULT FALSE,
    source_page   INTEGER,
    source_bbox   JSONB,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_extracted_fields_case      ON extracted_fields (case_id);
CREATE INDEX IF NOT EXISTS idx_extracted_fields_flagged   ON extracted_fields (case_id, flagged);


-- ---- reviewer_decisions -----------------------------------------------------

CREATE TABLE IF NOT EXISTS reviewer_decisions (
    decision_id   BIGSERIAL PRIMARY KEY,
    case_id       TEXT NOT NULL REFERENCES cases(case_id) ON DELETE CASCADE,
    reviewer_id   TEXT NOT NULL,
    outcome       reviewer_outcome NOT NULL,
    comments      TEXT,
    expires_at    TIMESTAMPTZ NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_reviewer_decisions_case ON reviewer_decisions (case_id);


-- ---- outreach_sessions ------------------------------------------------------

CREATE TABLE IF NOT EXISTS outreach_sessions (
    session_id      TEXT PRIMARY KEY,                            -- format MS-NNNNNNNN
    case_id         TEXT NOT NULL REFERENCES cases(case_id) ON DELETE CASCADE,
    channel         outreach_channel NOT NULL DEFAULT 'messaging',
    status          outreach_status NOT NULL DEFAULT 'queued',
    transcript      JSONB NOT NULL DEFAULT '[]'::jsonb,
    survey          JSONB,
    sdoh_flags      TEXT[] NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at    TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_outreach_sessions_case ON outreach_sessions (case_id);


-- ---- call_sessions ----------------------------------------------------------

CREATE TABLE IF NOT EXISTS call_sessions (
    call_id            TEXT PRIMARY KEY,                          -- format CL-NNNNNNNN
    case_id            TEXT NOT NULL REFERENCES cases(case_id) ON DELETE CASCADE,
    cm_id              TEXT NOT NULL,
    status             call_status NOT NULL DEFAULT 'pending',
    transcript         JSONB NOT NULL DEFAULT '[]'::jsonb,
    sentiment_trend    JSONB NOT NULL DEFAULT '[]'::jsonb,
    prompts_fired      JSONB NOT NULL DEFAULT '[]'::jsonb,
    consent_captured   BOOLEAN NOT NULL DEFAULT FALSE,
    consent_excerpt    TEXT,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    ended_at           TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_call_sessions_case ON call_sessions (case_id);


-- ---- appointments -----------------------------------------------------------

CREATE TABLE IF NOT EXISTS appointments (
    appointment_id          BIGSERIAL PRIMARY KEY,
    case_id                 TEXT NOT NULL REFERENCES cases(case_id) ON DELETE CASCADE,
    provider_id             TEXT,
    provider_name           TEXT NOT NULL,
    specialty               TEXT NOT NULL DEFAULT 'Primary Care',
    scheduled_at            TIMESTAMPTZ NOT NULL,
    location                TEXT,
    status                  appointment_status NOT NULL DEFAULT 'booked',
    crm_record_id           TEXT,
    sms_confirmation_sent   BOOLEAN NOT NULL DEFAULT FALSE,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_appointments_case ON appointments (case_id);


-- ---- referrals --------------------------------------------------------------

CREATE TABLE IF NOT EXISTS referrals (
    referral_id     BIGSERIAL PRIMARY KEY,
    case_id         TEXT NOT NULL REFERENCES cases(case_id) ON DELETE CASCADE,
    resource_name   TEXT NOT NULL,
    resource_type   resource_type NOT NULL,
    source          resource_source NOT NULL,
    status          referral_status NOT NULL DEFAULT 'created',
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    confirmed_at    TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_referrals_case ON referrals (case_id);


-- ---- compliance_findings ----------------------------------------------------

CREATE TABLE IF NOT EXISTS compliance_findings (
    finding_id    BIGSERIAL PRIMARY KEY,
    case_id       TEXT NOT NULL REFERENCES cases(case_id) ON DELETE CASCADE,
    check_code    TEXT NOT NULL,
    severity      compliance_severity NOT NULL,
    detail        TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_compliance_findings_case ON compliance_findings (case_id);


-- ---- audit_log --------------------------------------------------------------

CREATE TABLE IF NOT EXISTS audit_log (
    audit_id      BIGSERIAL PRIMARY KEY,
    case_id       TEXT NOT NULL,
    from_state    case_state,
    to_state      case_state NOT NULL,
    agent_name    TEXT NOT NULL,
    reason        TEXT NOT NULL,
    metadata      JSONB,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_log_case ON audit_log (case_id, created_at);


-- ---- case_events (event queue for communication_agent) --------------------

CREATE TABLE IF NOT EXISTS case_events (
    event_id          BIGSERIAL PRIMARY KEY,
    case_id           TEXT NOT NULL REFERENCES cases(case_id) ON DELETE CASCADE,
    event_type        TEXT NOT NULL,         -- e.g., "risk_stratified", "appointment_booked"
    payload           JSONB,
    processed         BOOLEAN NOT NULL DEFAULT FALSE,
    processed_at      TIMESTAMPTZ,
    delivery_status   TEXT,                  -- "sent" | "failed" | "skipped"
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_case_events_unprocessed
    ON case_events (created_at) WHERE processed = FALSE;

CREATE INDEX IF NOT EXISTS idx_case_events_case ON case_events (case_id);


-- ---- knowledge_chunks (RAG over TCM guidelines) ----------------------------

CREATE TABLE IF NOT EXISTS knowledge_chunks (
    chunk_id        BIGSERIAL PRIMARY KEY,
    source_doc      TEXT NOT NULL,
    chunk_text      TEXT NOT NULL,
    embedding       VECTOR(1024),                                -- Titan v2 dims
    chunk_metadata  JSONB,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- HNSW index for cosine similarity search. Builds incrementally.
DO $$ BEGIN
    CREATE INDEX idx_knowledge_chunks_embedding_hnsw
        ON knowledge_chunks
        USING hnsw (embedding vector_cosine_ops)
        WITH (m = 16, ef_construction = 64);
EXCEPTION WHEN duplicate_table THEN NULL; END $$;


-- ---- trigger: keep cases.updated_at fresh ----------------------------------

CREATE OR REPLACE FUNCTION touch_cases_updated_at() RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_cases_updated_at ON cases;
CREATE TRIGGER trg_cases_updated_at
    BEFORE UPDATE ON cases
    FOR EACH ROW
    EXECUTE FUNCTION touch_cases_updated_at();
