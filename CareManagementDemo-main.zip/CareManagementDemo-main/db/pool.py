"""Async psycopg connection pool.

A single module-level pool is created lazily on first call to `get_pool()`
and torn down by `close_pool()` (called from the FastAPI lifespan in Step 7).

Configured from environment:
  DATABASE_URL  — psycopg-compatible connection string (Neon-friendly)
  DB_POOL_MIN   — minimum idle connections (default 1)
  DB_POOL_MAX   — max concurrent connections (default 10)

Neon-specific note: the connection string carries `sslmode=require` and
`channel_binding=require`. psycopg/libpq honors these natively.
"""

from __future__ import annotations

import asyncio
import contextlib
import os
import sys
from collections.abc import AsyncIterator
from typing import Any

import structlog
from psycopg_pool import AsyncConnectionPool


def configure_async_loop_policy() -> None:
    """Switch Windows to `WindowsSelectorEventLoopPolicy` (psycopg async-compatible).

    Call this once at process start, before `asyncio.run(...)`. No-op on non-Windows.
    `uvicorn` (the API server) handles this itself; scripts that drive async DB
    code via `asyncio.run` must call it explicitly.
    """
    if sys.platform.startswith("win"):
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

log = structlog.get_logger(__name__)

_pool: AsyncConnectionPool | None = None


def _conninfo() -> str:
    url = os.environ.get("DATABASE_URL")
    if not url:
        raise RuntimeError("DATABASE_URL is not set; copy .env.example to .env")
    return url


async def get_pool() -> AsyncConnectionPool:
    """Return the singleton pool, opening it on first call."""
    global _pool
    if _pool is None:
        min_size = int(os.environ.get("DB_POOL_MIN", "1"))
        max_size = int(os.environ.get("DB_POOL_MAX", "10"))
        _pool = AsyncConnectionPool(
            conninfo=_conninfo(),
            min_size=min_size,
            max_size=max_size,
            open=False,
            kwargs={"autocommit": False},
        )
        await _pool.open()
        await _pool.wait()
        log.info("db_pool_opened", min_size=min_size, max_size=max_size)
    return _pool


async def close_pool() -> None:
    global _pool
    if _pool is not None:
        await _pool.close()
        log.info("db_pool_closed")
        _pool = None


@contextlib.asynccontextmanager
async def lifespan_pool() -> AsyncIterator[AsyncConnectionPool]:
    """Async context manager for FastAPI lifespan integration."""
    pool = await get_pool()
    try:
        yield pool
    finally:
        await close_pool()


@contextlib.asynccontextmanager
async def connection() -> AsyncIterator[Any]:
    """Borrow a connection from the pool."""
    pool = await get_pool()
    async with pool.connection() as conn:
        yield conn
