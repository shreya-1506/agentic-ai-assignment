"""State-machine enforcement.

`update_case_state` is the **only** sanctioned way to mutate `cases.current_state`.
It validates the transition against `ALLOWED_TRANSITIONS` and writes an
`audit_log` row in the same transaction.

Callers everywhere — agents, skills, the orchestrator — must use this helper.
Direct `UPDATE cases SET current_state = ...` is a bug.
"""

from __future__ import annotations

from typing import Any

import structlog
from psycopg import AsyncConnection
from psycopg.rows import dict_row

from config.orchestrator import MILESTONE_STATES
from models.exceptions import CaseNotFound, InvalidStateTransition
from models.schemas import ALLOWED_TRANSITIONS, Case, CaseState

log = structlog.get_logger(__name__)


async def update_case_state(
    conn: AsyncConnection,
    case_id: str,
    new_state: CaseState,
    *,
    agent_name: str,
    reason: str,
    metadata: dict[str, Any] | None = None,
) -> Case:
    """Transition a case to `new_state`, atomically.

    - Locks the row (`SELECT ... FOR UPDATE`) inside a transaction.
    - Idempotent: if the case is already in `new_state`, returns without writing.
    - Raises `CaseNotFound` if the case_id is unknown.
    - Raises `InvalidStateTransition` if the transition isn't allowed.
    - Writes one `audit_log` row per actual transition.
    """
    async with conn.transaction():
        async with conn.cursor(row_factory=dict_row) as cur:
            await cur.execute(
                "SELECT * FROM cases WHERE case_id = %s FOR UPDATE",
                (case_id,),
            )
            row = await cur.fetchone()
            if row is None:
                raise CaseNotFound(f"No case with case_id={case_id}", case_id=case_id)

            from_state = CaseState(row["current_state"])

            if new_state == from_state:
                log.info(
                    "state_transition_noop",
                    case_id=case_id,
                    state=from_state.value,
                    agent=agent_name,
                )
                return Case.model_validate(row)

            allowed = ALLOWED_TRANSITIONS.get(from_state, frozenset())
            if new_state not in allowed:
                raise InvalidStateTransition(
                    case_id=case_id,
                    from_state=from_state.value,
                    to_state=new_state.value,
                )

            # On a real state transition, clear orchestrator retry bookkeeping.
            await cur.execute(
                """
                UPDATE cases SET
                    current_state     = %s,
                    agent_retry_count = 0,
                    agent_last_error  = NULL,
                    next_eligible_at  = NULL
                  WHERE case_id = %s
                """,
                (new_state.value, case_id),
            )
            await cur.execute(
                """
                INSERT INTO audit_log (case_id, from_state, to_state, agent_name, reason, metadata)
                VALUES (%s, %s, %s, %s, %s, %s)
                """,
                (case_id, from_state.value, new_state.value, agent_name, reason, _json(metadata)),
            )

            # Milestone emission — every transition into a MILESTONE_STATES member
            # produces a `case_events` row for the communication_agent to fan out.
            # Single source of truth, regardless of which call site (agent, API,
            # auto-transition) drove the change.
            if new_state in MILESTONE_STATES:
                event_payload = {"reason": reason, "agent": agent_name}
                if metadata:
                    event_payload["metadata"] = metadata
                await cur.execute(
                    """
                    INSERT INTO case_events (case_id, event_type, payload)
                    VALUES (%s, %s, %s)
                    """,
                    (case_id, f"state.{new_state.value}", _json(event_payload)),
                )

            await cur.execute("SELECT * FROM cases WHERE case_id = %s", (case_id,))
            refreshed = await cur.fetchone()

    log.info(
        "state_transition",
        case_id=case_id,
        from_state=from_state.value,
        to_state=new_state.value,
        agent=agent_name,
        reason=reason,
    )
    assert refreshed is not None  # row was just locked-and-updated in this txn
    return Case.model_validate(refreshed)


def _json(value: dict[str, Any] | None) -> Any:
    """Wrap dict as psycopg-native Jsonb so the JSONB column accepts it."""
    if value is None:
        return None
    from psycopg.types.json import Jsonb

    return Jsonb(value)
