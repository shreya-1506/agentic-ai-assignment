"""Async DB read/write helpers, one per logical entity.

Skills and agents use these instead of writing raw SQL. They take an open
`AsyncConnection` (typically borrowed from `db.pool.connection()`) and
typed Pydantic models from `models.schemas`.

This module never starts its own transaction — callers compose helpers
inside their own `async with conn.transaction():` block. `update_case_state`
(in `db.state`) is the one exception: it owns its transaction.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from psycopg import AsyncConnection
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb

from models.schemas import (
    Appointment,
    AuditLogEntry,
    CallSession,
    Case,
    CaseState,
    ComplianceFinding,
    ExtractedField,
    Member,
    OutreachSession,
    Referral,
    ReviewerDecision,
    RiskScores,
)


# =============================================================================
# Members
# =============================================================================


async def insert_member(conn: AsyncConnection, member: Member) -> None:
    async with conn.cursor() as cur:
        await cur.execute(
            """
            INSERT INTO members (member_id, first_name, last_name, dob, phone, email,
                                 preferred_language, plan_name, pcp_name, pcp_id, address)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (member_id) DO UPDATE SET
                first_name = EXCLUDED.first_name,
                last_name  = EXCLUDED.last_name,
                dob        = EXCLUDED.dob,
                phone      = EXCLUDED.phone,
                email      = EXCLUDED.email,
                preferred_language = EXCLUDED.preferred_language,
                plan_name  = EXCLUDED.plan_name,
                pcp_name   = EXCLUDED.pcp_name,
                pcp_id     = EXCLUDED.pcp_id,
                address    = EXCLUDED.address
            """,
            (
                member.member_id,
                member.first_name,
                member.last_name,
                member.dob,
                member.phone,
                member.email,
                member.preferred_language,
                member.plan_name,
                member.pcp_name,
                member.pcp_id,
                Jsonb(member.address.model_dump()) if member.address else None,
            ),
        )


async def get_member(conn: AsyncConnection, member_id: str) -> Member | None:
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute("SELECT * FROM members WHERE member_id = %s", (member_id,))
        row = await cur.fetchone()
        return Member.model_validate(row) if row else None


# =============================================================================
# Cases
# =============================================================================


async def insert_case(conn: AsyncConnection, case: Case) -> None:
    async with conn.cursor() as cur:
        await cur.execute(
            """
            INSERT INTO cases (case_id, member_id, current_state, priority_tier,
                composite_priority, discharge_facility, discharge_date, admit_date,
                length_of_stay, primary_dx_code, primary_dx_description,
                attending_physician, pcp_name, plan_name, crm_case_record_id,
                raw_discharge_event)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                case.case_id,
                case.member_id,
                case.current_state.value,
                case.priority_tier.value if case.priority_tier else None,
                case.composite_priority,
                case.discharge_facility,
                case.discharge_date,
                case.admit_date,
                case.length_of_stay,
                case.primary_dx_code,
                case.primary_dx_description,
                case.attending_physician,
                case.pcp_name,
                case.plan_name,
                case.crm_case_record_id,
                Jsonb(case.raw_discharge_event) if case.raw_discharge_event else None,
            ),
        )


async def get_case(conn: AsyncConnection, case_id: str) -> Case | None:
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute("SELECT * FROM cases WHERE case_id = %s", (case_id,))
        row = await cur.fetchone()
        return Case.model_validate(row) if row else None


async def update_case_fields(
    conn: AsyncConnection, case_id: str, fields: dict[str, Any]
) -> None:
    """Update arbitrary non-state columns on a case row.

    NOTE: `current_state` updates must go through `db.state.update_case_state`,
    which enforces ALLOWED_TRANSITIONS. This helper refuses that column.
    """
    if "current_state" in fields:
        raise ValueError("Use db.state.update_case_state to change current_state")
    if not fields:
        return
    cols = list(fields.keys())
    set_clause = ", ".join(f"{c} = %s" for c in cols)
    values = []
    for c in cols:
        v = fields[c]
        # The `cases` table has no Postgres array columns, so a list value
        # always targets a JSONB column (currently: extraction_flags). Dicts
        # likewise round-trip through Jsonb so JSON columns accept them.
        if isinstance(v, (dict, list)):
            v = Jsonb(v)
        values.append(v)
    values.append(case_id)
    async with conn.cursor() as cur:
        await cur.execute(
            f"UPDATE cases SET {set_clause} WHERE case_id = %s",
            values,
        )


async def list_cases_in_state(
    conn: AsyncConnection, state: CaseState, limit: int = 50
) -> list[Case]:
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "SELECT * FROM cases WHERE current_state = %s "
            "ORDER BY created_at ASC LIMIT %s",
            (state.value, limit),
        )
        rows = await cur.fetchall()
        return [Case.model_validate(r) for r in rows]


# =============================================================================
# Risk scores
# =============================================================================


async def insert_risk_scores(conn: AsyncConnection, scores: RiskScores) -> None:
    async with conn.cursor() as cur:
        await cur.execute(
            """
            INSERT INTO risk_scores (case_id, impactability_total, impactability_subscores,
                intervenability_total, intervenability_subscores, composite_priority,
                priority_tier)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (case_id) DO UPDATE SET
                impactability_total = EXCLUDED.impactability_total,
                impactability_subscores = EXCLUDED.impactability_subscores,
                intervenability_total = EXCLUDED.intervenability_total,
                intervenability_subscores = EXCLUDED.intervenability_subscores,
                composite_priority = EXCLUDED.composite_priority,
                priority_tier = EXCLUDED.priority_tier,
                computed_at = now()
            """,
            (
                scores.case_id,
                scores.impactability_total,
                Jsonb(scores.impactability_subscores.model_dump()),
                scores.intervenability_total,
                Jsonb(scores.intervenability_subscores.model_dump()),
                scores.composite_priority,
                scores.priority_tier.value,
            ),
        )


async def get_risk_scores(conn: AsyncConnection, case_id: str) -> RiskScores | None:
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute("SELECT * FROM risk_scores WHERE case_id = %s", (case_id,))
        row = await cur.fetchone()
        return RiskScores.model_validate(row) if row else None


# =============================================================================
# Extracted fields
# =============================================================================


async def insert_extracted_fields(
    conn: AsyncConnection, fields: list[ExtractedField]
) -> None:
    if not fields:
        return
    async with conn.cursor() as cur:
        await cur.executemany(
            """
            INSERT INTO extracted_fields (case_id, field_name, value, confidence,
                                          flagged, source_page, source_bbox)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            [
                (
                    f.case_id,
                    f.field_name,
                    f.value,
                    f.confidence,
                    f.flagged,
                    f.source_page,
                    Jsonb(f.source_bbox) if f.source_bbox else None,
                )
                for f in fields
            ],
        )


async def list_extracted_fields(
    conn: AsyncConnection, case_id: str
) -> list[ExtractedField]:
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "SELECT * FROM extracted_fields WHERE case_id = %s ORDER BY field_id",
            (case_id,),
        )
        rows = await cur.fetchall()
        return [ExtractedField.model_validate(r) for r in rows]


# =============================================================================
# Reviewer decisions
# =============================================================================


async def insert_reviewer_decision(
    conn: AsyncConnection, decision: ReviewerDecision
) -> int:
    async with conn.cursor() as cur:
        await cur.execute(
            """
            INSERT INTO reviewer_decisions (case_id, reviewer_id, outcome, comments, expires_at)
            VALUES (%s, %s, %s, %s, %s) RETURNING decision_id
            """,
            (
                decision.case_id,
                decision.reviewer_id,
                decision.outcome.value,
                decision.comments,
                decision.expires_at,
            ),
        )
        row = await cur.fetchone()
        return row[0]


async def get_latest_reviewer_decision(
    conn: AsyncConnection, case_id: str
) -> ReviewerDecision | None:
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "SELECT * FROM reviewer_decisions WHERE case_id = %s "
            "ORDER BY created_at DESC LIMIT 1",
            (case_id,),
        )
        row = await cur.fetchone()
        return ReviewerDecision.model_validate(row) if row else None


# =============================================================================
# Outreach sessions
# =============================================================================


async def insert_outreach_session(conn: AsyncConnection, sess: OutreachSession) -> None:
    async with conn.cursor() as cur:
        await cur.execute(
            """
            INSERT INTO outreach_sessions (session_id, case_id, channel, status,
                transcript, survey, sdoh_flags, completed_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                sess.session_id,
                sess.case_id,
                sess.channel.value,
                sess.status.value,
                Jsonb([t.model_dump(mode="json") for t in sess.transcript]),
                Jsonb(sess.survey.model_dump()) if sess.survey else None,
                sess.sdoh_flags,
                sess.completed_at,
            ),
        )


async def update_outreach_session(conn: AsyncConnection, sess: OutreachSession) -> None:
    async with conn.cursor() as cur:
        await cur.execute(
            """
            UPDATE outreach_sessions
               SET status       = %s,
                   transcript   = %s,
                   survey       = %s,
                   sdoh_flags   = %s,
                   completed_at = %s
             WHERE session_id = %s
            """,
            (
                sess.status.value,
                Jsonb([t.model_dump(mode="json") for t in sess.transcript]),
                Jsonb(sess.survey.model_dump()) if sess.survey else None,
                sess.sdoh_flags,
                sess.completed_at,
                sess.session_id,
            ),
        )


async def get_outreach_session(
    conn: AsyncConnection, session_id: str
) -> OutreachSession | None:
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "SELECT * FROM outreach_sessions WHERE session_id = %s", (session_id,)
        )
        row = await cur.fetchone()
        return OutreachSession.model_validate(row) if row else None


async def get_outreach_by_case(
    conn: AsyncConnection, case_id: str
) -> OutreachSession | None:
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "SELECT * FROM outreach_sessions WHERE case_id = %s "
            "ORDER BY created_at DESC LIMIT 1",
            (case_id,),
        )
        row = await cur.fetchone()
        return OutreachSession.model_validate(row) if row else None


# =============================================================================
# Call sessions
# =============================================================================


async def insert_call_session(conn: AsyncConnection, call: CallSession) -> None:
    async with conn.cursor() as cur:
        await cur.execute(
            """
            INSERT INTO call_sessions (call_id, case_id, cm_id, status, transcript,
                sentiment_trend, prompts_fired, consent_captured, consent_excerpt, ended_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                call.call_id,
                call.case_id,
                call.cm_id,
                call.status.value,
                Jsonb([t.model_dump(mode="json") for t in call.transcript]),
                Jsonb(call.sentiment_trend),
                Jsonb([p.model_dump(mode="json") for p in call.prompts_fired]),
                call.consent_captured,
                call.consent_excerpt,
                call.ended_at,
            ),
        )


async def update_call_session(conn: AsyncConnection, call: CallSession) -> None:
    async with conn.cursor() as cur:
        await cur.execute(
            """
            UPDATE call_sessions
               SET status           = %s,
                   transcript       = %s,
                   sentiment_trend  = %s,
                   prompts_fired    = %s,
                   consent_captured = %s,
                   consent_excerpt  = %s,
                   ended_at         = %s
             WHERE call_id = %s
            """,
            (
                call.status.value,
                Jsonb([t.model_dump(mode="json") for t in call.transcript]),
                Jsonb(call.sentiment_trend),
                Jsonb([p.model_dump(mode="json") for p in call.prompts_fired]),
                call.consent_captured,
                call.consent_excerpt,
                call.ended_at,
                call.call_id,
            ),
        )


async def get_call_session(
    conn: AsyncConnection, call_id: str
) -> CallSession | None:
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "SELECT * FROM call_sessions WHERE call_id = %s", (call_id,)
        )
        row = await cur.fetchone()
        return CallSession.model_validate(row) if row else None


# =============================================================================
# Appointments
# =============================================================================


async def insert_appointment(conn: AsyncConnection, appt: Appointment) -> int:
    async with conn.cursor() as cur:
        await cur.execute(
            """
            INSERT INTO appointments (case_id, provider_id, provider_name, specialty,
                scheduled_at, location, status, crm_record_id, sms_confirmation_sent)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) RETURNING appointment_id
            """,
            (
                appt.case_id,
                appt.provider_id,
                appt.provider_name,
                appt.specialty,
                appt.scheduled_at,
                appt.location,
                appt.status.value,
                appt.crm_record_id,
                appt.sms_confirmation_sent,
            ),
        )
        row = await cur.fetchone()
        return row[0]


async def get_appointment(
    conn: AsyncConnection, appointment_id: int
) -> Appointment | None:
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "SELECT * FROM appointments WHERE appointment_id = %s", (appointment_id,)
        )
        row = await cur.fetchone()
        return Appointment.model_validate(row) if row else None


async def get_latest_appointment(
    conn: AsyncConnection, case_id: str
) -> Appointment | None:
    """Return the most recently inserted appointment for `case_id`."""
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "SELECT * FROM appointments WHERE case_id = %s "
            "ORDER BY appointment_id DESC LIMIT 1",
            (case_id,),
        )
        row = await cur.fetchone()
        return Appointment.model_validate(row) if row else None


async def get_latest_call_session(
    conn: AsyncConnection, case_id: str
) -> CallSession | None:
    """Return the most recent CallSession for `case_id`."""
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "SELECT * FROM call_sessions WHERE case_id = %s "
            "ORDER BY created_at DESC LIMIT 1",
            (case_id,),
        )
        row = await cur.fetchone()
        return CallSession.model_validate(row) if row else None


# =============================================================================
# Referrals
# =============================================================================


async def insert_referral(conn: AsyncConnection, ref: Referral) -> int:
    async with conn.cursor() as cur:
        await cur.execute(
            """
            INSERT INTO referrals (case_id, resource_name, resource_type, source, status, notes)
            VALUES (%s, %s, %s, %s, %s, %s) RETURNING referral_id
            """,
            (
                ref.case_id,
                ref.resource_name,
                ref.resource_type.value,
                ref.source.value,
                ref.status.value,
                ref.notes,
            ),
        )
        row = await cur.fetchone()
        return row[0]


async def list_referrals(conn: AsyncConnection, case_id: str) -> list[Referral]:
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "SELECT * FROM referrals WHERE case_id = %s ORDER BY created_at",
            (case_id,),
        )
        rows = await cur.fetchall()
        return [Referral.model_validate(r) for r in rows]


# =============================================================================
# Compliance findings
# =============================================================================


async def insert_compliance_finding(
    conn: AsyncConnection, finding: ComplianceFinding
) -> int:
    async with conn.cursor() as cur:
        await cur.execute(
            """
            INSERT INTO compliance_findings (case_id, check_code, severity, detail)
            VALUES (%s, %s, %s, %s) RETURNING finding_id
            """,
            (
                finding.case_id,
                finding.check_code,
                finding.severity.value,
                finding.detail,
            ),
        )
        row = await cur.fetchone()
        return row[0]


async def list_compliance_findings(
    conn: AsyncConnection, case_id: str
) -> list[ComplianceFinding]:
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "SELECT * FROM compliance_findings WHERE case_id = %s ORDER BY finding_id",
            (case_id,),
        )
        rows = await cur.fetchall()
        return [ComplianceFinding.model_validate(r) for r in rows]


# =============================================================================
# Audit log
# =============================================================================


async def list_audit_log(
    conn: AsyncConnection, case_id: str, limit: int = 100
) -> list[AuditLogEntry]:
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "SELECT * FROM audit_log WHERE case_id = %s ORDER BY created_at LIMIT %s",
            (case_id, limit),
        )
        rows = await cur.fetchall()
        return [AuditLogEntry.model_validate(r) for r in rows]


# =============================================================================
# Case events (for communication_agent's event queue)
# =============================================================================


async def insert_case_event(
    conn: AsyncConnection,
    case_id: str,
    event_type: str,
    payload: dict[str, Any] | None = None,
) -> int:
    async with conn.cursor() as cur:
        await cur.execute(
            """
            INSERT INTO case_events (case_id, event_type, payload)
            VALUES (%s, %s, %s) RETURNING event_id
            """,
            (case_id, event_type, Jsonb(payload) if payload else None),
        )
        row = await cur.fetchone()
        return row[0]


async def pop_unprocessed_events(
    conn: AsyncConnection, limit: int = 50
) -> list[dict[str, Any]]:
    """Return up to `limit` unprocessed events. Caller marks them processed."""
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            """
            SELECT event_id, case_id, event_type, payload, created_at
              FROM case_events
             WHERE processed = FALSE
             ORDER BY created_at ASC
             LIMIT %s
             FOR UPDATE SKIP LOCKED
            """,
            (limit,),
        )
        return list(await cur.fetchall())


async def mark_event_processed(
    conn: AsyncConnection,
    event_id: int,
    delivery_status: str,
) -> None:
    async with conn.cursor() as cur:
        await cur.execute(
            """
            UPDATE case_events
               SET processed = TRUE,
                   processed_at = %s,
                   delivery_status = %s
             WHERE event_id = %s
            """,
            (datetime.utcnow(), delivery_status, event_id),
        )
