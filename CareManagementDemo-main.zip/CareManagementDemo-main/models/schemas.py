"""Pydantic v2 models, string-valued enums, and ALLOWED_TRANSITIONS.

This is the single source of truth for case-related data shapes. Every
enum value here must match the Postgres enum character-for-character
(see db/schema.sql).
"""

from __future__ import annotations

from datetime import date, datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


# =============================================================================
# Enums (string-valued; match Postgres enum types exactly)
# =============================================================================


class CaseState(StrEnum):
    DISCHARGE_RECEIVED = "DISCHARGE_RECEIVED"
    RISK_STRATIFIED = "RISK_STRATIFIED"
    DOCUMENT_PENDING_REVIEW = "DOCUMENT_PENDING_REVIEW"
    DOCUMENT_APPROVED = "DOCUMENT_APPROVED"
    OUTREACH_SCHEDULED = "OUTREACH_SCHEDULED"
    OUTREACH_COMPLETE = "OUTREACH_COMPLETE"
    CM_CALLBACK_IN_PROGRESS = "CM_CALLBACK_IN_PROGRESS"
    APPOINTMENT_BOOKED = "APPOINTMENT_BOOKED"
    CARE_GOALS_MET = "CARE_GOALS_MET"
    CLOSED_NO_CONTACT = "CLOSED_NO_CONTACT"
    CLOSED_MEMBER_DECLINED = "CLOSED_MEMBER_DECLINED"
    ESCALATED = "ESCALATED"


TERMINAL_STATES: frozenset[CaseState] = frozenset(
    {
        CaseState.CARE_GOALS_MET,
        CaseState.CLOSED_NO_CONTACT,
        CaseState.CLOSED_MEMBER_DECLINED,
        CaseState.ESCALATED,
    }
)


class PriorityTier(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class ReviewerOutcome(StrEnum):
    APPROVE = "approve"
    REJECT = "reject"
    ESCALATE = "escalate"


class ComplianceSeverity(StrEnum):
    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"


class OutreachChannel(StrEnum):
    MESSAGING = "messaging"
    SMS = "sms"
    WHATSAPP = "whatsapp"


class OutreachStatus(StrEnum):
    QUEUED = "queued"
    IN_PROGRESS = "in_progress"
    COMPLETE = "complete"
    EXPIRED = "expired"


class CallStatus(StrEnum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETE = "complete"


class AppointmentStatus(StrEnum):
    BOOKED = "booked"
    CANCELLED = "cancelled"
    COMPLETED = "completed"


class ResourceType(StrEnum):
    DEVICE = "device"
    SERVICE = "service"
    TRANSPORT = "transport"
    OTHER = "other"


class ResourceSource(StrEnum):
    COMMUNITY = "community"
    PLAN = "plan"
    SELF = "self"


class ReferralStatus(StrEnum):
    CREATED = "created"
    CONFIRMED = "confirmed"
    RECEIVED = "received"
    NA = "na"


# =============================================================================
# State machine
# =============================================================================


ALLOWED_TRANSITIONS: dict[CaseState, frozenset[CaseState]] = {
    CaseState.DISCHARGE_RECEIVED: frozenset(
        {CaseState.RISK_STRATIFIED, CaseState.ESCALATED, CaseState.CLOSED_NO_CONTACT}
    ),
    CaseState.RISK_STRATIFIED: frozenset(
        {CaseState.DOCUMENT_PENDING_REVIEW, CaseState.ESCALATED}
    ),
    CaseState.DOCUMENT_PENDING_REVIEW: frozenset(
        {
            CaseState.DOCUMENT_APPROVED,
            CaseState.ESCALATED,
            CaseState.CLOSED_MEMBER_DECLINED,
        }
    ),
    CaseState.DOCUMENT_APPROVED: frozenset(
        {CaseState.OUTREACH_SCHEDULED, CaseState.ESCALATED}
    ),
    CaseState.OUTREACH_SCHEDULED: frozenset(
        {
            CaseState.OUTREACH_COMPLETE,
            CaseState.CLOSED_NO_CONTACT,
            CaseState.CLOSED_MEMBER_DECLINED,
            CaseState.ESCALATED,
        }
    ),
    CaseState.OUTREACH_COMPLETE: frozenset(
        {CaseState.CM_CALLBACK_IN_PROGRESS, CaseState.ESCALATED}
    ),
    CaseState.CM_CALLBACK_IN_PROGRESS: frozenset(
        {
            CaseState.APPOINTMENT_BOOKED,
            CaseState.CLOSED_MEMBER_DECLINED,
            CaseState.ESCALATED,
        }
    ),
    CaseState.APPOINTMENT_BOOKED: frozenset(
        {CaseState.CARE_GOALS_MET, CaseState.ESCALATED}
    ),
    CaseState.CARE_GOALS_MET: frozenset(),
    CaseState.CLOSED_NO_CONTACT: frozenset(),
    CaseState.CLOSED_MEMBER_DECLINED: frozenset(),
    CaseState.ESCALATED: frozenset(),
}


def is_terminal(state: CaseState) -> bool:
    return state in TERMINAL_STATES


# =============================================================================
# Pydantic models — one per logical entity. Field names match DB columns.
# =============================================================================


class _Base(BaseModel):
    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        str_strip_whitespace=True,
    )


# ---- Member -----------------------------------------------------------------


class Address(_Base):
    line1: str | None = None
    line2: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None


class Member(_Base):
    member_id: str
    first_name: str
    last_name: str
    dob: date
    phone: str
    email: str | None = None
    preferred_language: str = "English"
    plan_name: str
    pcp_name: str | None = None
    pcp_id: str | None = None
    address: Address | None = None
    created_at: datetime | None = None


# ---- Case -------------------------------------------------------------------


class Case(_Base):
    case_id: str
    member_id: str
    current_state: CaseState = CaseState.DISCHARGE_RECEIVED
    priority_tier: PriorityTier | None = None
    composite_priority: int | None = None
    discharge_facility: str
    discharge_date: date
    admit_date: date | None = None
    length_of_stay: int | None = None
    primary_dx_code: str
    primary_dx_description: str | None = None
    attending_physician: str | None = None
    pcp_name: str | None = None
    plan_name: str | None = None
    crm_case_record_id: str | None = None
    raw_discharge_event: dict[str, Any] | None = None
    # Orchestrator bookkeeping (Step 5): retry counter, last error, dispatch lease.
    agent_retry_count: int = 0
    agent_last_error: str | None = None
    next_eligible_at: datetime | None = None
    # document_extraction_agent outputs (Step 8 real impl):
    #  - extraction_flags: list of {field, confidence, reason} for fields whose
    #    confidence fell below the low-confidence threshold (0.80). Rendered as
    #    red badges in the reviewer UI.
    #  - is_stp: snapshot of `config.stp_rules.is_stp(case)` at extraction time.
    extraction_flags: list[dict[str, Any]] | None = None
    is_stp: bool = False
    created_at: datetime | None = None
    updated_at: datetime | None = None


# ---- Risk scores ------------------------------------------------------------


class ImpactabilitySubscores(_Base):
    clinical_severity: int = Field(ge=0, le=10)
    utilization: int = Field(ge=0, le=10)
    med_complexity: int = Field(ge=0, le=10)
    care_gaps: int = Field(ge=0, le=10)
    prior_engagement: int = Field(ge=0, le=10)


class IntervenabilitySubscores(_Base):
    sdoh: int = Field(ge=0, le=10)
    insurance_pharmacy: int = Field(ge=0, le=10)
    cognitive_behavioral: int = Field(ge=0, le=10)
    contactability: int = Field(ge=0, le=10)


class RiskScores(_Base):
    case_id: str
    impactability_total: int = Field(ge=0, le=50)
    impactability_subscores: ImpactabilitySubscores
    # POC text says /50 but lists 4 ten-point components (= /40).
    # Treating as /40 in code; surface in agents.md for business confirmation.
    intervenability_total: int = Field(ge=0, le=40)
    intervenability_subscores: IntervenabilitySubscores
    composite_priority: int = Field(ge=0, le=90)
    priority_tier: PriorityTier
    computed_at: datetime | None = None


# ---- Extracted fields -------------------------------------------------------


class ExtractedField(_Base):
    field_id: int | None = None
    case_id: str
    field_name: str
    value: str | None = None
    confidence: float = Field(ge=0.0, le=1.0)
    flagged: bool = False
    source_page: int | None = None
    source_bbox: dict[str, Any] | None = None
    created_at: datetime | None = None


# ---- Reviewer decision (human gate) ----------------------------------------


class ReviewerDecision(_Base):
    decision_id: int | None = None
    case_id: str
    reviewer_id: str
    outcome: ReviewerOutcome
    comments: str | None = None
    expires_at: datetime
    created_at: datetime | None = None


# ---- Outreach (async messaging) --------------------------------------------


class OutreachTurn(_Base):
    """One turn in the messaging-channel conversation."""

    role: str  # "tcm" | "member" | "system"
    text: str
    timestamp: datetime


class SurveyForm(_Base):
    language: str | None = None
    communication_assistance: str | None = None
    symptoms: str | None = None
    medication_pickup: bool | None = None
    pcp_followup_scheduled: bool | None = None
    cmp_enrollment: bool | None = None
    contact_phone: str | None = None
    callback_preference: str | None = None  # "morning" | "afternoon" | "evening"


class OutreachSession(_Base):
    session_id: str  # format: MS-NNNNNNNN
    case_id: str
    channel: OutreachChannel = OutreachChannel.MESSAGING
    status: OutreachStatus = OutreachStatus.QUEUED
    transcript: list[OutreachTurn] = Field(default_factory=list)
    survey: SurveyForm | None = None
    sdoh_flags: list[str] = Field(default_factory=list)
    created_at: datetime | None = None
    completed_at: datetime | None = None


# ---- Call session (live CM voice callback) ---------------------------------


class CallTurn(_Base):
    speaker: str  # "cm" | "member"
    text: str
    timestamp: datetime
    sentiment: float | None = None  # -1.0 to 1.0


class PromptFired(_Base):
    prompt_idx: int  # 1..4
    fired_at: datetime
    content: str
    triggered_by: str | None = None  # conversation beat that triggered it


class CallSession(_Base):
    call_id: str  # format: CL-NNNNNNNN
    case_id: str
    cm_id: str
    status: CallStatus = CallStatus.PENDING
    transcript: list[CallTurn] = Field(default_factory=list)
    sentiment_trend: list[dict[str, Any]] = Field(default_factory=list)
    prompts_fired: list[PromptFired] = Field(default_factory=list)
    consent_captured: bool = False
    consent_excerpt: str | None = None
    created_at: datetime | None = None
    ended_at: datetime | None = None


# ---- Appointment ------------------------------------------------------------


class Appointment(_Base):
    appointment_id: int | None = None
    case_id: str
    provider_id: str | None = None
    provider_name: str
    specialty: str = "Primary Care"
    scheduled_at: datetime
    location: str | None = None
    status: AppointmentStatus = AppointmentStatus.BOOKED
    crm_record_id: str | None = None
    sms_confirmation_sent: bool = False
    created_at: datetime | None = None


# ---- Referral ---------------------------------------------------------------


class Referral(_Base):
    referral_id: int | None = None
    case_id: str
    resource_name: str
    resource_type: ResourceType
    source: ResourceSource
    status: ReferralStatus = ReferralStatus.CREATED
    notes: str | None = None
    created_at: datetime | None = None
    confirmed_at: datetime | None = None


# ---- Compliance finding -----------------------------------------------------


class ComplianceFinding(_Base):
    finding_id: int | None = None
    case_id: str
    check_code: str
    severity: ComplianceSeverity
    detail: str | None = None
    created_at: datetime | None = None


# ---- Audit log entry --------------------------------------------------------


class AuditLogEntry(_Base):
    audit_id: int | None = None
    case_id: str
    from_state: CaseState | None = None
    to_state: CaseState
    agent_name: str
    reason: str
    metadata: dict[str, Any] | None = None
    created_at: datetime | None = None


# ---- Knowledge chunk (RAG) -------------------------------------------------


class KnowledgeChunk(_Base):
    chunk_id: int | None = None
    source_doc: str
    chunk_text: str
    embedding: list[float] | None = None  # 1024 dims (Titan v2)
    chunk_metadata: dict[str, Any] | None = None
    created_at: datetime | None = None


# =============================================================================
# Convenience exports
# =============================================================================


__all__ = [
    "ALLOWED_TRANSITIONS",
    "Address",
    "Appointment",
    "AppointmentStatus",
    "AuditLogEntry",
    "CallSession",
    "CallStatus",
    "CallTurn",
    "Case",
    "CaseState",
    "ComplianceFinding",
    "ComplianceSeverity",
    "ExtractedField",
    "ImpactabilitySubscores",
    "IntervenabilitySubscores",
    "KnowledgeChunk",
    "Member",
    "OutreachChannel",
    "OutreachSession",
    "OutreachStatus",
    "OutreachTurn",
    "PriorityTier",
    "PromptFired",
    "Referral",
    "ReferralStatus",
    "ResourceSource",
    "ResourceType",
    "ReviewerDecision",
    "ReviewerOutcome",
    "RiskScores",
    "SurveyForm",
    "TERMINAL_STATES",
    "is_terminal",
]
