"""Typed exception hierarchy for skills and agents.

All exceptions raised by `/skills/` modules must be `SkillError` subclasses.
Agents may raise these too. Each exception carries a `case_id` when known
so callers can attach it to structured logs without re-plumbing context.
"""

from __future__ import annotations

from typing import Any


class SkillError(Exception):
    """Base class for all errors raised by skills/agents."""

    def __init__(self, message: str, *, case_id: str | None = None, **extra: Any) -> None:
        super().__init__(message)
        self.case_id = case_id
        self.extra = extra


# ---- State machine errors ----------------------------------------------------


class CaseNotFound(SkillError):
    """The given case_id does not exist in the cases table."""


class InvalidStateTransition(SkillError):
    """Attempted transition not present in ALLOWED_TRANSITIONS."""

    def __init__(self, case_id: str, from_state: str, to_state: str) -> None:
        super().__init__(
            f"Illegal transition {from_state} -> {to_state} for case {case_id}",
            case_id=case_id,
            from_state=from_state,
            to_state=to_state,
        )
        self.from_state = from_state
        self.to_state = to_state


class DuplicateCase(SkillError):
    """A case for the same (member_id, discharge_date, facility) already exists."""


# ---- Document / extraction errors --------------------------------------------


class DocumentNotFound(SkillError):
    """Hospital Discharge Summary could not be retrieved from EHR_DOCUMENT_STORE."""


class LowConfidenceField(SkillError):
    """An extracted field is below the confidence threshold and was flagged."""

    def __init__(self, case_id: str, field_name: str, confidence: float) -> None:
        super().__init__(
            f"Low-confidence field '{field_name}' = {confidence:.2f} on case {case_id}",
            case_id=case_id,
            field_name=field_name,
            confidence=confidence,
        )
        self.field_name = field_name
        self.confidence = confidence


# ---- Human gate errors -------------------------------------------------------


class HumanGateNotPassed(SkillError):
    """Action attempted before clinician approval was recorded."""


class ReviewerDecisionExpired(SkillError):
    """The reviewer decision exists but is past its SLA window."""


# ---- Consent / scheduling errors --------------------------------------------


class ConsentNotCaptured(SkillError):
    """Scheduling attempted without verbal consent in the call transcript."""


# ---- External integration errors --------------------------------------------


class MockUnavailable(SkillError):
    """A mock external system is intentionally returning failure (for tests)."""


class BedrockError(SkillError):
    """Bedrock invoke / embedding call failed after retries."""


class ExternalServiceError(SkillError):
    """Catch-all for unexpected failures from mocked external systems."""
