# Workflow — Manual End-to-End Walkthrough (PowerShell)

> A reproducible PowerShell walkthrough of the system from a fresh clone. Each step here corresponds to a build step; sections appear as each step produces something driveable.

## Prerequisites

- Windows + PowerShell 5.1
- Python 3.11+ via [uv](https://github.com/astral-sh/uv) (`uv --version`)
- Postgres 15+ with pgvector — local install **or** a Neon serverless DB
- AWS credentials configured with Bedrock access (Claude Haiku 4.5 + Titan v2)
- (Optional) GTK3 runtime if exercising WeasyPrint PDF rendering

## Setup (one-time)

```powershell
# from project root
uv venv hh --python 3.11
.\hh\Scripts\Activate.ps1
uv pip install -r requirements.txt
Copy-Item .env.example .env
# edit .env: DATABASE_URL (Neon URL or local), BEDROCK_REGION, AWS creds
```

---

## Step 2 — Bootstrap the database

Applies [db/schema.sql](db/schema.sql) idempotently to the database in `DATABASE_URL`.

```powershell
.\hh\Scripts\Activate.ps1
uv pip install "psycopg[binary,pool]>=3.2,<4.0" "pgvector>=0.3,<1.0" "pydantic>=2.9,<3.0" "structlog>=24.4,<25.0"
python -m scripts.bootstrap_db
```

Expected output (against Neon):

```
Connecting to: postgresql://neondb_owner:***@<endpoint>.neon.tech/neondb?...
OK: schema applied.
Tables in 'public': ['appointments', 'audit_log', 'call_sessions', 'cases',
  'compliance_findings', 'extracted_fields', 'knowledge_chunks', 'members',
  'outreach_sessions', 'referrals', 'reviewer_decisions', 'risk_scores']
```

Re-runnable any time — every DDL statement is idempotent.

---

## Step 3 — Ingest the RAG corpus

Reads [knowledge/tcm_guidelines/*.md](knowledge/tcm_guidelines/), chunks each doc on `## ` headers, embeds each chunk via Titan v2 (1024 dims), and upserts into `knowledge_chunks`. Idempotent (SHA-256 content-hash dedup): re-runs only embed and insert new/edited chunks.

```powershell
.\hh\Scripts\Activate.ps1
uv pip install "boto3>=1.35,<2.0"

# preview what would happen
python -m scripts.ingest_knowledge --dry-run

# real ingest (calls Bedrock)
python -m scripts.ingest_knowledge
```

First-run expected output (against an empty `knowledge_chunks` table):

```
Scanning 6 markdown files in ...\knowledge\tcm_guidelines
  cmp_enrollment.md: 6 chunks
  cms_tcm_billing.md: 6 chunks
  copd_post_discharge.md: 6 chunks
  high_risk_icd10.md: 10 chunks
  medication_reconciliation.md: 6 chunks
  sdoh_screening.md: 6 chunks

Diff vs DB: insert=40  unchanged=0  delete=0

Embedding 40 chunk(s) via Titan v2 (amazon.titan-embed-text-v2:0) ...
  [1/40] ...
  ...
Done. knowledge_chunks now contains 40 row(s).
```

Re-run: `insert=0 unchanged=40 delete=0` (no Bedrock calls).

---

## Step 12 — scheduling_agent (CM-triggered stub) + /schedule endpoints

Mid-call POST that books the PCP appointment + renders the SMS + PDF + calendar + referral + follow-up task — all in one call.

```powershell
.\hh\Scripts\Activate.ps1
python -m scripts.smoke_step12_scheduling
```

Manual flow against running uvicorn (case must be in `CM_CALLBACK_IN_PROGRESS` with verbal consent):

```powershell
$body = @{ cm_id = "cm.sarah@example.com" } | ConvertTo-Json
Invoke-RestMethod -Method POST -ContentType "application/json" `
  -Uri "http://localhost:8000/cases/CASE-00099999/schedule" -Body $body |
  ConvertTo-Json -Depth 4

# Fetch the booked appointment
Invoke-RestMethod "http://localhost:8000/cases/CASE-00099999/appointment" |
  ConvertTo-Json -Depth 3

# Inspect side-effects on disk
Get-Content data/outbox/sms.log -Tail 1
ls data/documents/CASE-00099999_*
```

Expected: `current_state: "APPOINTMENT_BOOKED"`, `provider_name: "Dr. Luis Garcia"`, `scheduled_at: "2026-10-10T14:00:00Z"`. SMS log has a confirmation line with redacted phone. The HTML artifact (`CASE-00099999_appointment_confirmation.html`) is in `data/documents/` — to upgrade to PDF, install GTK3 + the `weasyprint` Python package.

---

## Step 11 — agent_assist_agent (foreground stub) + /call endpoints

The first foreground (non-orchestrator) agent. `POST /cases/{id}/call/start` spawns a background asyncio task that streams the canned 12-turn transcript, scores sentiment per member turn, fires 4 sequential prompts, and captures verbal consent. The CM panel polls `GET /cases/{id}/call` to watch progress in real time.

```powershell
.\hh\Scripts\Activate.ps1
python -m scripts.smoke_step11_call
```

Manual flow with uvicorn running (case must be in `OUTREACH_COMPLETE`):

```powershell
# Start the call
$body = @{ cm_id = "cm.sarah@example.com" } | ConvertTo-Json
$start = Invoke-RestMethod -Method POST -ContentType "application/json" `
  -Uri "http://localhost:8000/cases/CASE-00099999/call/start" -Body $body
$start.call_id

# Poll until done (call replay finishes in ~1 second)
Invoke-RestMethod "http://localhost:8000/cases/CASE-00099999/call" | ConvertTo-Json -Depth 6
```

You'll see:
- `transcript` building up to 12 turns (alternating cm / member with sentiment scores on member turns)
- `prompts_fired` listing `p1_breathing`, `p2_oximeter`, `p3_transport`, `p4_schedule` in order
- `sentiment_trend` arc from ~50 (neutral) up to ~85 (very_positive)
- `consent_captured: true` and `consent_excerpt: "Yes, please."` after turn 12
- `status: "complete"` once the background task finishes

The case stays in `CM_CALLBACK_IN_PROGRESS` after the call ends — Step 12's scheduling_agent flips it to `APPOINTMENT_BOOKED` once verbal consent is honored.

---

## Step 10 — Human review endpoints (first true end-to-end)

After Step 10 the full pipeline walks `DISCHARGE_RECEIVED -> OUTREACH_COMPLETE` via the live API — no raw-SQL bypasses.

```powershell
.\hh\Scripts\Activate.ps1
python -m scripts.smoke_step10_review
```

Or manually drive it via the running uvicorn:

```powershell
$h = @{ "X-Admin-Token" = "local-dev-admin-please-change" }

# Reset CASE-00099999 to a clean start (re-run any earlier smoke or use the
# /cases/intake endpoint with a fresh dedup key)

# Tick 1: admission_risk_agent -> RISK_STRATIFIED
Invoke-RestMethod -Method POST -Headers $h `
  -Uri "http://localhost:8000/admin/orchestrator/tick"

# Tick 2: document_extraction_agent -> DOCUMENT_PENDING_REVIEW
Invoke-RestMethod -Method POST -Headers $h `
  -Uri "http://localhost:8000/admin/orchestrator/tick"

# See the reviewer queue
Invoke-RestMethod "http://localhost:8000/clinician/queue" | ConvertTo-Json -Depth 5

# Approve the case
$review = @{
  reviewer_id = "clinician.sarah@example.com"
  outcome     = "approve"
  comments    = "Medication taper confirmed. Authorize outreach."
} | ConvertTo-Json
Invoke-RestMethod -Method POST -ContentType "application/json" `
  -Uri "http://localhost:8000/cases/CASE-00099999/review" -Body $review

# Tick 3: orchestrator auto-transitions DOCUMENT_APPROVED -> OUTREACH_SCHEDULED
Invoke-RestMethod -Method POST -Headers $h `
  -Uri "http://localhost:8000/admin/orchestrator/tick"

# Tick 4: outreach_agent -> OUTREACH_COMPLETE
Invoke-RestMethod -Method POST -Headers $h `
  -Uri "http://localhost:8000/admin/orchestrator/tick"

# Final view
Invoke-RestMethod "http://localhost:8000/cases/CASE-00099999" | ConvertTo-Json -Depth 6
```

---

## Step 9 — outreach_agent stub + /cases/{id}/outreach

The stub walks `OUTREACH_SCHEDULED -> OUTREACH_COMPLETE` by running through John Martinez's canned 14-turn messaging conversation, issuing one RAG query, and persisting a survey + SDOH flag list. The reviewer endpoint that bridges `DOCUMENT_PENDING_REVIEW -> OUTREACH_SCHEDULED` lands in Step 10 — for now the smoke bypasses the gate via raw SQL.

```powershell
.\hh\Scripts\Activate.ps1
python -m scripts.smoke_step9_outreach
```

With the API running, fetch the session:

```powershell
Invoke-RestMethod "http://localhost:8000/cases/CASE-00099999/outreach" | ConvertTo-Json -Depth 6
```

You'll see the 14-turn transcript, the populated `survey` (`cmp_enrollment: true`, `pcp_followup_scheduled: false`, `symptoms: "Mild dyspnea, morning SOB"`), and `sdoh_flags: ["no_pcp_appt"]`.

---

## Step 8 — document_extraction_agent stub + /cases/{id}/extraction

Two consecutive orchestrator ticks walk `CASE-00099999` from `DISCHARGE_RECEIVED → RISK_STRATIFIED → DOCUMENT_PENDING_REVIEW`. The second tick persists the 11-field John Martinez extraction (1 flagged at 0.72 confidence) and emits the `state.DOCUMENT_PENDING_REVIEW` milestone.

```powershell
.\hh\Scripts\Activate.ps1
python -m scripts.smoke_step8_document_extraction
```

Or, with the API running, hit the new endpoint directly:

```powershell
Invoke-RestMethod "http://localhost:8000/cases/CASE-00099999/extraction" | ConvertTo-Json -Depth 4
```

You'll see `total_fields: 11`, `flagged_count: 1`, `flagged_field_names: ["medication_changes"]`, and `ready_for_review: true` (which the reviewer UI in Step 10 will use to know when to render an approve/reject pane).

After Step 8, the case sits in `DOCUMENT_PENDING_REVIEW` indefinitely — the orchestrator skips it (no agent for that state) until the clinician acts via the reviewer endpoint (Step 10).

---

## Step 7 — FastAPI surface (uvicorn + lifespan-hosted orchestrator)

The single uvicorn process hosts the HTTP API AND the orchestrator polling loop (as an asyncio task started in the FastAPI lifespan).

```powershell
.\hh\Scripts\Activate.ps1
uv pip install "fastapi>=0.115,<1.0" "uvicorn[standard]>=0.32,<1.0" "pydantic-settings>=2.6,<3.0"

# Run the API server
uvicorn api.main:app --reload --port 8000
```

Then visit:

- http://localhost:8000/docs           — Swagger UI
- http://localhost:8000/health         — proc + DB + Bedrock readiness probe
- http://localhost:8000/cases?state=DISCHARGE_RECEIVED  — list cases by state
- http://localhost:8000/cases/CASE-00099999             — full case view

Force an orchestrator tick from the CLI (without waiting for the 5s timer):

```powershell
$h = @{ "X-Admin-Token" = "local-dev-admin-please-change" }
Invoke-RestMethod -Method POST -Uri "http://localhost:8000/admin/orchestrator/tick?limit=5" -Headers $h
```

Post a synthetic discharge event:

```powershell
$body = @{
  member_id          = "MBR-99000001"
  facility           = "St. Mary's Medical Center"
  admit_date         = "2026-11-01"
  discharge_date     = "2026-11-03"
  length_of_stay_days = 2
  primary_dx_code    = "J44.1"
  primary_dx_description = "COPD with acute exacerbation"
  pcp_name           = "Dr. Garcia"
  plan_name          = "BlueCross Premier"
} | ConvertTo-Json
Invoke-RestMethod -Method POST -Uri "http://localhost:8000/cases/intake" -Body $body -ContentType "application/json"
```

Smoke (no server required — drives the ASGI app in-process):

```powershell
python -m scripts.smoke_step7_api
```

---

## Step 6 — admission_risk_agent stub (orchestrator-driven)

Walks the John Martinez seed case `CASE-00099999` from `DISCHARGE_RECEIVED` to `RISK_STRATIFIED` through the orchestrator. The stub uses the POC's exact scores (Impactability 42 / Intervenability 31 / Composite 73 / Medium).

```powershell
.\hh\Scripts\Activate.ps1
python -m scripts.smoke_step6_admission_risk
```

Output ends with the case in `RISK_STRATIFIED` and a populated `risk_scores` row. Subsequent ticks log `agent_not_registered` for the next state's agent (document_extraction_agent lands in Step 8) and otherwise no-op. Re-run the script any time to walk from `DISCHARGE_RECEIVED` again (it resets the case state + clears the prior risk_scores row).

---

## Step 5 — Orchestrator dispatch loop

The orchestrator polls dispatchable cases and routes them to registered agents. Run the smoke test (4 scenarios: happy path, auto-transition, transient failure, escalation):

```powershell
.\hh\Scripts\Activate.ps1
python -m scripts.smoke_step5_orchestrator
```

Or run the orchestrator as a daemon (single tick — useful before FastAPI lands):

```powershell
python -m scripts.run_orchestrator --max-ticks 1 --poll 5
```

Without `--max-ticks`, the loop runs forever (until Ctrl+C). It uses `next_eligible_at` as a soft lease so a long-running dispatch won't be re-picked-up by a parallel instance. Successful `update_case_state` calls clear the lease automatically.

---

## Step 4 — Skills layer smoke tests

After installing the slim Step 4 deps (psycopg, pgvector, pydantic, structlog, boto3, jinja2, httpx, tenacity), exercise the layer in two passes:

```powershell
.\hh\Scripts\Activate.ps1
uv pip install "jinja2>=3.1,<4.0" "httpx>=0.27,<1.0" "tenacity>=9.0,<10.0"

# Foundations: PII redaction, ID minting, structlog, Bedrock chat, embed, RAG
python -m scripts.smoke_step4_foundations

# Full end-to-end: all 22 skill modules against Neon + Bedrock
python -m scripts.smoke_step4_skills
```

The skills smoke seeds John Martinez (`MBR-00847291`) and `CASE-00099999` into Neon on first run; subsequent runs reuse them. It exercises CRM, member, claims, EHR fetch, document parsing/extraction, formulary, scheduling, SMS, email, calendar, messaging round-trip, transcript stream, sentiment scoring, community resource lookup, Jinja templates, PDF rendering (HTML fallback when WeasyPrint isn't installed), webhook delivery (graceful failure path), DB-backed event queue (`case_events`), and UI pushes. Output is JSON-structured logs with PII automatically masked.

---

_(walkthrough sections added per build step as runnable artifacts land)_
