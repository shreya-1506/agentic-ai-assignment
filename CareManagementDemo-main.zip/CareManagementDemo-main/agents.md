# Agents — Canonical Contracts

> Single source of truth for the multi-agent TCM pipeline. **Update this file before changing agent code.** Every agent listed here must have a 1:1 implementation under [agents/](agents/).

## Pipeline overview

```
DISCHARGE_RECEIVED
  → orchestration_agent dispatches → admission_risk_agent
                                       ↓
RISK_STRATIFIED                       → document_extraction_agent
                                       ↓
DOCUMENT_PENDING_REVIEW  [HUMAN GATE: clinician approves + authorizes outreach, SLA 4h]
                                       ↓
DOCUMENT_APPROVED                     → outreach_agent
                                       ↓
OUTREACH_SCHEDULED                    → (messaging session executes)
                                       ↓
OUTREACH_COMPLETE                     → agent_assist_agent (real-time during CM voice callback)
                                       ↓
CM_CALLBACK_IN_PROGRESS               → scheduling_agent (verbal-consent-gated, mid-call)
                                       ↓
APPOINTMENT_BOOKED                    → compliance_agent → CARE_GOALS_MET (terminal)

communication_agent: event-driven, fires at each milestone (not in the linear chain).
```

## Cross-agent invariants

- Agents never call each other in-process. All hand-off is via `cases` state + orchestrator polling.
- Every agent is idempotent on entry: read current state, exit cleanly if already past.
- State transitions go through [`db.state.update_case_state`](db/state.py), which enforces [`ALLOWED_TRANSITIONS`](models/schemas.py) (single source of truth) and writes one `audit_log` row per transition in the same transaction.
- Every log line carries `case_id`; PII is masked (names, DOB, MRN, phone).
- Default LLM: **Claude Haiku 4.5 on Bedrock** per BUILD_PROMPT (`BEDROCK_MODEL_ID=us.anthropic.claude-haiku-4-5-20251001-v1:0`).
  - **Active override in this POC build:** `BEDROCK_MODEL_ID=us.anthropic.claude-sonnet-4-20250514-v1:0` (Sonnet 4, May 2025). All agents inherit this unless they explicitly override.
- Embeddings: Titan v2 (1024 dims) via `amazon.titan-embed-text-v2:0`.
- Per-agent model overrides allowed; document the override + rationale in that agent's entry below.

## Open business questions (flagged from BUILD_PROMPT_v2)

1. **STP rules** — currently `is_stp(case)` returns `False` for every case (all go to clinician review). Business to confirm the 5 candidate rules in [config/stp_rules.py](config/stp_rules.py).
2. **Stage 3 ("Discharge Review — CM Check")** — currently folded into the document_extraction reviewer surface (one human gate). If business wants it as a separate gate, add a `DISCHARGE_REVIEWED` state between `DOCUMENT_APPROVED` and `OUTREACH_SCHEDULED`.
3. **Intervenability scoring** — POC says `/50` but lists only 4 ten-point components (= `/40`). Code treats as `/40`. Business to confirm.

## Agent entries

> Filled in incrementally as each agent is built. Schema for each entry:
>
> ```
> ### NN — <agent_name>
> - **Role:** one-line purpose
> - **Trigger:** state the orchestrator dispatches from
> - **Input state → Output state:** STATE_A → STATE_B
> - **Tools used:** list of skill functions from skills.md
> - **System-prompt skeleton:** brief outline
> - **Constraints:** retries, timeouts, idempotency notes
> - **Model:** default | override (with rationale)
> ```

> **Runtime:** Step 7 wired the orchestrator into a FastAPI lifespan-managed daemon inside the uvicorn process. `ORCHESTRATOR_ENABLED=false` disables it for tests; `POST /admin/orchestrator/tick` (header `X-Admin-Token`) forces a tick from the CLI / Swagger UI.

### 00 — orchestration_agent

- **Role:** polling dispatcher; routes cases to the agent registered for the current state; enforces idempotency, retries, and lease-based concurrency safety; emits milestone events to `case_events`.
- **Trigger:** continuous polling loop (asyncio); FastAPI lifespan daemon from Step 7 onward.
- **Input state → Output state:** N/A — the orchestrator dispatches *for* every dispatchable state and doesn't move cases through agent work itself. It does perform two kinds of writes:
  - **Auto-transitions** for states with no work agent (currently `DOCUMENT_APPROVED → OUTREACH_SCHEDULED`).
  - **Failure transitions:** `<any> → ESCALATED` after `MAX_RETRIES` consecutive dispatch failures.
- **Tools used:** `db.state.update_case_state`, `db.state_io.{get_case, update_case_fields, insert_case_event}`, the agent registry from `agents._registry`.
- **Constraints:**
  - `SELECT ... FOR UPDATE SKIP LOCKED` + `next_eligible_at` lease (configurable; default 300s) → safe for multiple instances even though the POC runs one.
  - Retry: `MAX_RETRIES=3`, backoff `(60s, 300s, 1800s)`. Each transient failure writes a `transient_failure retry=N/M` row in `audit_log`.
  - Idempotent: if a case advances state mid-tick (via a foreground API call), the orchestrator re-reads and skips re-dispatch.
  - Never writes domain data — only state, audit, and event rows.
- **Model:** none (no LLM calls).
- **File:** [agents/orchestration_agent.py](agents/orchestration_agent.py)
- **Dispatch table source of truth:** [config/orchestrator.py](config/orchestrator.py).

### 01 — admission_risk_agent  *(STUB, Step 6)*

- **Role:** turns a raw discharge event into a stratified, prioritized case with a CRM record and 4 workflow tasks ready for the next stage.
- **Trigger:** orchestrator dispatch on `current_state = DISCHARGE_RECEIVED`.
- **Input state → Output state:** `DISCHARGE_RECEIVED → RISK_STRATIFIED` (escalation path: `→ ESCALATED` via orchestrator retry policy).
- **Tools used:** `skills.member.get_profile`, `skills.claims.get_member_history`, `skills.crm.create_case`, `skills.crm.create_task`, `db.state_io.insert_risk_scores`, `db.state_io.update_case_fields`, `db.state.update_case_state`.
- **System-prompt skeleton:** (real impl) anchored 0–10 rubrics per Impactability + Intervenability dimension; returns JSON only — no totals, no side-effects.
- **Constraints:**
  - Idempotent re-entry: exits cleanly if `current_state != DISCHARGE_RECEIVED`.
  - Composite math (`Impactability + Intervenability`) and `tier_for(score)` are deterministic Python, **not** computed by the LLM.
  - 4 CRM workflow tasks per the POC are always created on success.
  - Stub writes John Martinez's POC values (Impactability 42 / Intervenability 31 / Composite 73 / Medium) regardless of the input case — the teammate replaces this with real scoring.
- **Model:** stub uses no LLM. Real impl: `BEDROCK_MODEL_ID` (currently overridden to Sonnet 4).
- **File:** [agents/admission_risk_agent.py](agents/admission_risk_agent.py).
- **Spec:** [agent_prompts/01_admission_risk_agent.md](agent_prompts/01_admission_risk_agent.md).

### 02 — document_extraction_agent

- **Role:** retrieve the Hospital Discharge Summary, extract 13 per-field values with confidence scores, flag low-confidence rows for clinician review, persist denormalized `case.extraction_flags` + `case.is_stp` for the reviewer UI, and transition the case into the human gate.
- **Trigger:** orchestrator dispatch on `current_state = RISK_STRATIFIED`.
- **Input state → Output state:**
  - Success: `RISK_STRATIFIED → DOCUMENT_PENDING_REVIEW`.
  - Failure (document fetch exhausted): `RISK_STRATIFIED → ESCALATED` with `reason="discharge summary fetch failed after 2 attempts"`.
- **Tools used:** `skills.ehr.fetch_discharge_summary`, `skills.documents.parse_pdf`, `skills.documents.extract_fields_llm`, `config.stp_rules.is_stp`, `db.state_io.insert_extracted_fields`, `db.state_io.update_case_fields`, `db.state.update_case_state`.
- **System-prompt skeleton:** see [`config.extraction.EXTRACTION_SYSTEM_PROMPT`](config/extraction.py) — per-field JSON with `{value, confidence, reason}` keys, anchored confidence rubric (≥0.95 verbatim, 0.85–0.94 inferred, 0.70–0.84 ambiguous, <0.70 → null), explicit "no prose outside JSON" guard.
- **Constraints:**
  - **Idempotent re-entry:** state-guard skips if `current_state != RISK_STRATIFIED`; extraction-row-guard skips re-extraction if `extracted_fields` rows already exist for the case (still recomputes `extraction_flags` + `is_stp` + advances state).
  - **Confidence threshold:** [`LOW_CONFIDENCE_THRESHOLD = 0.80`](config/extraction.py); fields below are `flagged=True` and surface in `case.extraction_flags`.
  - **Document fetch retries:** `MAX_DOCUMENT_FETCH_ATTEMPTS = 2`. After that the agent transitions the case to `ESCALATED` and writes the last error type onto the audit metadata.
  - **STP check:** `is_stp(case)` is currently `False` for every case (placeholder until business signs off on the 5 candidate rules in [config/stp_rules.py](config/stp_rules.py)); the boolean is persisted on `cases.is_stp` for visibility.
  - **LLM failure handling:** Bedrock failures (`BedrockError`) and JSON-parse failures (`ExtractionParseError`) propagate to the orchestrator, which owns retry-with-backoff-then-escalate (`MAX_RETRIES=3`, backoff `60s / 5min / 30min`). The agent does NOT silently fall back to the deterministic mock -- a fallback at this layer would hide LLM outages from the on-call surface and ship mock data to the clinician reviewer.
  - **PII:** structlog auto-redacts known PII keys; per-field values flow through `redact_pii` before they hit log lines. The DB row stores raw clinician-readable text (audit requirement).
- **Extraction contract (13 fields, confidence ranges from POC):**

  | Field | Expected | Tier |
  |---|---|---|
  | medical_center | 96–99% | high |
  | patient_name | 96–99% | high |
  | mrn | 96–99% | high |
  | admit_date | 96–99% | high |
  | discharge_date | 96–99% | high |
  | length_of_stay | 96–99% | high |
  | attending_physician | 96–99% | high |
  | primary_diagnosis | 96–99% | high |
  | hand_off_summary | 91–95% | medium |
  | reason_for_hospitalization | 91–95% | medium |
  | medication_changes | 70–80% | **low — flagged** |
  | last_spo2 | 85–95% | medium |
  | discharge_disposition | 90–98% | high |

- **Reviewer payload (sample, as returned by `GET /cases/{id}/extraction` joined with `GET /cases/{id}`):**

  ```json
  {
    "case_id": "CASE-00099999",
    "current_state": "DOCUMENT_PENDING_REVIEW",
    "is_stp": false,
    "extraction_flags": [
      {
        "field": "medication_changes",
        "confidence": 0.72,
        "tier": "low",
        "reason": "OCR noise on prednisone dose; multiple candidates"
      }
    ],
    "total_fields": 13,
    "flagged_count": 1,
    "ready_for_review": true,
    "fields": [
      {"field_name": "medical_center",        "value": "St. Mary's Medical Center", "confidence": 0.98, "flagged": false},
      {"field_name": "patient_name",          "value": "John Martinez",             "confidence": 0.99, "flagged": false},
      {"field_name": "mrn",                   "value": "MRN-78234916",              "confidence": 0.97, "flagged": false},
      {"field_name": "admit_date",            "value": "2026-10-02",                "confidence": 0.96, "flagged": false},
      {"field_name": "discharge_date",        "value": "2026-10-05",                "confidence": 0.97, "flagged": false},
      {"field_name": "length_of_stay",        "value": "3",                          "confidence": 0.96, "flagged": false},
      {"field_name": "attending_physician",   "value": "Dr. Priya Patel",           "confidence": 0.96, "flagged": false},
      {"field_name": "primary_diagnosis",     "value": "COPD with acute exacerbation (J44.1)", "confidence": 0.98, "flagged": false},
      {"field_name": "hand_off_summary",      "value": "Patient stabilized ...",     "confidence": 0.93, "flagged": false},
      {"field_name": "reason_for_hospitalization", "value": "Acute COPD ...",        "confidence": 0.91, "flagged": false},
      {"field_name": "medication_changes",    "value": "[{\"name\": \"Prednisone\", \"dose\": \"40mg\", \"instructions\": \"taper 14d\"}, ...]", "confidence": 0.72, "flagged": true},
      {"field_name": "last_spo2",             "value": "93% on room air (Day 3)",   "confidence": 0.90, "flagged": false},
      {"field_name": "discharge_disposition", "value": "Home with self-care",        "confidence": 0.95, "flagged": false}
    ]
  }
  ```

- **Model:** Bedrock Claude Haiku 4.5 per `BEDROCK_MODEL_ID` (Sonnet 4 override active in this build).
- **File:** [agents/document_extraction_agent.py](agents/document_extraction_agent.py).
- **Spec:** [agent_prompts/02_document_extraction_agent.md](agent_prompts/02_document_extraction_agent.md).
- **Config:** [config/extraction.py](config/extraction.py) (prompt, thresholds, expected fields).
- **Endpoint:** `GET /cases/{id}/extraction` ([api/routes/extraction.py](api/routes/extraction.py)).
- **Tests:** [tests/test_document_extraction_unit.py](tests/test_document_extraction_unit.py) + [tests/test_document_extraction_agent.py](tests/test_document_extraction_agent.py).

> **Milestone emission update (Step 10):** every state transition that lands in [`config.orchestrator.MILESTONE_STATES`](config/orchestrator.py) — regardless of which call site drives it (orchestrator, agent, API endpoint, auto-transition) — inserts a `case_events` row inside the same transaction as the state UPDATE. Implemented in [`db.state.update_case_state`](db/state.py). The communication_agent (Step 14) consumes this queue.

### 03 — outreach_agent  *(STUB, Step 9)*

- **Role:** drive the async messaging-channel conversation: identity verify → clinical check-in → CMP pitch → survey capture → SDOH flag emission.
- **Trigger:** orchestrator dispatch on `current_state = OUTREACH_SCHEDULED`.
- **Input state → Output state:** `OUTREACH_SCHEDULED → OUTREACH_COMPLETE` (failure paths: `→ CLOSED_NO_CONTACT` after 3 messaging attempts, `→ CLOSED_MEMBER_DECLINED` on enrollment refusal — handled by real impl, stub only does success).
- **Tools used:** `skills.messaging.open_session/send_message/poll_for_reply/close_session`, `skills.knowledge.search_guidelines` (RAG over `knowledge_chunks`), `skills.member.get_profile`, `db.state_io.insert_outreach_session`.
- **System-prompt skeleton:** (real impl) drives turn-by-turn LLM phrasing + survey extraction; tracks conversation state; respects identity-mismatch hard gate; caps at 30 turns.
- **Constraints:**
  - Identity mismatch → `CLOSED_MEMBER_DECLINED` (no further outreach).
  - 3 messaging attempts at 4-hour gaps before `CLOSED_NO_CONTACT`.
  - SDOH detection rules: `no_pcp_appt`, `transport_gap`, `med_affordability_gap`, `language_barrier`, `lives_alone` (stub only emits `no_pcp_appt`).
  - RAG-grounded CMP pitch citations recorded with the outreach session (real impl).
  - Idempotent re-entry: prior complete session shortcuts the work + still advances state.
- **Model:** stub no LLM. Real impl: `BEDROCK_MODEL_ID` (Sonnet 4 override).
- **File:** [agents/outreach_agent.py](agents/outreach_agent.py).
- **Spec:** [agent_prompts/03_outreach_agent.md](agent_prompts/03_outreach_agent.md).
- **Endpoint:** `GET /cases/{id}/outreach` ([api/routes/outreach.py](api/routes/outreach.py)).

### 04 — agent_assist_agent  *(STUB, Step 11; foreground)*

- **Role:** real-time CM voice-callback co-pilot. Streams transcript, scores sentiment, surfaces 4 sequential AI prompts on conversation beats, captures verbal consent for mid-call scheduling.
- **Trigger:** *foreground* via `POST /cases/{id}/call/start` (NOT orchestrator-dispatched). The endpoint spawns the agent as an asyncio task and returns 202 immediately.
- **Input state → Output state:** `OUTREACH_COMPLETE → CM_CALLBACK_IN_PROGRESS` (the endpoint transitions on call start; the agent itself does NOT transition state at the end). Step 12's scheduling_agent moves the case onward to `APPOINTMENT_BOOKED`.
- **Tools used:** `skills.transcript.subscribe` (async iterator), `skills.sentiment.score_turn`, `skills.ui.push_prompt`, `skills.ui.push_sentiment`, `db.state_io.update_call_session`.
- **Prompts (POC):**
  1. `p1_breathing` — last SpO2, taper status, med pickup (triggered on "how have you been")
  2. `p2_oximeter` — Valley CHC pulse oximeter program (triggered on "inhaler")
  3. `p3_transport` — plan-covered non-emergency medical transport (triggered on "transportation")
  4. `p4_schedule` — Dr. Garcia availability + scheduling_agent armed (triggered on "next week")
- **Constraints:**
  - 30-turn safety cap.
  - Each prompt fires exactly once (in canonical order p1..p4 for the canned John Martinez transcript).
  - `consent_captured` is keyed on a single substring (`"yes, please"`); real impl uses LLM classification per the teammate spec.
  - Persists `CallSession` every 2 turns for live UI polling; final write flips `status=complete` + `ended_at`.
- **Model:** stub no LLM. Real impl: `BEDROCK_MODEL_ID` (Sonnet 4 override).
- **File:** [agents/agent_assist_agent.py](agents/agent_assist_agent.py).
- **Spec:** [agent_prompts/04_agent_assist_agent.md](agent_prompts/04_agent_assist_agent.md).
- **Endpoints:** `POST /cases/{id}/call/start`, `GET /cases/{id}/call` ([api/routes/call.py](api/routes/call.py)).

### 05 — scheduling_agent  *(STUB, Step 12; CM-triggered)*

- **Role:** mid-call PCP appointment booking with full artifact suite (SMS, PDF, calendar, CRM mirror, referral, follow-up task).
- **Trigger:** *CM-triggered* via `POST /cases/{id}/schedule` after verbal consent appears in the live transcript. NOT orchestrator-dispatched.
- **Input state → Output state:** `CM_CALLBACK_IN_PROGRESS → APPOINTMENT_BOOKED`.
- **Tools used:** `skills.scheduling.get_availability/book_appointment`, `skills.sms.send`, `skills.templates.render` + `skills.pdf.render`, `skills.crm.create_appointment/create_task`, `skills.calendar.add_event`, `db.state_io.insert_appointment/insert_referral`.
- **Constraints:**
  - Pre-condition: `latest CallSession.consent_captured == True` (raises `ConsentNotCaptured` if not).
  - Slot picker: earliest match for `outreach.survey.callback_preference` within the 7–10-day window from discharge. Falls back to any slot if no preference match.
  - Stub hardcodes the John Martinez Oct 10 14:00 slot via the canned `PCP_LUIS_GARCIA_SLOTS_OCT_2026` fixture.
  - Best-effort side effects: in the real impl, PDF render / SMS failure should NOT block the state transition once the appointment row is persisted (artifacts are re-triable). Stub treats them as in-line happy path.
  - Always creates the Valley CHC pulse oximeter referral as a community/device row (POC pattern; real impl reads `case.referrals` injectable list).
- **Model:** stub no LLM. Real impl uses an LLM to re-verify consent against the last N transcript turns + to pick a slot semantically when the picker has multiple candidates.
- **File:** [agents/scheduling_agent.py](agents/scheduling_agent.py).
- **Spec:** [agent_prompts/05_scheduling_agent.md](agent_prompts/05_scheduling_agent.md).
- **Endpoints:** `POST /cases/{id}/schedule`, `GET /cases/{id}/appointment` ([api/routes/scheduling.py](api/routes/scheduling.py)).

_(work agents 06–07: stubs land in Steps 13, 14)_
