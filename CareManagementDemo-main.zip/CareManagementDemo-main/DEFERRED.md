# DEFERRED

> Things that are coded but not live-verified, plus open cross-cutting items. Move into [BUILD_LOG.md](BUILD_LOG.md) as they get resolved.

## Cross-cutting

- **STP rules** — `is_stp(case)` returns `False` for all cases. 5 candidate rules awaiting business sign-off. (See [agents.md](agents.md) §"Open business questions".)
- **Stage 3 distinct gate** — currently merged with the document_extraction reviewer gate. If business splits it, a `DISCHARGE_REVIEWED` state goes between `DOCUMENT_APPROVED` and `OUTREACH_SCHEDULED`.
- **Intervenability denominator** — `/40` in code; POC text says `/50`. Awaiting business confirmation.
- **Next.js UI** — not in this build's scope. CM reviewer dashboard + discharge intake portal land as a follow-up.

## Coded-but-not-verified

- **`db/state.py::update_case_state`** — written and unit-importable but not yet exercised against a real state transition (no agent has called it yet — `CASE-00099999` is parked in `DISCHARGE_RECEIVED`). First live exercise happens in Step 5 when the orchestrator drives a case through transitions.
- **`skills.pdf` real PDF path** — only the HTML fallback has been exercised on Windows. The WeasyPrint branch will activate once GTK3 + the `weasyprint` Python package are installed; first dependency for Step 12 (scheduling agent's appointment confirmation PDF).
- **`skills.webhook` retry semantics** — tenacity retry (3 attempts, 0.5–4s backoff) verified for the failure path; success path not yet exercised against a real sink.
- **`skills.ui` WebSocket fan-out** — currently log-file-only. Real WebSocket lands in Step 7+ when the FastAPI surface is up.

## Python / runtime gotchas

- **Windows asyncio + psycopg async** — Windows' default `ProactorEventLoop` is incompatible with psycopg async. `db.pool.configure_async_loop_policy()` switches to `WindowsSelectorEventLoopPolicy`. Any script that uses `asyncio.run` against the DB must call it; uvicorn handles this itself.
- **`skills.email` module name** — note this **does not** shadow the stdlib `email` package because `skills/` is a subpackage. Inside `skills/email.py` itself, use `from email import mime` (the stdlib import is unambiguous; only top-level `import email` in skills/email.py would be circular).

## Security / ops

- **AWS credentials in `.env`** — long-lived IAM user keys (`AKIA...` prefix) for IAM user `Varun_proxzar` (account `008971635132`). Acceptable for the POC. For production: rotate to scoped Bedrock-only role, use STS short-lived creds or IAM Identity Center. Confirm `.env` never gets committed.
- **`BEDROCK_MODEL_ID` override**: `.env` is set to `us.anthropic.claude-sonnet-4-20250514-v1:0` (Sonnet 4 May-2025), not the build-prompt default Haiku 4.5. Documented in BUILD_LOG Step 3. Affects every agent invocation from Step 5 onward.

## External integrations stubbed as mocks

These need real-system wiring once vendor decisions land. Each is marked `# MOCK:` in code with a TODO.

| Mock | Real target |
|---|---|
| `EHR_DOCUMENT_STORE` | FHIR R4 `/DocumentReference` |
| `MEMBER_DATABASE` | Plan eligibility API |
| `CLAIMS_DATA_WAREHOUSE` | Plan analytics API |
| `CRM_SYSTEM` | Salesforce Health Cloud |
| `PCP_SCHEDULING_SYSTEM` | Epic MyChart Scheduling |
| `SMS_GATEWAY` | Twilio Messaging API |
| `PATIENT_JOURNEY_CALENDAR` | Member portal calendar service |
| `FORMULARY_API` | PBM API |
| `MESSAGING_CHANNEL_PLATFORM` | Twilio Conversations (or vendor TBD) |
| `TRANSCRIPT_STREAM` | AWS Transcribe Medical (or vendor TBD) |
| `SENTIMENT_SERVICE` | Vendor TBD |
| `COMMUNITY_RESOURCES_DIRECTORY` | Findhelp / Aunt Bertha (or plan-internal directory) |
