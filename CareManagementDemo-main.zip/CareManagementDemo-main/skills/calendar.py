"""Patient Journey Calendar.

# MOCK: member portal calendar service
TODO: replace with real member-portal calendar API.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from skills._common import get_logger, mint_id


@dataclass
class JourneyEvent:
    event_id: str
    case_id: str
    member_id: str
    title: str
    when: datetime
    kind: str
    payload: dict[str, Any] = field(default_factory=dict)


_EVENTS: dict[str, JourneyEvent] = {}


def add_event(
    case_id: str,
    member_id: str,
    when: datetime,
    title: str,
    kind: str = "appointment",
    **payload: Any,
) -> str:
    """Append an event to the member's journey calendar."""
    log = get_logger(case_id)
    event_id = mint_id("appt") if kind == "appointment" else f"JE-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
    _EVENTS[event_id] = JourneyEvent(
        event_id=event_id,
        case_id=case_id,
        member_id=member_id,
        title=title,
        when=when,
        kind=kind,
        payload=payload,
    )
    log.info(
        "calendar_event_added",
        event_id=event_id,
        when=when.isoformat(),
        kind=kind,
        title=title,
    )
    return event_id


def _all_events() -> list[JourneyEvent]:
    return list(_EVENTS.values())


def _reset() -> None:
    _EVENTS.clear()
