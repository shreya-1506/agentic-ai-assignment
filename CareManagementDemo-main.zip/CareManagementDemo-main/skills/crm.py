"""CRM skill.

# MOCK: Salesforce Health Cloud
TODO: replace with real Salesforce Health Cloud REST calls + OAuth refresh.

All CRM records live in an in-memory dict for the POC. State persists for
the lifetime of the Python process.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from skills._common import get_logger, mint_crm_id, mint_task_id


@dataclass
class CrmCaseRecord:
    crm_case_number: str
    case_id: str
    member_id: str
    fields: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass
class CrmTask:
    task_id: str
    case_id: str
    title: str
    due_at: datetime | None
    priority: str
    payload: dict[str, Any]
    status: str = "open"
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


_CASES: dict[str, CrmCaseRecord] = {}
_TASKS: dict[str, CrmTask] = {}


def create_case(
    case_id: str,
    member_id: str,
    **fields: Any,
) -> str:
    """Create a CRM case record. Returns the assigned `CRM-NNNNNNNN` number."""
    log = get_logger(case_id)
    crm_case_number = mint_crm_id()
    _CASES[crm_case_number] = CrmCaseRecord(
        crm_case_number=crm_case_number,
        case_id=case_id,
        member_id=member_id,
        fields=fields,
    )
    log.info("crm_case_created", crm_case_number=crm_case_number, member_id=member_id)
    return crm_case_number


def update_case(
    case_id: str,
    crm_case_number: str,
    **fields: Any,
) -> None:
    log = get_logger(case_id)
    rec = _CASES.get(crm_case_number)
    if rec is None:
        log.warning("crm_case_not_found", crm_case_number=crm_case_number)
        return
    rec.fields.update(fields)
    log.info("crm_case_updated", crm_case_number=crm_case_number, fields=list(fields))


def create_task(
    case_id: str,
    title: str,
    *,
    due_at: datetime | None = None,
    priority: str = "normal",
    links: list[str] | None = None,
    **payload: Any,
) -> str:
    """Create a CRM workflow task. Returns the assigned `TASK-NNNNNNNN` id."""
    log = get_logger(case_id)
    task_id = mint_task_id()
    _TASKS[task_id] = CrmTask(
        task_id=task_id,
        case_id=case_id,
        title=title,
        due_at=due_at,
        priority=priority,
        payload={"links": links or [], **payload},
    )
    log.info("crm_task_created", task_id=task_id, title=title, priority=priority)
    return task_id


def create_appointment(
    case_id: str,
    appointment_id: int,
    slot: datetime,
    pcp_id: str,
) -> str:
    """Mirror the booked appointment into CRM. Returns the CRM appointment record id."""
    log = get_logger(case_id)
    crm_appt_id = mint_crm_id()
    log.info(
        "crm_appointment_created",
        crm_appt_id=crm_appt_id,
        appointment_id=appointment_id,
        slot=slot.isoformat(),
        pcp_id=pcp_id,
    )
    return crm_appt_id


def queue_for_cm(case_id: str, reason: str) -> None:
    """Route the case to the human CM queue."""
    log = get_logger(case_id)
    log.info("crm_queued_for_cm", reason=reason)


# ---- test/inspection helpers (not part of the public skill contract) -------


def _all_cases() -> list[CrmCaseRecord]:
    return list(_CASES.values())


def _all_tasks() -> list[CrmTask]:
    return list(_TASKS.values())


def _reset() -> None:
    _CASES.clear()
    _TASKS.clear()
