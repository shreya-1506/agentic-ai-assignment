"""Skills layer — deterministic tools used by agents.

Conventions enforced across this package:
  - Every public tool accepts `case_id: str` and binds it on every structlog
    line via `skills._common.get_logger(case_id)`.
  - I/O types are Pydantic v2 models from `models.schemas` (or local typed
    dataclasses for ephemeral skill-internal shapes).
  - Errors are `SkillError` subclasses from `models.exceptions`.
  - PII (names, DOB, MRN, phone) is masked in logs.
  - No LLM calls inside skills — except `skills.bedrock`, which IS the LLM
    wrapper and is treated as shared infrastructure (alongside `skills._common`).
  - No cross-skill imports of business logic. Skills may import from
    `models`, `db`, `skills._common`, and `skills.bedrock` only.
  - Every mocked external integration carries a `# MOCK:` comment naming
    the real system it stands in for.
"""
