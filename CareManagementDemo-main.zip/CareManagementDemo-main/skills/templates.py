"""Jinja2 string-template renderer.

Templates live in `templates/`. Not a mock — `Jinja2` is a real dependency.
PDF generation lives in `skills.pdf`; this module is for plain-text or HTML
output (e.g., SMS body, email body, care-plan section blocks).
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, StrictUndefined, select_autoescape

from skills._common import get_logger

PROJECT_ROOT = Path(__file__).resolve().parent.parent
TEMPLATES_DIR = PROJECT_ROOT / "templates"


@lru_cache(maxsize=1)
def _env() -> Environment:
    return Environment(
        loader=FileSystemLoader(str(TEMPLATES_DIR)),
        autoescape=select_autoescape(["html", "htm", "xml"]),
        undefined=StrictUndefined,
        trim_blocks=True,
        lstrip_blocks=True,
    )


def render(case_id: str, template_name: str, context: dict[str, Any]) -> str:
    """Render `templates/<template_name>` with `context`. Returns the string."""
    log = get_logger(case_id)
    tpl = _env().get_template(template_name)
    out = tpl.render(**context)
    log.info("template_rendered", template=template_name, chars=len(out))
    return out
