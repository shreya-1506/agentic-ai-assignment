"""Case-events queue.

Thin wrapper around `db.state_io` so the `communication_agent` can read
its queue without leaking SQL concerns into agent code. The communication
agent's event loop will:
  1. `pop_unprocessed(limit)` to get a batch
  2. fan out to sms/email/webhook
  3. `mark_processed(event_id, delivery_status)` per event
"""

from __future__ import annotations

from typing import Any

from db.pool import connection
from db.state_io import (
    insert_case_event,
    mark_event_processed,
    pop_unprocessed_events,
)
from skills._common import get_logger


async def emit(
    case_id: str,
    event_type: str,
    payload: dict[str, Any] | None = None,
) -> int:
    """Queue a new milestone event for the communication_agent to deliver."""
    log = get_logger(case_id)
    async with connection() as conn:
        async with conn.transaction():
            event_id = await insert_case_event(conn, case_id, event_type, payload)
    log.info("event_emitted", event_type=event_type, event_id=event_id)
    return event_id


async def pop_unprocessed(limit: int = 50) -> list[dict[str, Any]]:
    """Return up to `limit` unprocessed events for the comms daemon."""
    async with connection() as conn:
        async with conn.transaction():
            return await pop_unprocessed_events(conn, limit)


async def mark_processed(event_id: int, delivery_status: str) -> None:
    """Mark an event as delivered (or `failed`/`skipped`)."""
    async with connection() as conn:
        async with conn.transaction():
            await mark_event_processed(conn, event_id, delivery_status)
