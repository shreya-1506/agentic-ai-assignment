"""POC seed fixtures — the John Martinez case and his orbit.

Single canonical place where mock skills look up "what does Member X look like?"
data. Keeps mocks consistent so a case can walk end-to-end with believable
content. Real production wiring replaces every mock; this file becomes dead.
"""

from __future__ import annotations

from datetime import date, datetime, timezone
from typing import Any

# ---- The POC member ---------------------------------------------------------

JOHN_MARTINEZ_MEMBER_ID = "MBR-00847291"

JOHN_MARTINEZ_PROFILE: dict[str, Any] = {
    "member_id": JOHN_MARTINEZ_MEMBER_ID,
    "first_name": "John",
    "last_name": "Martinez",
    "dob": date(1952, 3, 15),
    "phone": "(555) 847-2910",
    "email": "john.martinez@example.com",
    "preferred_language": "English",
    "plan_name": "BlueCross Premier",
    "pcp_name": "Dr. Luis Garcia",
    "pcp_id": "PCP-00042100",
    "address": {
        "line1": "1742 Oak Avenue",
        "line2": None,
        "city": "Springfield",
        "state": "CA",
        "postal_code": "94101",
    },
}

JOHN_MARTINEZ_CLAIMS_HISTORY: dict[str, Any] = {
    "lookback_months": 24,
    "admits": [
        {
            "admit_date": "2025-11-12",
            "discharge_date": "2025-11-15",
            "facility": "St. Mary's Medical Center",
            "primary_dx": "J44.1",
            "length_of_stay": 3,
        },
        {
            "admit_date": "2026-04-21",
            "discharge_date": "2026-04-23",
            "facility": "St. Mary's Medical Center",
            "primary_dx": "J44.1",
            "length_of_stay": 2,
        },
    ],
    "ed_visits": [
        {"date": "2026-01-08", "facility": "St. Mary's ED", "chief_complaint": "shortness of breath"},
        {"date": "2026-07-15", "facility": "St. Mary's ED", "chief_complaint": "wheeze + cough"},
    ],
    "care_gaps": [
        {"gap_type": "annual_wellness_visit", "open_since": "2026-01-01"},
        {"gap_type": "pneumococcal_vaccine", "open_since": "2025-10-01"},
    ],
    "prior_engagement": {
        "prior_tcm_count": 0,
        "prior_cmp_enrollment": False,
        "last_outreach_attempts": 0,
    },
}

# ---- The POC case -----------------------------------------------------------

JOHN_MARTINEZ_DISCHARGE_EVENT: dict[str, Any] = {
    "event_type": "DischargeNotification",
    "fhir_resource": "Encounter",
    "member_id": JOHN_MARTINEZ_MEMBER_ID,
    "admit_date": "2026-10-02",
    "discharge_date": "2026-10-05",
    "facility": "St. Mary's Medical Center",
    "attending_physician": "Dr. Priya Patel",
    "primary_dx_code": "J44.1",
    "primary_dx_description": "Chronic obstructive pulmonary disease with acute exacerbation",
    "length_of_stay_days": 3,
    "pcp_name": "Dr. Luis Garcia",
    "pcp_id": "PCP-00042100",
    "plan_name": "BlueCross Premier",
}

# ---- Mock extracted-discharge-summary fields (per poc.md) -------------------

JOHN_MARTINEZ_EXTRACTED_FIELDS: list[dict[str, Any]] = [
    {"field_name": "medical_center",        "value": "St. Mary's Medical Center",      "confidence": 0.98, "flagged": False, "source_page": 1},
    {"field_name": "patient_name",          "value": "John Martinez",                  "confidence": 0.99, "flagged": False, "source_page": 1},
    {"field_name": "mrn",                   "value": "MRN-78234916",                   "confidence": 0.97, "flagged": False, "source_page": 1},
    {"field_name": "admit_date",            "value": "2026-10-02",                     "confidence": 0.96, "flagged": False, "source_page": 1},
    {"field_name": "discharge_date",        "value": "2026-10-05",                     "confidence": 0.97, "flagged": False, "source_page": 1},
    {"field_name": "length_of_stay",        "value": "3",                              "confidence": 0.96, "flagged": False, "source_page": 1},
    {"field_name": "attending_physician",   "value": "Dr. Priya Patel",                "confidence": 0.96, "flagged": False, "source_page": 1},
    {"field_name": "primary_diagnosis",     "value": "COPD with acute exacerbation (J44.1)", "confidence": 0.98, "flagged": False, "source_page": 1},
    {"field_name": "hand_off_summary",      "value": "Patient stabilized on oral steroids; weaning supplemental O2; ambulating with mild dyspnea.", "confidence": 0.93, "flagged": False, "source_page": 2},
    {"field_name": "reason_for_hospitalization", "value": "Acute COPD exacerbation with hypoxia, treated with IV methylprednisolone and bronchodilators.", "confidence": 0.91, "flagged": False, "source_page": 2},
    {"field_name": "medication_changes",    "value": "Prednisone 40 mg PO daily tapering over 14 days; Albuterol HFA 90 mcg PRN; Tiotropium 18 mcg inhalation daily; Azithromycin 500 mg PO ×5 days", "confidence": 0.72, "flagged": True, "source_page": 3},
    {"field_name": "last_spo2",             "value": "93% on room air (Day 3)",        "confidence": 0.90, "flagged": False, "source_page": 2},
    {"field_name": "discharge_disposition", "value": "Home with self-care",            "confidence": 0.95, "flagged": False, "source_page": 3},
]

# ---- The POC outreach (messaging) — canned member replies ------------------

JOHN_MARTINEZ_MESSAGING_REPLIES: list[str] = [
    "Speaking.",                                                          # name verify
    "March 15th, 1952.",                                                  # DOB verify
    "A bit short of breath in the mornings — better than when I was admitted though.",
    "Yes, picked them up yesterday at CVS.",                              # meds
    "No, I haven't called yet.",                                          # PCP appt
    "Yes, that sounds really helpful.",                                   # CMP enrollment
    "Afternoon usually works best for me.",                               # callback preference
]

# ---- The POC live-call transcript (CM Sarah ↔ John) -----------------------

JOHN_MARTINEZ_CALL_TRANSCRIPT: list[dict[str, Any]] = [
    {"speaker": "cm",     "text": "Hi John, this is Sarah from BlueCross Premier — how have you been since you got home?", "ts_offset_s": 0},
    {"speaker": "member", "text": "Doing okay, the mornings are still a little tight on the breathing.",                    "ts_offset_s": 8},
    {"speaker": "cm",     "text": "Got it — how is the inhaler working? Are you using the Tiotropium every morning?",        "ts_offset_s": 22},
    {"speaker": "member", "text": "I am, yes. The Albuterol I use as needed, maybe once a day.",                            "ts_offset_s": 35},
    {"speaker": "cm",     "text": "Good. Do you have a way to check your oxygen at home, like a pulse oximeter?",            "ts_offset_s": 60},
    {"speaker": "member", "text": "No, I don't have one.",                                                                  "ts_offset_s": 72},
    {"speaker": "cm",     "text": "I can connect you to Valley Community Health Center — they have a free pulse oximeter program.", "ts_offset_s": 85},
    {"speaker": "cm",     "text": "And about getting to appointments — do you have reliable transportation?",                "ts_offset_s": 110},
    {"speaker": "member", "text": "My daughter drives me sometimes, but it's not always available.",                        "ts_offset_s": 122},
    {"speaker": "cm",     "text": "Your plan covers non-emergency medical transport — I'll note that for your follow-ups.", "ts_offset_s": 138},
    {"speaker": "cm",     "text": "I'd like to get you in to see Dr. Garcia within the next week. I have our Scheduling Agent available right now — it can book Dr. Garcia for you while we're on the call. Would that be alright?", "ts_offset_s": 175},
    {"speaker": "member", "text": "Yes, please.",                                                                            "ts_offset_s": 192},
]

JOHN_MARTINEZ_CONSENT_EXCERPT = "Yes, please."

# ---- Discharge facility + PCP availability (mock scheduling) ---------------

PCP_LUIS_GARCIA_SLOTS_OCT_2026: list[datetime] = [
    datetime(2026, 10, 8,  9, 30, tzinfo=timezone.utc),
    datetime(2026, 10, 9,  11, 0, tzinfo=timezone.utc),
    datetime(2026, 10, 10, 14, 0, tzinfo=timezone.utc),  # the POC booking
    datetime(2026, 10, 13, 15, 30, tzinfo=timezone.utc),
    datetime(2026, 10, 14, 10, 0, tzinfo=timezone.utc),
]

# ---- Community resources (pulse oximeter, transport) -----------------------

COMMUNITY_RESOURCES: list[dict[str, Any]] = [
    {
        "name": "Valley Community Health Center",
        "resource_type": "device",
        "subtype": "pulse_oximeter",
        "description": "Free pulse oximeter program for COPD patients",
        "contact": "valley-chc.org",
        "phone": "(555) 200-1144",
        "zip_coverage": ["94101", "94102", "94103"],
    },
    {
        "name": "Springfield Rides",
        "resource_type": "transport",
        "subtype": "non_emergency_medical",
        "description": "Volunteer-driven rides to medical appointments",
        "contact": "springfield-rides.org",
        "phone": "(555) 200-7755",
        "zip_coverage": ["94101", "94102", "94103", "94104"],
    },
]

# ---- Formulary lookup (plan = BlueCross Premier) ---------------------------

BLUECROSS_PREMIER_FORMULARY: dict[str, dict[str, Any]] = {
    "prednisone":     {"covered": True, "tier": 1, "prior_auth_required": False, "copay_estimate": 5.00},
    "albuterol":      {"covered": True, "tier": 1, "prior_auth_required": False, "copay_estimate": 10.00},
    "tiotropium":     {"covered": True, "tier": 2, "prior_auth_required": False, "copay_estimate": 35.00},
    "azithromycin":   {"covered": True, "tier": 1, "prior_auth_required": False, "copay_estimate": 8.00},
}
