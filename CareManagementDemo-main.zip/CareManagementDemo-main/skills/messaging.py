"""Async messaging channel (member outreach conversations).

# MOCK: Twilio Conversations / vendor TBD
TODO: replace with real vendor API + webhook handling.

In mock mode, `poll_for_reply` returns canned John Martinez replies one at
a time per session. Outbound `send_message` is logged but not transmitted.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from skills._common import get_logger, mint_session_id, redact_phone
from skills._fixtures import JOHN_MARTINEZ_MESSAGING_REPLIES

PROJECT_ROOT = Path(__file__).resolve().parent.parent
OUTBOX = PROJECT_ROOT / "data" / "outbox"
MESSAGING_LOG = OUTBOX / "messaging.log"


@dataclass
class MessagingSession:
    session_id: str
    case_id: str
    member_id: str
    member_phone: str
    is_open: bool = True
    sent: list[dict[str, Any]] = field(default_factory=list)
    canned_reply_index: int = 0
    opened_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    closed_at: datetime | None = None


_SESSIONS: dict[str, MessagingSession] = {}


def open_session(case_id: str, member_id: str, member_phone: str) -> str:
    """Open a new messaging session. Returns the `MS-NNNNNNNN` session id."""
    log = get_logger(case_id)
    sid = mint_session_id()
    _SESSIONS[sid] = MessagingSession(
        session_id=sid,
        case_id=case_id,
        member_id=member_id,
        member_phone=member_phone,
    )
    log.info(
        "messaging_session_opened",
        session_id=sid,
        member_id=member_id,
        member_phone=redact_phone(member_phone),
    )
    return sid


def send_message(case_id: str, session_id: str, text: str) -> None:
    """Send a message to the member side of the session."""
    log = get_logger(case_id)
    sess = _SESSIONS.get(session_id)
    if sess is None or not sess.is_open:
        log.warning("messaging_session_invalid", session_id=session_id)
        return
    sess.sent.append({"ts": datetime.now(timezone.utc).isoformat(), "text": text})

    OUTBOX.mkdir(parents=True, exist_ok=True)
    with MESSAGING_LOG.open("a", encoding="utf-8") as fh:
        fh.write(f"{datetime.now(timezone.utc).isoformat()}\t{case_id}\t{session_id}\t>>>\t{text}\n")

    log.info("messaging_sent", session_id=session_id, chars=len(text))


def poll_for_reply(
    case_id: str,
    session_id: str,
    timeout_seconds: int = 10,
) -> str | None:
    """Return the next canned reply for the session, or None if exhausted."""
    log = get_logger(case_id)
    sess = _SESSIONS.get(session_id)
    if sess is None:
        log.warning("messaging_session_invalid", session_id=session_id)
        return None

    if sess.canned_reply_index >= len(JOHN_MARTINEZ_MESSAGING_REPLIES):
        log.info("messaging_no_more_replies", session_id=session_id)
        return None

    reply = JOHN_MARTINEZ_MESSAGING_REPLIES[sess.canned_reply_index]
    sess.canned_reply_index += 1

    OUTBOX.mkdir(parents=True, exist_ok=True)
    with MESSAGING_LOG.open("a", encoding="utf-8") as fh:
        fh.write(f"{datetime.now(timezone.utc).isoformat()}\t{case_id}\t{session_id}\t<<<\t{reply}\n")

    log.info(
        "messaging_received",
        session_id=session_id,
        reply_index=sess.canned_reply_index - 1,
        chars=len(reply),
    )
    return reply


def close_session(case_id: str, session_id: str) -> None:
    log = get_logger(case_id)
    sess = _SESSIONS.get(session_id)
    if sess is None:
        return
    sess.is_open = False
    sess.closed_at = datetime.now(timezone.utc)
    log.info(
        "messaging_session_closed",
        session_id=session_id,
        outbound=len(sess.sent),
        inbound=sess.canned_reply_index,
    )


def _reset() -> None:
    _SESSIONS.clear()
