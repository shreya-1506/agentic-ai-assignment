"""Bedrock LLM + embedding wrapper.

Treated as shared infrastructure (like `skills._common`): other skill
modules may import from it. Agents call `invoke_chat` for reasoning;
`embed_text` is used by `skills.knowledge` for RAG retrieval and by
`scripts.ingest_knowledge` for one-shot ingestion.

Uses the Bedrock **Converse** API for chat (provider-normalized; cleaner
than `invoke_model` with Anthropic-specific JSON envelopes).
"""

from __future__ import annotations

import json
import os
import threading
from typing import Any, Literal

import boto3

from models.exceptions import BedrockError
from skills._common import get_logger

# -----------------------------------------------------------------------------
# Client singleton
# -----------------------------------------------------------------------------

_lock = threading.Lock()
_client: Any | None = None


def _region() -> str:
    return (
        os.environ.get("BEDROCK_REGION")
        or os.environ.get("AWS_REGION")
        or os.environ.get("AWS_DEFAULT_REGION")
        or "us-east-1"
    )


def _get_client() -> Any:
    global _client
    with _lock:
        if _client is None:
            _client = boto3.client("bedrock-runtime", region_name=_region())
        return _client


def _chat_model_id() -> str:
    return os.environ.get(
        "BEDROCK_MODEL_ID",
        "us.anthropic.claude-haiku-4-5-20251001-v1:0",
    )


def _embed_model_id() -> str:
    return os.environ.get("BEDROCK_EMBEDDING_MODEL_ID", "amazon.titan-embed-text-v2:0")


def _embed_dims() -> int:
    return int(os.environ.get("BEDROCK_EMBEDDING_DIMENSIONS", "1024"))


# -----------------------------------------------------------------------------
# Chat
# -----------------------------------------------------------------------------


Role = Literal["user", "assistant"]


def invoke_chat(
    *,
    case_id: str,
    system: str,
    messages: list[dict[str, Any]],
    max_tokens: int = 1024,
    temperature: float = 0.0,
    model_id: str | None = None,
) -> str:
    """Call the configured chat model via Bedrock Converse and return text.

    `messages` is the normal `[{"role": "user", "content": "..."}, ...]` shape.
    String content is auto-wrapped into Converse's `[{"text": ...}]` form.

    Raises `BedrockError` on any failure.
    """
    log = get_logger(case_id, model_id=model_id or _chat_model_id())
    try:
        client = _get_client()
        converse_messages = _to_converse_messages(messages)
        response = client.converse(
            modelId=model_id or _chat_model_id(),
            system=[{"text": system}] if system else None,
            messages=converse_messages,
            inferenceConfig={"maxTokens": max_tokens, "temperature": temperature},
        )
        content = response["output"]["message"]["content"]
        text = "".join(block.get("text", "") for block in content if "text" in block)
        log.info(
            "bedrock_chat_ok",
            input_tokens=response.get("usage", {}).get("inputTokens"),
            output_tokens=response.get("usage", {}).get("outputTokens"),
            stop_reason=response.get("stopReason"),
        )
        return text
    except Exception as exc:
        log.error("bedrock_chat_failed", error=str(exc), error_type=type(exc).__name__)
        raise BedrockError(f"chat call failed: {exc}", case_id=case_id) from exc


def _to_converse_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for m in messages:
        role = m["role"]
        content = m["content"]
        if isinstance(content, str):
            blocks = [{"text": content}]
        elif isinstance(content, list):
            blocks = content
        else:
            blocks = [{"text": str(content)}]
        out.append({"role": role, "content": blocks})
    return out


# -----------------------------------------------------------------------------
# Embeddings (Titan v2)
# -----------------------------------------------------------------------------


def embed_text(*, case_id: str, text: str) -> list[float]:
    """Embed `text` with the configured Titan v2 model. Returns a list of floats."""
    log = get_logger(case_id, model_id=_embed_model_id())
    try:
        client = _get_client()
        response = client.invoke_model(
            modelId=_embed_model_id(),
            body=json.dumps(
                {"inputText": text, "dimensions": _embed_dims(), "normalize": True}
            ),
            contentType="application/json",
            accept="application/json",
        )
        payload = json.loads(response["body"].read())
        vec = payload["embedding"]
        if len(vec) != _embed_dims():
            raise BedrockError(
                f"unexpected embedding dim: got {len(vec)} expected {_embed_dims()}",
                case_id=case_id,
            )
        log.info(
            "bedrock_embed_ok",
            input_tokens=payload.get("inputTextTokenCount"),
            dims=len(vec),
        )
        return vec
    except BedrockError:
        raise
    except Exception as exc:
        log.error("bedrock_embed_failed", error=str(exc), error_type=type(exc).__name__)
        raise BedrockError(f"embed call failed: {exc}", case_id=case_id) from exc
