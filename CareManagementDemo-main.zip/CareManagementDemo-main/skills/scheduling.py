"""PCP scheduling.

# MOCK: Epic MyChart Scheduling
TODO: replace with real scheduling API.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from models.schemas import Appointment, AppointmentStatus
from skills._common import get_logger
from skills._fixtures import PCP_LUIS_GARCIA_SLOTS_OCT_2026


def get_availability(
    case_id: str,
    pcp_id: str,
    window_start: datetime,
    window_end: datetime,
) -> list[datetime]:
    """Return available slots within `[window_start, window_end]`."""
    log = get_logger(case_id)
    slots = [
        s for s in PCP_LUIS_GARCIA_SLOTS_OCT_2026
        if window_start <= s <= window_end
    ]
    log.info(
        "scheduling_availability",
        pcp_id=pcp_id,
        window_start=window_start.isoformat(),
        window_end=window_end.isoformat(),
        slot_count=len(slots),
    )
    return slots


def book_appointment(
    case_id: str,
    pcp_id: str,
    slot: datetime,
    *,
    provider_name: str = "Dr. Luis Garcia",
    location: str = "Springfield Primary Care Clinic, 250 Main St.",
    specialty: str = "Primary Care",
) -> Appointment:
    """Book the slot. Returns the constructed `Appointment` (unsaved)."""
    log = get_logger(case_id)
    appt = Appointment(
        case_id=case_id,
        provider_id=pcp_id,
        provider_name=provider_name,
        specialty=specialty,
        scheduled_at=slot,
        location=location,
        status=AppointmentStatus.BOOKED,
    )
    log.info(
        "scheduling_booked",
        pcp_id=pcp_id,
        slot=slot.isoformat(),
        provider=provider_name,
    )
    return appt
