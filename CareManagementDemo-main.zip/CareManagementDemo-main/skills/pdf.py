"""PDF rendering via Jinja2 + WeasyPrint.

WeasyPrint requires the GTK3 runtime on Windows. To avoid hard-failing
imports on machines without GTK3, the import is lazy: if WeasyPrint is
unavailable we fall back to writing the rendered HTML to disk and log a
warning. The artifact path is returned either way.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from skills._common import get_logger
from skills.templates import render as render_template

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DOCS_DIR = PROJECT_ROOT / "data" / "documents"


def render(
    case_id: str,
    template_name: str,
    context: dict[str, Any],
    *,
    output_path: Path | str | None = None,
) -> Path:
    """Render `template_name` to a PDF (or HTML fallback) and return the path."""
    log = get_logger(case_id)
    DOCS_DIR.mkdir(parents=True, exist_ok=True)
    html = render_template(case_id, template_name, context)

    out = Path(output_path) if output_path else DOCS_DIR / f"{case_id}_{Path(template_name).stem}.pdf"

    try:
        import weasyprint  # type: ignore[import-not-found]
        weasyprint.HTML(string=html).write_pdf(str(out))
        log.info("pdf_rendered", template=template_name, path=str(out))
        return out
    except Exception as exc:  # GTK3 missing, weasyprint import failure, etc.
        fallback = out.with_suffix(".html")
        fallback.write_text(html, encoding="utf-8")
        log.warning(
            "pdf_fallback_to_html",
            template=template_name,
            path=str(fallback),
            reason=f"{type(exc).__name__}: {exc}",
        )
        return fallback
