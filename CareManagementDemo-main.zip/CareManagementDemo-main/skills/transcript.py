"""Live voice-call transcript stream.

# MOCK: AWS Transcribe Medical / vendor TBD
TODO: replace with real STT stream subscription.

For the POC `get_recent` returns the canned John Martinez transcript trimmed
to the last `n` turns. `subscribe` yields turns one-at-a-time with a small
sleep, simulating a live feed.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from datetime import datetime, timezone
from typing import Any

from models.schemas import CallTurn
from skills._common import get_logger
from skills._fixtures import JOHN_MARTINEZ_CALL_TRANSCRIPT


def _full_turns() -> list[CallTurn]:
    base = datetime(2026, 10, 9, 16, 0, 0, tzinfo=timezone.utc)
    return [
        CallTurn(
            speaker=row["speaker"],
            text=row["text"],
            timestamp=base + _offset(row["ts_offset_s"]),
        )
        for row in JOHN_MARTINEZ_CALL_TRANSCRIPT
    ]


def _offset(seconds: int):
    from datetime import timedelta
    return timedelta(seconds=seconds)


def get_recent(case_id: str, call_id: str, n: int = 10) -> list[CallTurn]:
    """Return the last `n` transcript turns for `call_id`."""
    log = get_logger(case_id)
    turns = _full_turns()[-n:]
    log.info("transcript_recent", call_id=call_id, n=len(turns))
    return turns


async def subscribe(
    case_id: str,
    call_id: str,
    *,
    interval_s: float = 0.05,
) -> AsyncIterator[CallTurn]:
    """Yield turns one-at-a-time as if live. POC simulates with a small sleep."""
    log = get_logger(case_id)
    log.info("transcript_subscribe_start", call_id=call_id)
    for turn in _full_turns():
        await asyncio.sleep(interval_s)
        yield turn
    log.info("transcript_subscribe_end", call_id=call_id)
