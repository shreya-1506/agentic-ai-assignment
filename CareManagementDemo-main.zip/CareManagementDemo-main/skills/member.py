"""Member-database skill.

# MOCK: plan eligibility API
TODO: replace with real plan eligibility / member-profile API call.
"""

from __future__ import annotations

from datetime import date

from models.exceptions import SkillError
from models.schemas import Address, Member
from skills._common import get_logger
from skills._fixtures import JOHN_MARTINEZ_MEMBER_ID, JOHN_MARTINEZ_PROFILE


class MemberNotFound(SkillError):
    """The member_id is not present in the mock member database."""


def _materialize(profile: dict) -> Member:
    addr = profile.get("address")
    return Member(
        member_id=profile["member_id"],
        first_name=profile["first_name"],
        last_name=profile["last_name"],
        dob=profile["dob"],
        phone=profile["phone"],
        email=profile.get("email"),
        preferred_language=profile.get("preferred_language", "English"),
        plan_name=profile["plan_name"],
        pcp_name=profile.get("pcp_name"),
        pcp_id=profile.get("pcp_id"),
        address=Address(**addr) if addr else None,
    )


def get_profile(case_id: str, member_id: str) -> Member:
    """Return the member profile for `member_id`.

    Raises `MemberNotFound` if the id is unknown.
    """
    log = get_logger(case_id)
    log.info("member_lookup", member_id=member_id)

    if member_id == JOHN_MARTINEZ_MEMBER_ID:
        return _materialize(JOHN_MARTINEZ_PROFILE)

    log.warning("member_unknown", member_id=member_id)
    raise MemberNotFound(f"unknown member_id={member_id}", case_id=case_id)


def verify_identity(
    case_id: str,
    member_id: str,
    *,
    dob_provided: date,
    name_provided: str,
) -> bool:
    """Validate name + DOB against the member record. PII-safe logging."""
    log = get_logger(case_id)
    try:
        m = get_profile(case_id, member_id)
    except MemberNotFound:
        log.info("identity_verification_failed", reason="member_not_found")
        return False

    name_match = name_provided.strip().lower() in (
        f"{m.first_name} {m.last_name}".lower(),
        m.first_name.lower(),
        f"{m.last_name}, {m.first_name}".lower(),
    )
    dob_match = m.dob == dob_provided

    ok = bool(name_match and dob_match)
    log.info(
        "identity_verification",
        result=ok,
        name_match=name_match,
        dob_match=dob_match,
    )
    return ok
