"""RAG retrieval over `knowledge_chunks`.

Embeds the query via Titan v2 (`skills.bedrock.embed_text`) and runs an
HNSW cosine-similarity search against the table populated by
`scripts/ingest_knowledge.py`.
"""

from __future__ import annotations

from dataclasses import dataclass

from pgvector.psycopg import register_vector_async
from psycopg.rows import dict_row

from db.pool import connection
from skills._common import get_logger
from skills.bedrock import embed_text


@dataclass(frozen=True)
class GuidelineHit:
    chunk_id: int
    source_doc: str
    section_title: str
    chunk_text: str
    similarity: float


async def search_guidelines(
    case_id: str,
    query: str,
    k: int = 5,
) -> list[GuidelineHit]:
    """Return the top-k clinical-guideline chunks for `query`.

    `similarity` is cosine similarity in [0, 1]; higher is more relevant.
    """
    log = get_logger(case_id, k=k)
    log.info("rag_search_start", query_chars=len(query))

    qvec = embed_text(case_id=case_id, text=query)

    async with connection() as conn:
        await register_vector_async(conn)
        async with conn.cursor(row_factory=dict_row) as cur:
            await cur.execute(
                """
                SELECT chunk_id,
                       source_doc,
                       chunk_metadata->>'section_title' AS section_title,
                       chunk_text,
                       1 - (embedding <=> %s::vector) AS similarity
                  FROM knowledge_chunks
                 ORDER BY embedding <=> %s::vector
                 LIMIT %s
                """,
                (qvec, qvec, k),
            )
            rows = await cur.fetchall()

    hits = [
        GuidelineHit(
            chunk_id=r["chunk_id"],
            source_doc=r["source_doc"],
            section_title=r["section_title"] or r["source_doc"],
            chunk_text=r["chunk_text"],
            similarity=float(r["similarity"]),
        )
        for r in rows
    ]
    log.info("rag_search_done", hits=len(hits), top_sim=hits[0].similarity if hits else None)
    return hits
