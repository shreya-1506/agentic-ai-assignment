"""Community resource directory.

# MOCK: Findhelp / Aunt Bertha / plan-internal directory
TODO: replace with real community-resources lookup.
"""

from __future__ import annotations

from typing import Any

from skills._common import get_logger
from skills._fixtures import COMMUNITY_RESOURCES


def search_resources(
    case_id: str,
    *,
    need_type: str,
    member_zip: str | None = None,
    subtype: str | None = None,
) -> list[dict[str, Any]]:
    """Return resources matching `need_type` (and optional `subtype`) for the member's zip."""
    log = get_logger(case_id)
    out = []
    for r in COMMUNITY_RESOURCES:
        if r["resource_type"] != need_type:
            continue
        if subtype is not None and r.get("subtype") != subtype:
            continue
        if member_zip is not None and r.get("zip_coverage") and member_zip not in r["zip_coverage"]:
            continue
        out.append(r)
    log.info(
        "community_search",
        need_type=need_type,
        subtype=subtype,
        zip=member_zip,
        hits=len(out),
    )
    return out
