"""Outbound SMS.

# MOCK: Twilio Messaging API
TODO: replace with real Twilio client when TWILIO_STUB=false.

In stub mode (default) we append the would-be message to `data/outbox/sms.log`
and return a fake message SID. No outbound network traffic.
"""

from __future__ import annotations

import os
import secrets
from datetime import datetime, timezone
from pathlib import Path

from skills._common import get_logger, redact_phone

PROJECT_ROOT = Path(__file__).resolve().parent.parent
OUTBOX = PROJECT_ROOT / "data" / "outbox"
SMS_LOG = OUTBOX / "sms.log"


def _stub_enabled() -> bool:
    return os.environ.get("TWILIO_STUB", "true").lower() == "true"


def send(case_id: str, phone: str, body: str) -> str:
    """Send an SMS. Returns the message SID (fake in stub mode)."""
    log = get_logger(case_id)
    sid = "SM" + secrets.token_hex(16)

    if _stub_enabled():
        OUTBOX.mkdir(parents=True, exist_ok=True)
        line = (
            f"{datetime.now(timezone.utc).isoformat()}\t{case_id}\t{redact_phone(phone)}"
            f"\t{sid}\t{body.replace(chr(10), ' / ')}\n"
        )
        with SMS_LOG.open("a", encoding="utf-8") as fh:
            fh.write(line)
        log.info("sms_stubbed", to=redact_phone(phone), sid=sid, body_len=len(body))
        return sid

    # MOCK: real Twilio call would go here.
    log.warning("sms_real_send_not_implemented", to=redact_phone(phone))
    raise NotImplementedError("real Twilio send not yet wired")
