"""Outbound webhook poster.

Real httpx POST. Not a mock. Used by `communication_agent` to deliver
event-driven notifications to downstream consumers.

Default target when no URL is provided: `http://localhost:9999/sink`
(matches the agent_prompts' suggested local sink for testing).
"""

from __future__ import annotations

import os
from typing import Any

import httpx
from tenacity import retry, stop_after_attempt, wait_exponential

from skills._common import get_logger

DEFAULT_SINK = os.environ.get("WEBHOOK_SINK_URL", "http://localhost:9999/sink")


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=0.5, min=0.5, max=4),
    reraise=True,
)
def _send_with_retry(url: str, payload: dict[str, Any]) -> dict[str, Any]:
    with httpx.Client(timeout=httpx.Timeout(5.0)) as client:
        resp = client.post(url, json=payload)
        resp.raise_for_status()
        try:
            return resp.json()
        except Exception:
            return {"status_code": resp.status_code, "text": resp.text[:512]}


def post(
    case_id: str,
    payload: dict[str, Any],
    *,
    url: str | None = None,
) -> dict[str, Any]:
    """POST `payload` as JSON to `url` (defaults to DEFAULT_SINK). Returns response."""
    log = get_logger(case_id)
    target = url or DEFAULT_SINK
    try:
        result = _send_with_retry(target, payload)
        log.info("webhook_ok", url=target, payload_keys=list(payload.keys()))
        return result
    except Exception as exc:
        log.warning(
            "webhook_failed",
            url=target,
            error_type=type(exc).__name__,
            error=str(exc),
        )
        return {"ok": False, "error": str(exc), "error_type": type(exc).__name__}
