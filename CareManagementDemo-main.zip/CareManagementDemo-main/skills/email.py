"""Outbound email.

# MOCK: aiosmtplib
TODO: replace with real aiosmtplib send when SMTP_OFF=false.

In stub mode (default) we append a record to `data/outbox/email.log`.
"""

from __future__ import annotations

import os
import secrets
from datetime import datetime, timezone
from pathlib import Path

from skills._common import get_logger, redact_email

PROJECT_ROOT = Path(__file__).resolve().parent.parent
OUTBOX = PROJECT_ROOT / "data" / "outbox"
EMAIL_LOG = OUTBOX / "email.log"


def _smtp_off() -> bool:
    return os.environ.get("SMTP_OFF", "true").lower() == "true"


def send(
    case_id: str,
    to: str,
    subject: str,
    body: str,
    body_html: str | None = None,
) -> str:
    """Send an email. Returns the message ID (fake in stub mode)."""
    log = get_logger(case_id)
    msg_id = "MSG-" + secrets.token_hex(12)

    if _smtp_off():
        OUTBOX.mkdir(parents=True, exist_ok=True)
        line = (
            f"{datetime.now(timezone.utc).isoformat()}\t{case_id}\t{redact_email(to)}"
            f"\t{msg_id}\t{subject}\t{len(body)}c\n"
        )
        with EMAIL_LOG.open("a", encoding="utf-8") as fh:
            fh.write(line)
        log.info(
            "email_stubbed",
            to=redact_email(to),
            subject=subject,
            msg_id=msg_id,
            has_html=bool(body_html),
        )
        return msg_id

    # MOCK: real SMTP send would go here.
    log.warning("email_real_send_not_implemented", to=redact_email(to))
    raise NotImplementedError("real SMTP send not yet wired")
