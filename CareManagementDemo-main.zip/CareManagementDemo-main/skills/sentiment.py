"""Turn-level sentiment scoring.

# MOCK: vendor TBD
TODO: replace with real sentiment service (or fine-tuned classifier).

The mock uses a simple keyword heuristic so the John Martinez arc trends
from neutral (~50) at call start to very positive (~90) by close.
"""

from __future__ import annotations

from typing import Any

from skills._common import get_logger

_POSITIVE = {
    "yes", "please", "good", "great", "better", "okay", "ok", "thanks", "thank you",
    "helpful", "wonderful", "perfect", "improving",
}
_NEGATIVE = {
    "no", "not", "can't", "cannot", "won't", "tight", "worse", "worsening",
    "short of breath", "trouble", "difficult", "pain", "scared",
}


def _bucket(score_0_100: int) -> str:
    if score_0_100 >= 80: return "very_positive"
    if score_0_100 >= 60: return "positive"
    if score_0_100 >= 40: return "neutral"
    if score_0_100 >= 20: return "negative"
    return "very_negative"


def score_turn(case_id: str, text: str) -> dict[str, Any]:
    """Return `{score_0_100, label}` for a single transcript turn."""
    log = get_logger(case_id)
    lower = text.lower()

    score = 50
    for tok in _POSITIVE:
        if tok in lower:
            score += 10
    for tok in _NEGATIVE:
        if tok in lower:
            score -= 8

    # short affirmations bias positive; short denials bias negative
    if lower.strip() in {"yes.", "yes, please.", "please.", "okay."}:
        score = max(score, 85)
    if lower.strip() in {"no.", "i don't have one.", "not really."}:
        score = min(score, 40)

    score = max(0, min(100, score))
    label = _bucket(score)
    log.info("sentiment_scored", chars=len(text), score=score, label=label)
    return {"score_0_100": score, "label": label}
