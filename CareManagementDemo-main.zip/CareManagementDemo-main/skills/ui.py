"""UI push channel for the CM panel (Agent Assist).

# MOCK: WebSocket push to CM panel
TODO: replace with real WebSocket fan-out (FastAPI websockets in Step 7+).

For the POC we keep an in-memory ring buffer per case and append a line to
`data/outbox/ui_pushes.log`. The reviewer UI will subscribe to this in a
later step.
"""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from skills._common import get_logger

PROJECT_ROOT = Path(__file__).resolve().parent.parent
OUTBOX = PROJECT_ROOT / "data" / "outbox"
UI_LOG = OUTBOX / "ui_pushes.log"

_BUFFERS: dict[str, list[dict[str, Any]]] = defaultdict(list)


def _push(case_id: str, kind: str, payload: dict[str, Any]) -> None:
    entry = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "case_id": case_id,
        "kind": kind,
        "payload": payload,
    }
    _BUFFERS[case_id].append(entry)
    OUTBOX.mkdir(parents=True, exist_ok=True)
    with UI_LOG.open("a", encoding="utf-8") as fh:
        fh.write(f"{entry['ts']}\t{case_id}\t{kind}\t{payload}\n")


def push_prompt(case_id: str, prompt_id: str, payload: dict[str, Any]) -> None:
    log = get_logger(case_id)
    _push(case_id, "prompt", {"prompt_id": prompt_id, **payload})
    log.info("ui_push_prompt", prompt_id=prompt_id)


def push_sentiment(case_id: str, sentiment_event: dict[str, Any]) -> None:
    log = get_logger(case_id)
    _push(case_id, "sentiment", sentiment_event)
    log.info("ui_push_sentiment", **{k: v for k, v in sentiment_event.items() if k in {"label", "score_0_100"}})


def push_slot_options(case_id: str, call_id: str, slots: list[Any]) -> None:
    log = get_logger(case_id)
    _push(case_id, "slot_options", {"call_id": call_id, "slots": [str(s) for s in slots]})
    log.info("ui_push_slot_options", call_id=call_id, slot_count=len(slots))


def _drain(case_id: str) -> list[dict[str, Any]]:
    """Test helper: return and clear the in-memory buffer for a case."""
    out = _BUFFERS.pop(case_id, [])
    return out
