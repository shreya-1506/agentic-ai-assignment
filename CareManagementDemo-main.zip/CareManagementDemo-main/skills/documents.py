"""Document parsing + per-field extraction.

# MOCK: Unstructured + Tesseract OCR
TODO: replace with real `unstructured` partitioning + Tesseract fallback.

For the POC the discharge summary is a markdown stand-in (see `skills.ehr`).
`parse_pdf` returns its text directly.

Two extraction entry points:
  - `extract_fields`            -- deterministic mock that returns the canned
                                    John Martinez fixture (13 fields with one
                                    flagged-low-confidence row). Used by unit
                                    tests and offline smoke scripts that need
                                    a stable extraction without hitting the
                                    network. NOT invoked by the agent at
                                    runtime: production wiring lets Bedrock
                                    failures propagate to the orchestrator's
                                    retry-then-escalate policy rather than
                                    masking them with mock data.
  - `extract_fields_llm`        -- real Bedrock-backed per-field extractor.
                                    Calls `skills.bedrock.invoke_chat` with
                                    the prompt from `config.extraction`, parses
                                    the model's JSON response, normalizes
                                    each field into an `ExtractedField` row,
                                    and applies the 0.80 flag threshold.

Both entry points return `list[ExtractedField]` in the same shape.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from config.extraction import (
    EXPECTED_FIELD_NAMES,
    EXTRACTION_SYSTEM_PROMPT,
    LOW_CONFIDENCE_THRESHOLD,
    MAX_DOC_CHARS_FOR_LLM,
)
from models.exceptions import BedrockError, DocumentNotFound, SkillError
from models.schemas import ExtractedField
from skills import bedrock as bedrock_skill
from skills._common import get_logger
from skills._fixtures import JOHN_MARTINEZ_EXTRACTED_FIELDS


# =============================================================================
# Parsing
# =============================================================================


def parse_pdf(case_id: str, path: Path | str) -> str:
    """Return the full text of the document. Works on `.md` stand-ins too."""
    log = get_logger(case_id)
    p = Path(path)
    if not p.exists():
        log.warning("document_not_found", path=str(p))
        raise DocumentNotFound(f"file not found: {p}", case_id=case_id)
    text = p.read_text(encoding="utf-8")
    log.info("document_parsed", path=str(p), chars=len(text))
    return text


# =============================================================================
# Deterministic fallback (canned John Martinez fixture)
# =============================================================================


def extract_fields(case_id: str, document_text: str) -> list[ExtractedField]:
    """Return the canned per-field extraction.

    Deterministic mock used by unit tests and offline smoke scripts. NOT
    used by the production agent at runtime -- Bedrock failures there
    propagate to the orchestrator's retry/escalate policy instead.
    The fixture contains exactly one flagged-low-confidence row
    (`medication_changes` @ 0.72) so any UI surface rendering it gets a
    realistic mix of high- and low-confidence rows.
    """
    log = get_logger(case_id)
    fields = [
        ExtractedField(
            case_id=case_id,
            field_name=f["field_name"],
            value=f["value"],
            confidence=f["confidence"],
            flagged=f["flagged"],
            source_page=f.get("source_page"),
            source_bbox=f.get("source_bbox"),
        )
        for f in JOHN_MARTINEZ_EXTRACTED_FIELDS
    ]
    flagged = sum(1 for f in fields if f.flagged)
    log.info(
        "fields_extracted_mock",
        total=len(fields),
        flagged=flagged,
        source="fixture",
    )
    return fields


# =============================================================================
# Real LLM extractor
# =============================================================================


class ExtractionParseError(SkillError):
    """The model returned text we couldn't parse into the expected schema."""


def extract_fields_llm(
    case_id: str,
    document_text: str,
    *,
    model_id: str | None = None,
    max_tokens: int = 2048,
    temperature: float = 0.0,
) -> list[ExtractedField]:
    """Run the Bedrock-backed per-field extractor.

    Returns `list[ExtractedField]`, one entry per name in `EXPECTED_FIELD_NAMES`,
    in the same order. Missing fields in the model output become rows with
    `value=None`, `confidence=0.0`, `flagged=True`, and a `source_bbox` carrying
    `{"reason": "missing from LLM response"}` so downstream UI surfaces the gap.

    Raises:
      BedrockError: the underlying Bedrock Converse call failed.
      ExtractionParseError: the model responded but we couldn't parse JSON.
    """
    log = get_logger(case_id)

    if not document_text or not document_text.strip():
        raise ExtractionParseError(
            "cannot extract fields from empty document_text", case_id=case_id
        )

    truncated = document_text[:MAX_DOC_CHARS_FOR_LLM]
    if len(document_text) > MAX_DOC_CHARS_FOR_LLM:
        log.info(
            "document_truncated_for_llm",
            original_chars=len(document_text),
            kept_chars=MAX_DOC_CHARS_FOR_LLM,
        )

    user_msg = (
        "Discharge summary text follows between the markers. Extract the 13 "
        "fields per the system instructions and return ONLY the JSON object.\n\n"
        "----- BEGIN DISCHARGE SUMMARY -----\n"
        f"{truncated}\n"
        "----- END DISCHARGE SUMMARY -----\n"
    )

    try:
        raw = bedrock_skill.invoke_chat(
            case_id=case_id,
            system=EXTRACTION_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_msg}],
            max_tokens=max_tokens,
            temperature=temperature,
            model_id=model_id,
        )
    except BedrockError:
        raise  # let the caller decide whether to fall back

    payload = _parse_extractor_json(case_id, raw)
    fields = _payload_to_fields(case_id, payload)
    flagged = sum(1 for f in fields if f.flagged)
    log.info(
        "fields_extracted_llm",
        total=len(fields),
        flagged=flagged,
        source="bedrock",
    )
    return fields


# -----------------------------------------------------------------------------
# JSON parsing helpers
# -----------------------------------------------------------------------------


_JSON_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL)


def _parse_extractor_json(case_id: str, raw: str) -> dict[str, Any]:
    """Coerce the model's response into a dict.

    Models sometimes wrap JSON in ```json ... ``` fences or add a leading line
    like "Here is the JSON:". We strip those defensively before parsing.
    """
    if not raw or not raw.strip():
        raise ExtractionParseError("empty response from LLM", case_id=case_id)

    candidate = raw.strip()

    fence_match = _JSON_FENCE_RE.search(candidate)
    if fence_match:
        candidate = fence_match.group(1).strip()

    # If there's still leading prose, grab from the first `{` to the last `}`.
    if not candidate.startswith("{"):
        start = candidate.find("{")
        end = candidate.rfind("}")
        if start != -1 and end != -1 and end > start:
            candidate = candidate[start : end + 1]

    try:
        parsed = json.loads(candidate)
    except json.JSONDecodeError as exc:
        raise ExtractionParseError(
            f"could not decode LLM JSON: {exc}", case_id=case_id
        ) from exc

    if not isinstance(parsed, dict):
        raise ExtractionParseError(
            f"LLM JSON root is not an object (got {type(parsed).__name__})",
            case_id=case_id,
        )
    return parsed


def _payload_to_fields(
    case_id: str, payload: dict[str, Any]
) -> list[ExtractedField]:
    """Translate the parsed JSON object into ordered `ExtractedField` rows."""
    fields: list[ExtractedField] = []
    for name in EXPECTED_FIELD_NAMES:
        entry = payload.get(name)
        if not isinstance(entry, dict):
            fields.append(
                ExtractedField(
                    case_id=case_id,
                    field_name=name,
                    value=None,
                    confidence=0.0,
                    flagged=True,
                    source_bbox={"reason": "missing from LLM response"},
                )
            )
            continue

        raw_value = entry.get("value")
        value_str = _stringify_value(raw_value)

        confidence = _clamp_confidence(entry.get("confidence"))
        reason = entry.get("reason")
        flagged = confidence < LOW_CONFIDENCE_THRESHOLD

        # We don't have real PDF bbox info in the POC, so use source_bbox to
        # carry the model's per-field rationale through to the reviewer UI.
        source_bbox = {"reason": reason} if isinstance(reason, str) and reason else None

        fields.append(
            ExtractedField(
                case_id=case_id,
                field_name=name,
                value=value_str,
                confidence=confidence,
                flagged=flagged,
                source_bbox=source_bbox,
            )
        )
    return fields


def _stringify_value(raw: Any) -> str | None:
    """Persist non-string values (lists, ints) as JSON-encoded strings.

    The `extracted_fields.value` column is TEXT. For structured values
    (e.g., `medication_changes` is a list of dicts) we JSON-encode so the
    reviewer UI can re-parse on read. None stays None.
    """
    if raw is None:
        return None
    if isinstance(raw, str):
        return raw
    try:
        return json.dumps(raw, ensure_ascii=False, sort_keys=False)
    except (TypeError, ValueError):
        return str(raw)


def _clamp_confidence(raw: Any) -> float:
    """Coerce the model's confidence into the [0.0, 1.0] range."""
    try:
        v = float(raw)
    except (TypeError, ValueError):
        return 0.0
    if v < 0.0:
        return 0.0
    if v > 1.0:
        return 1.0
    return v
