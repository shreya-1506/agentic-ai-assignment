"""Shared infrastructure for all skills: logging, PII redaction, ID minting.

Importable from any skill module. Not a tool itself — these are helpers.
"""

from __future__ import annotations

import logging
import os
import re
import secrets
from datetime import date
from typing import Any

import structlog

# -----------------------------------------------------------------------------
# PII redaction
# -----------------------------------------------------------------------------

# Keys whose values are always considered PII when they appear in structlog events.
_PII_KEYS: set[str] = {
    "phone",
    "phone_number",
    "member_phone",
    "contact_phone",
    "first_name",
    "last_name",
    "full_name",
    "name",
    "patient_name",
    "dob",
    "date_of_birth",
    "mrn",
    "medical_record_number",
    "ssn",
    "email",
    "address",
    "home_address",
}

_PHONE_RE = re.compile(r"\b(\+?1?[\s\-.]?\(?\d{3}\)?[\s\-.]?\d{3}[\s\-.]?\d{4})\b")
_EMAIL_RE = re.compile(r"\b[\w._%+-]+@[\w.-]+\.[A-Za-z]{2,}\b")


def redact_phone(phone: str | None) -> str:
    if not phone:
        return ""
    digits = re.sub(r"\D", "", phone)
    if len(digits) < 4:
        return "***"
    return f"(***) ***-{digits[-4:]}"


def redact_name(name: str | None) -> str:
    if not name:
        return ""
    parts = [p for p in name.split() if p]
    return " ".join(f"{p[0]}." for p in parts) if parts else "***"


def redact_dob(dob: date | str | None) -> str:
    if dob is None:
        return ""
    if isinstance(dob, date):
        return f"****-{dob.month:02d}-{dob.day:02d}"
    s = str(dob)
    return re.sub(r"^\d{4}", "****", s)


def redact_mrn(mrn: str | None) -> str:
    if not mrn:
        return ""
    return f"***{mrn[-4:]}" if len(mrn) >= 4 else "***"


def redact_email(email: str | None) -> str:
    if not email or "@" not in email:
        return "***"
    local, _, domain = email.partition("@")
    return f"{local[:1]}***@{domain}"


def redact_pii(value: Any, key: str | None = None) -> Any:
    """Best-effort redaction. Tag-driven (by key) when known, fallback to regex."""
    if value is None:
        return None
    if key is not None:
        k = key.lower()
        if k in {"phone", "phone_number", "member_phone", "contact_phone"}:
            return redact_phone(str(value))
        if k in {"first_name", "last_name", "full_name", "name", "patient_name"}:
            return redact_name(str(value))
        if k in {"dob", "date_of_birth"}:
            return redact_dob(value)
        if k in {"mrn", "medical_record_number"}:
            return redact_mrn(str(value))
        if k in {"email"}:
            return redact_email(str(value))
        if k in {"ssn"}:
            return "***-**-****"
    if isinstance(value, str):
        out = _PHONE_RE.sub(lambda m: redact_phone(m.group(1)), value)
        out = _EMAIL_RE.sub(lambda m: redact_email(m.group(0)), out)
        return out
    return value


def _redact_processor(_logger: Any, _method: str, event_dict: dict[str, Any]) -> dict[str, Any]:
    """structlog processor that auto-redacts known PII keys in the event dict."""
    for k in list(event_dict.keys()):
        if k.lower() in _PII_KEYS:
            event_dict[k] = redact_pii(event_dict[k], key=k)
    return event_dict


# -----------------------------------------------------------------------------
# structlog configuration
# -----------------------------------------------------------------------------

_configured = False


def configure_logging() -> None:
    """One-time structlog setup. Idempotent."""
    global _configured
    if _configured:
        return

    level = os.environ.get("LOG_LEVEL", "INFO").upper()
    logging.basicConfig(format="%(message)s", level=level)

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.stdlib.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            _redact_processor,
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(getattr(logging, level, logging.INFO)),
        cache_logger_on_first_use=True,
    )
    _configured = True


def get_logger(case_id: str | None = None, **bind: Any) -> structlog.stdlib.BoundLogger:
    """Return a logger bound to `case_id` and any extra context."""
    configure_logging()
    log = structlog.get_logger()
    bindings: dict[str, Any] = {}
    if case_id:
        bindings["case_id"] = case_id
    bindings.update(bind)
    return log.bind(**bindings) if bindings else log


# -----------------------------------------------------------------------------
# ID minting
# -----------------------------------------------------------------------------

_ID_PREFIXES = {
    "case": "CASE",
    "member": "MBR",
    "session": "MS",
    "call": "CL",
    "task": "TASK",
    "crm": "CRM",
    "appt": "APPT",
}


def mint_id(kind: str, *, width: int = 8) -> str:
    """Mint a `<PREFIX>-NNNNNNNN` ID. `kind` ∈ _ID_PREFIXES keys."""
    prefix = _ID_PREFIXES[kind]
    n = secrets.randbelow(10**width)
    return f"{prefix}-{n:0{width}d}"


def mint_case_id() -> str:
    return mint_id("case")


def mint_session_id() -> str:
    return mint_id("session")


def mint_call_id() -> str:
    return mint_id("call")


def mint_member_id() -> str:
    return mint_id("member")


def mint_crm_id() -> str:
    return mint_id("crm")


def mint_task_id() -> str:
    return mint_id("task")
