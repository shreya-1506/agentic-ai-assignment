"""EHR document store.

# MOCK: FHIR R4 /DocumentReference
TODO: replace with real FHIR document-reference + binary fetch.

`fetch_discharge_summary` returns a path to a stand-in PDF/markdown file
under `data/documents/`. The mock generates the file on first call so the
downstream OCR/extraction step has something to read.
"""

from __future__ import annotations

from datetime import date
from pathlib import Path

from models.exceptions import DocumentNotFound
from skills._common import get_logger
from skills._fixtures import JOHN_MARTINEZ_MEMBER_ID

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DOCS_DIR = PROJECT_ROOT / "data" / "documents"


def fetch_discharge_summary(
    case_id: str,
    member_id: str,
    discharge_date: date,
) -> Path:
    """Return a local path to the discharge summary for `member_id`.

    For John Martinez we synthesize a markdown stand-in on first call (no
    real PDF). For any other member we raise `DocumentNotFound`.
    """
    log = get_logger(case_id)
    DOCS_DIR.mkdir(parents=True, exist_ok=True)

    if member_id != JOHN_MARTINEZ_MEMBER_ID:
        log.warning("ehr_document_not_found", member_id=member_id)
        raise DocumentNotFound(
            f"no discharge summary for member_id={member_id}", case_id=case_id
        )

    path = DOCS_DIR / f"{member_id}_{discharge_date.isoformat()}_discharge.md"
    if not path.exists():
        path.write_text(_synth_discharge_summary(member_id, discharge_date), encoding="utf-8")
        log.info("ehr_document_synthesized", path=str(path))
    else:
        log.info("ehr_document_cached", path=str(path))
    return path


def _synth_discharge_summary(member_id: str, discharge_date: date) -> str:
    return f"""# Hospital Discharge Summary

**Medical Center:** St. Mary's Medical Center
**Patient Name:** John Martinez
**MRN:** MRN-78234916
**Member ID:** {member_id}
**Admit Date:** 2026-10-02
**Discharge Date:** {discharge_date.isoformat()}
**Length of Stay:** 3 days
**Attending Physician:** Dr. Priya Patel
**Primary Diagnosis:** Chronic obstructive pulmonary disease with acute exacerbation (J44.1)

## Reason for Hospitalization
Patient presented to the emergency department with worsening dyspnea, productive cough,
and decreased exercise tolerance over 4 days. Pulse oximetry on admission was 86% on
room air. Treated for acute COPD exacerbation with IV methylprednisolone, nebulized
bronchodilators, and supplemental oxygen.

## Hand-off Summary
Patient stabilized on oral steroids over the course of hospitalization; weaning
supplemental oxygen by day 3. Ambulating with mild dyspnea on exertion. Pulse oximetry
on room air 93% at discharge.

**Last SpO2:** 93% on room air (Day 3)

## Medication Changes (reconciled)
- Prednisone 40 mg PO daily tapering over 14 days
- Albuterol HFA 90 mcg PRN (1–2 puffs every 4 hours as needed)
- Tiotropium 18 mcg inhalation daily (continued from home regimen)
- Azithromycin 500 mg PO ×5 days (new, prescribed for suspected bacterial component)

## Discharge Instructions
Follow up with PCP (Dr. Luis Garcia) within 7–10 days.
Return to ED for worsening dyspnea, fever, or new chest pain.
Continue home oxygen as needed.

**Discharge Disposition:** Home with self-care
"""
