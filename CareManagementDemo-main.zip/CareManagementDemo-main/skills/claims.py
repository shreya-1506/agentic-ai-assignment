"""Claims + care gaps + prior engagement.

# MOCK: plan analytics API
TODO: replace with real claims warehouse query.

Returns a consolidated `member_history` dict consumed by `admission_risk_agent`.
"""

from __future__ import annotations

from typing import Any

from skills._common import get_logger
from skills._fixtures import JOHN_MARTINEZ_CLAIMS_HISTORY, JOHN_MARTINEZ_MEMBER_ID


def get_member_history(
    case_id: str,
    member_id: str,
    lookback_months: int = 24,
) -> dict[str, Any]:
    """Return claims, ED visits, care gaps, and prior engagement summary."""
    log = get_logger(case_id)
    log.info("claims_lookup", member_id=member_id, lookback_months=lookback_months)

    if member_id == JOHN_MARTINEZ_MEMBER_ID:
        return {**JOHN_MARTINEZ_CLAIMS_HISTORY, "member_id": member_id}

    # Generic mock for other members — empty history, no prior engagement.
    return {
        "member_id": member_id,
        "lookback_months": lookback_months,
        "admits": [],
        "ed_visits": [],
        "care_gaps": [],
        "prior_engagement": {
            "prior_tcm_count": 0,
            "prior_cmp_enrollment": False,
            "last_outreach_attempts": 0,
        },
    }
