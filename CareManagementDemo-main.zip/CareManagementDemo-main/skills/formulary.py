"""Plan formulary coverage check.

# MOCK: PBM API
TODO: replace with real PBM/formulary lookup.
"""

from __future__ import annotations

from typing import Any

from skills._common import get_logger
from skills._fixtures import BLUECROSS_PREMIER_FORMULARY


def check_coverage(
    case_id: str,
    drug_name: str,
    member_plan: str,
) -> dict[str, Any]:
    """Return coverage info: covered, tier, prior_auth_required, copay_estimate."""
    log = get_logger(case_id)
    key = drug_name.split()[0].lower()
    table = BLUECROSS_PREMIER_FORMULARY if "BlueCross" in member_plan else {}
    hit = table.get(key)
    if hit:
        log.info("formulary_hit", drug=key, plan=member_plan)
        return {"drug": drug_name, "plan": member_plan, **hit}
    log.info("formulary_miss", drug=key, plan=member_plan)
    return {
        "drug": drug_name,
        "plan": member_plan,
        "covered": False,
        "tier": None,
        "prior_auth_required": True,
        "copay_estimate": None,
    }
