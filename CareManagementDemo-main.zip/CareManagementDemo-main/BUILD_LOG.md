# BUILD_LOG

Per-step running record of the multi-agent TCM POC build.

## At a glance

| # | Step | Status | Notes |
|---|---|---|---|
| 1 | Project scaffold | ✓ done | Dirs, tracking docs, .env.example, .gitignore, requirements.txt |
| 2 | Pydantic models + Postgres schema + pgvector | ✓ done | 12 tables live on Neon; ALLOWED_TRANSITIONS enforced via `db.state.update_case_state` |
| 3 | Knowledge-base ingestion script | ✓ done | 40 chunks × 1024-dim Titan v2 embeddings ingested into Neon; HNSW retrieval verified |
| 4 | Skills layer (`/skills/`) with mocks | ✓ done | 22 skill modules + db/state_io + 2 templates; full end-to-end smoke against Neon + Bedrock passes |
| 5 | `orchestration_agent` | ✓ done | Polling loop + dispatch table + auto-transitions + 3-strike retry/backoff + milestone events; 4-scenario smoke green |
| 6 | `admission_risk_agent` | ✓ done (stub) | Walks DISCHARGE_RECEIVED → RISK_STRATIFIED end-to-end; populates John Martinez POC values; teammate replaces the math with real LLM scoring |
| 7 | FastAPI core + lifespan-hosted orchestrator | ✓ done | uvicorn process hosts API + orchestrator daemon; Swagger at /docs; full case view; intake with dedup; admin tick |
| 8 | `document_extraction_agent` + endpoints | ✓ done | RISK_STRATIFIED → DOCUMENT_PENDING_REVIEW; 13 extracted fields (1 flagged @ 0.72); GET /cases/{id}/extraction; Bedrock-backed extractor (failures propagate to orchestrator retry/escalate); denormalized `cases.extraction_flags` + `cases.is_stp` |
| 9 | `outreach_agent` (RAG over TCM guidelines) | ✓ done (stub) | OUTREACH_SCHEDULED → OUTREACH_COMPLETE; 14-turn canned convo; RAG-exercised; survey + sdoh_flags=['no_pcp_appt'] persisted; GET /cases/{id}/outreach |
| 10 | Human review endpoints | ✓ done | POST /cases/{id}/review + GET /clinician/queue; first true end-to-end (DISCHARGE_RECEIVED → OUTREACH_COMPLETE) via API only |
| 11 | `agent_assist_agent` + endpoints | ✓ done (stub) | Foreground; POST /call/start spawns bg task; GET /call polls; 12-turn replay + 4 prompts in order + consent + sentiment 62→85 |
| 12 | `scheduling_agent` + endpoints + artifact rendering | ✓ done (stub) | CM-triggered POST /schedule; books Oct 10 14:00, SMS + PDF/HTML + calendar + referral + follow-up task all wired |
| 13 | `compliance_agent` + audit endpoint | pending | **Stub** |
| 14 | `communication_agent` (event-driven) | pending | **Stub** |
| 15 | Sample data + E2E smoke test | pending | |

Status legend: pending · in progress · ✓ done · ⚠ deferred (see [DEFERRED.md](DEFERRED.md))

---

## Step 1 — Project scaffold

**Goal:** Lay down the directory tree, empty tracking docs, `.env.example`, `.gitignore`, and `requirements.txt`. No application code.

**What changed:**
- Moved 7 root-level agent specs into [agent_prompts/](agent_prompts/) via `git mv` (history preserved).
- Created directory tree per `BUILD_PROMPT_v2.md §"Project layout"`: `agents/`, `skills/`, `models/`, `api/routes/`, `config/`, `db/migrations/`, `knowledge/tcm_guidelines/`, `data/documents/`, `data/samples/`, `templates/`, `scripts/`. Each empty dir holds a `.gitkeep` so it survives `git add`.
- Created empty tracking docs: [agents.md](agents.md), [skills.md](skills.md), [HANDOFF.md](HANDOFF.md), [DEFERRED.md](DEFERRED.md), [workflow.md](workflow.md), [USAGE.md](USAGE.md). This file ([BUILD_LOG.md](BUILD_LOG.md)) holds the at-a-glance table.
- Overwrote [README.md](README.md) with the project README (architecture overview, prerequisites, quick-start, layout). The previous meta-doc ("Prompt Bundle") is preserved in git history.
- Wrote [.env.example](.env.example) with Postgres + Bedrock placeholders and feature flags (`BEDROCK_MODEL_ID`, `BEDROCK_EMBEDDING_MODEL_ID`, `SMTP_OFF=true`, `TWILIO_STUB=true`).
- Wrote [.gitignore](.gitignore) (Python caches, `tcm_env/`, `.env`, IDE, logs).
- Wrote [requirements.txt](requirements.txt) — FastAPI, uvicorn, strands-agents, psycopg[binary,pool], pgvector, pydantic v2, structlog, httpx, jinja2, weasyprint, unstructured, pytesseract, aiosmtplib, boto3, etc.

**Decisions captured for later steps:**
- Postgres: **Neon serverless DB** (URL in `.env`, gitignored). Confirmed `?sslmode=require&channel_binding=require` retained in connection string.
- Python venv: **uv-managed** `hh/` at project root (Python 3.11.15). Activation: `.\hh\Scripts\Activate.ps1`. Install: `uv pip install -r requirements.txt`.
- AWS Bedrock credentials available; real boto3 wiring lands when first agent needs it.
- Stub agent TODO markers use generic `# TODO(teammate):` placeholder.
- Next.js UI is **out of scope** for this build (Step 15 ends at smoke test).

**Deferred:**
- Dependency install (`uv pip install -r requirements.txt`) — happens at Step 2 when first import is needed. Note: WeasyPrint may need GTK3 runtime on Windows; defer that resolution until first PDF render attempt.
- `db/migrations/` is empty; no Alembic yet. Initial DDL lives in `db/schema.sql` (idempotent), added at Step 2.

**Driveable demo:** none yet (no runtime code).

---

## Step 2 — Pydantic models + Postgres schema + pgvector

**Goal:** Stand up the data plane that every later step builds on. Tables live on Neon. Pydantic models are the single source of truth for shapes & enums. `update_case_state` is the only sanctioned way to mutate `cases.current_state`.

**What changed:**
- [models/schemas.py](models/schemas.py) — Pydantic v2 models (`Case`, `Member`, `RiskScores` w/ `Impactability` + `Intervenability` subscores, `ExtractedField`, `ReviewerDecision`, `OutreachSession` + turns + survey, `CallSession` + turns + prompts fired, `Appointment`, `Referral`, `ComplianceFinding`, `AuditLogEntry`, `KnowledgeChunk`). String-valued enums (`CaseState`, `PriorityTier`, `ReviewerOutcome`, `ComplianceSeverity`, `OutreachChannel`, `OutreachStatus`, `CallStatus`, `AppointmentStatus`, `ResourceType`, `ResourceSource`, `ReferralStatus`). `ALLOWED_TRANSITIONS` dict + `TERMINAL_STATES` frozenset + `is_terminal()` helper.
- [models/exceptions.py](models/exceptions.py) — `SkillError` base + typed subclasses: `CaseNotFound`, `InvalidStateTransition`, `DuplicateCase`, `DocumentNotFound`, `LowConfidenceField`, `HumanGateNotPassed`, `ReviewerDecisionExpired`, `ConsentNotCaptured`, `MockUnavailable`, `BedrockError`, `ExternalServiceError`.
- [db/schema.sql](db/schema.sql) — idempotent DDL: pgvector extension, 11 Postgres enum types (DO-block wrapped), 12 tables, `cases_dedup_key` UNIQUE constraint (`member_id` + `discharge_date` + `discharge_facility`), HNSW index on `knowledge_chunks.embedding (vector_cosine_ops)`, `updated_at` trigger on `cases`.
- [db/pool.py](db/pool.py) — async psycopg `AsyncConnectionPool` (singleton, lazy open, lifespan-friendly).
- [db/state.py](db/state.py) — `update_case_state` (async). Validates `ALLOWED_TRANSITIONS`, idempotent on no-op, writes `audit_log` in same transaction, returns refreshed `Case`. Raises `CaseNotFound` / `InvalidStateTransition`.
- [scripts/bootstrap_db.py](scripts/bootstrap_db.py) — one-shot schema applier. Hand-rolled `.env` loader (no python-dotenv dependency). Password-redacted log line. Distinct exit codes for pgvector-missing, connection failure, unknown.

**Live verification:**
- `uv pip install` of slim Step 2 deps into `hh/`: psycopg[binary,pool]==3.3.4, pgvector==0.4.2, pydantic==2.13.4, structlog==24.4.0.
- `python -m scripts.bootstrap_db` against Neon → schema applied; all 12 tables present in `public`.
- Python-side smoke test: every `CaseState` has an `ALLOWED_TRANSITIONS` entry; all `TERMINAL_STATES` are dead-ends; exception hierarchy intact.

**Decisions made (locked in for later steps):**
- Schema shape: **separate relational tables** (not JSONB blobs on `cases`). One table per concept, FK to `cases`. Frees up reviewer/audit UI later.
- Audit log: **state transitions only**. Tool-level traces stay in structlog (queryable via log shipper if/when needed).
- Transition enforcement: **Python helper** (`db.state.update_case_state`). One source of truth (`models/schemas.py::ALLOWED_TRANSITIONS`); no DB trigger duplicating the table.

**Deferred:**
- Heavy install (WeasyPrint + GTK3, Unstructured, strands-agents, boto3, FastAPI/uvicorn, etc.) — installed per step as imports are added. Avoids the Windows GTK3 trap until we actually render a PDF.
- pydantic-settings — not used yet; bootstrap reads env directly. Will add when FastAPI lifespan needs typed config (Step 7).

**Driveable demo:** `python -m scripts.bootstrap_db` is the first runnable artifact. Re-runnable any time (idempotent).

---

## Step 3 — Knowledge-base ingestion script

**Goal:** Populate `knowledge_chunks` with the RAG corpus used by `outreach_agent` (and any other agent that wants clinical/regulatory context). Each chunk is embedded via Titan v2 (1024 dims) and indexed under HNSW cosine.

**What changed:**
- [knowledge/tcm_guidelines/](knowledge/tcm_guidelines/) — 6 markdown seed docs (POC-grade content, marked for SME review):
  - `cms_tcm_billing.md` — CPT 99495 / 99496, documentation requirements, eligibility
  - `copd_post_discharge.md` — AECOPD goals, med review, symptom surveillance, PCP follow-up, oxygen/devices
  - `medication_reconciliation.md` — ASHP/ISMP five-step process, high-risk classes, common pitfalls
  - `sdoh_screening.md` — AHC HRSN five domains, three-tier referral pattern, closure
  - `cmp_enrollment.md` — eligibility, care goals, escalation, engagement touchpoints
  - `high_risk_icd10.md` — escalation prefixes by system (J44, I50, E11, I63, N17, etc.)
- [scripts/ingest_knowledge.py](scripts/ingest_knowledge.py) — heading-aware chunker (split on `## `), content-hash dedup (SHA-256 over `source_doc | chunk_text` stored in `chunk_metadata.content_hash`), Titan v2 embedding via `bedrock-runtime`, `--dry-run` flag for plan-only mode. Per-chunk failure rolls back and exits non-zero (one bad chunk doesn't half-load the table).
- [scripts/bootstrap_db.py](scripts/bootstrap_db.py) — `_load_env` hardened to skip empty `.env` placeholders so real OS-level AWS creds aren't clobbered by blank lines.

**Live verification (against real Neon + real Bedrock):**
- `python -m scripts.ingest_knowledge --dry-run` → 40 chunks across 6 docs (cmp_enrollment 6, cms_tcm_billing 6, copd_post_discharge 6, high_risk_icd10 10, medication_reconciliation 6, sdoh_screening 6).
- `python -m scripts.ingest_knowledge` → 40 inserts, ~40 Titan v2 invocations.
- HNSW retrieval test: query "When should the PCP follow-up be scheduled after a COPD discharge?" → top hit `copd_post_discharge.md :: PCP Follow-Up and Pulmonary Rehab` at cosine 0.7523.
- Idempotency: second run reports `insert=0 unchanged=40 delete=0`, zero Bedrock calls.

**Decisions made (locked in):**
- Chunking: **heading-aware**. `## ` boundaries; preamble (above first `##`) becomes one chunk titled after the `#` doc title.
- Idempotency: **content-hash dedup**. Edits propagate (old hash deleted, new hash inserted); orphaned hashes are removed.

**Notes:**
- `BEDROCK_MODEL_ID` overridden in `.env` from default Haiku 4.5 to `us.anthropic.claude-sonnet-4-20250514-v1:0` per user choice. **Does not affect Step 3** (embeddings only use Titan v2), but agents in Steps 5–14 will invoke this model. Logged here so future steps don't silently assume Haiku 4.5.
- AWS creds (long-lived IAM keys for IAM user `Varun_proxzar`, account `008971635132`) live in `.env` only. Per security best practice, rotate after the POC; the IAM user should be Bedrock-scoped.

**Driveable demo:** `python -m scripts.ingest_knowledge [--dry-run]` — see [workflow.md](workflow.md) Step 3.

---

## Step 4 — Skills layer (build fully)

**Goal:** Stand up every tool the 7 agent stubs (and their real-implementation successors) will need to walk a case end-to-end. Mocks are honest — every stubbed external integration carries a `# MOCK:` comment naming the real target.

**What changed (counts: 22 skill modules, 1 db helper module, 1 fixtures file, 2 templates, 2 smoke scripts):**

**Foundations** (shared infrastructure):
- [skills/_common.py](skills/_common.py) — structlog config with auto-PII-redactor processor, explicit redactors (`redact_phone/name/dob/mrn/email`), ID minting (`mint_case_id`, `mint_session_id`, `mint_call_id`, `mint_member_id`, `mint_crm_id`, `mint_task_id`).
- [skills/bedrock.py](skills/bedrock.py) — Converse-API chat wrapper + Titan v2 embed wrapper. Thread-safe lazy client singleton. Logs token counts + stop reason on success.
- [skills/_fixtures.py](skills/_fixtures.py) — canonical John Martinez seed data: member, claims, discharge event, 11 extracted fields (1 flagged), 7 canned messaging replies, 12-turn call transcript, PCP availability slots, community resources, formulary.

**External-system mock skills** (12 modules):
- [skills/crm.py](skills/crm.py) (Salesforce Health Cloud) · [skills/member.py](skills/member.py) (plan eligibility) · [skills/claims.py](skills/claims.py) (plan analytics) · [skills/ehr.py](skills/ehr.py) (FHIR DocumentReference; synthesizes markdown stand-in) · [skills/documents.py](skills/documents.py) (Unstructured+Tesseract — returns canned per-field confidence map) · [skills/formulary.py](skills/formulary.py) (PBM) · [skills/scheduling.py](skills/scheduling.py) (Epic MyChart) · [skills/sms.py](skills/sms.py) (Twilio; stub appends to `data/outbox/sms.log`) · [skills/email.py](skills/email.py) (aiosmtplib; stub appends to `data/outbox/email.log`) · [skills/calendar.py](skills/calendar.py) (member portal) · [skills/messaging.py](skills/messaging.py) (Twilio Conversations; canned-reply mock) · [skills/transcript.py](skills/transcript.py) (AWS Transcribe Medical) · [skills/sentiment.py](skills/sentiment.py) (vendor TBD; keyword heuristic) · [skills/community.py](skills/community.py) (Findhelp).

**Internal infra skills** (5 modules):
- [skills/knowledge.py](skills/knowledge.py) — RAG over `knowledge_chunks` (Titan-v2 query embedding + HNSW cosine).
- [skills/templates.py](skills/templates.py) — Jinja2 string renderer; templates live in [templates/](templates/).
- [skills/pdf.py](skills/pdf.py) — Jinja2 + WeasyPrint; **falls back to writing HTML** on `weasyprint` import failure (Windows GTK3 trap).
- [skills/webhook.py](skills/webhook.py) — real httpx POST with tenacity retry (3 attempts, exponential backoff). Returns `{ok: false, error, error_type}` on failure rather than raising.
- [skills/events.py](skills/events.py) — thin wrapper around `db.state_io` for the `communication_agent` event queue (`emit`/`pop_unprocessed`/`mark_processed`).
- [skills/ui.py](skills/ui.py) — in-memory + log-file push channel for the CM panel (`push_prompt`/`push_sentiment`/`push_slot_options`).

**Database helpers:**
- [db/state_io.py](db/state_io.py) — async DB read/write helpers, one per entity (members, cases, risk_scores, extracted_fields, reviewer_decisions, outreach_sessions, call_sessions, appointments, referrals, compliance_findings, audit_log, case_events). Callers compose helpers inside their own transactions; only `update_case_state` owns its transaction.
- [db/pool.py](db/pool.py) — added `configure_async_loop_policy()` helper (sets `WindowsSelectorEventLoopPolicy` on Windows; psycopg async incompatibility with `ProactorEventLoop`).

**Schema additions:**
- New table `case_events` (event queue for the communication_agent). Schema is re-applied idempotently via `python -m scripts.bootstrap_db`.

**Templates:**
- `templates/sms_appointment_confirmation.j2` — SMS body for booked appointment.
- `templates/appointment_confirmation.j2` — HTML→PDF appointment confirmation.

**Live verification:**
- [scripts/smoke_step4_foundations.py](scripts/smoke_step4_foundations.py) — PII redaction, ID minting, structlog auto-redaction, Bedrock chat (`PONG`), Bedrock embed (1024 dims), RAG retrieval (cosine 0.752 on COPD-PCP query). All [OK].
- [scripts/smoke_step4_skills.py](scripts/smoke_step4_skills.py) — exercises every skill end-to-end against the seeded John Martinez case on Neon. 22 [OK] checks. Highlights:
  - `documents.extract_fields` → 11 fields, 1 flagged (matches POC)
  - `sentiment.score_turn` trend → 62 (early "tight on breathing") → 85 ("yes, please")
  - `messaging` round-trip → canned replies surfaced in order ("Speaking.", "March 15th, 1952.")
  - `pdf.render` → fell back to HTML (WeasyPrint not installed on Windows; deliberate fallback path)
  - `webhook.post` → graceful `ConnectError` failure (no sink listening)
  - `events.emit/pop_unprocessed/mark_processed` → round-trip through `case_events` on Neon

**Deferred:**
- WeasyPrint native install for real PDF rendering — install GTK3 runtime + `weasyprint` when first agent actually needs a PDF artifact in front of a user (Step 12 scheduling).
- `skills.ui` is still log-file-only; real WebSocket fan-out lands when the FastAPI surface comes up (Step 7+).
- `skills.webhook` retry config (3 attempts, 0.5–4s backoff) is reasonable but not load-tested.

**Driveable demos:**
- `python -m scripts.smoke_step4_foundations`
- `python -m scripts.smoke_step4_skills` (idempotent — seeds CASE-00099999 once, reuses thereafter)

---

## Step 5 — `orchestration_agent` (build fully)

**Goal:** Stand up the polling dispatcher that drives every case from `DISCHARGE_RECEIVED` to terminal. State-machine-enforced; agent failures don't lose cases; transient blips self-heal; persistent failures escalate.

**What changed:**
- [config/orchestrator.py](config/orchestrator.py) — single source of truth for the dispatch table:
  - `STATE_TO_AGENT_NAME`: `DISCHARGE_RECEIVED → admission_risk_agent`, `RISK_STRATIFIED → document_extraction_agent`, `OUTREACH_SCHEDULED → outreach_agent`, `APPOINTMENT_BOOKED → compliance_agent`.
  - `AUTO_TRANSITIONS`: `DOCUMENT_APPROVED → OUTREACH_SCHEDULED` (orchestrator advances itself; no agent needed).
  - `MILESTONE_STATES`: 10 states that emit `case_events` on entry.
  - Retry: `MAX_RETRIES=3`, backoff `(60s, 300s, 1800s)`.
  - Lease: `DISPATCH_LEASE_SECONDS=300` (bumps `next_eligible_at` so a long-running dispatch isn't re-claimed).
- [agents/_registry.py](agents/_registry.py) — `register(name, fn)` / `get(name)` / `all_registered()` / `_reset()` (test helper). Agent shape: `async def run(case_id: str) -> None`.
- [agents/__init__.py](agents/__init__.py) — imports trigger registry side-effects (stubs added Step 6+ will register themselves here).
- [agents/orchestration_agent.py](agents/orchestration_agent.py):
  - `_claim_cases(limit)` — `SELECT ... FOR UPDATE SKIP LOCKED` + lease bump. Single-instance now, multi-instance ready.
  - `_dispatch_case(case)` — auto-transition → agent lookup → dispatch → milestone emit on state change.
  - `_handle_agent_failure(case, agent_name, exc)` — increments `agent_retry_count`, sets `next_eligible_at = now + backoff`, writes a `transient_failure` audit row. Escalates on `count >= MAX_RETRIES`.
  - `tick(limit=N)` — one pass; returns claimed-case stats.
  - `run(poll_interval_s, max_ticks, stop_event)` — continuous loop with cooperative stop.
- [scripts/run_orchestrator.py](scripts/run_orchestrator.py) — standalone runner (SIGINT/SIGTERM stop on Unix; no-op on Windows). Used until FastAPI lands in Step 7.
- [scripts/smoke_step5_orchestrator.py](scripts/smoke_step5_orchestrator.py) — 4-scenario smoke (happy / auto / transient / escalation).

**Schema additions (idempotent ALTERs on `cases`):**
- `agent_retry_count INTEGER NOT NULL DEFAULT 0`
- `agent_last_error TEXT`
- `next_eligible_at TIMESTAMPTZ` + partial index `WHERE next_eligible_at IS NOT NULL`.

**`update_case_state` change:** on every successful transition it now resets `agent_retry_count=0`, `agent_last_error=NULL`, `next_eligible_at=NULL` in the same statement. Failed/no-op transitions don't touch these fields.

**Live verification (against Neon):**
- Scenario 1 (happy path): `DISCHARGE_RECEIVED → RISK_STRATIFIED` in one tick; retry=0, lease cleared, milestone in `case_events`, audit row written.
- Scenario 2 (auto-transition): `DOCUMENT_APPROVED → OUTREACH_SCHEDULED` with no agent registered; milestone emitted.
- Scenario 3 (transient): agent raises `RuntimeError`; retry=1, backoff=60s, `agent_last_error` recorded, `transient_failure` audit row, case still in `DISCHARGE_RECEIVED`.
- Scenario 4 (escalation): with `agent_retry_count` pre-loaded to 2, the next failure transitions to `ESCALATED` (3/3 attempts), milestone emitted, reason captures the error chain.

**Decision locked in:** retry-with-backoff-then-escalate. 3 strikes (60s · 5min · 30min). Configurable via `ORCHESTRATOR_MAX_RETRIES` and `ORCHESTRATOR_DISPATCH_LEASE_SECONDS`.

**Deferred:**
- Live exercise of multi-orchestrator concurrency. `FOR UPDATE SKIP LOCKED` + lease is in place but only one instance has been run.
- Wiring orchestrator into a FastAPI lifespan-managed daemon — lands in Step 7.

**Driveable demo:**
- `python -m scripts.smoke_step5_orchestrator` (4 scenarios; leaves `CASE-00099999` in `DISCHARGE_RECEIVED` for the next step)
- `python -m scripts.run_orchestrator --max-ticks 1 --poll 5` (single tick against current DB state)

---

## Step 6 — `admission_risk_agent` (stub)

**Goal:** First of the 7 teammate-owned stubs. Walks `DISCHARGE_RECEIVED → RISK_STRATIFIED` end-to-end so downstream stubs land on populated data. Teammate (per [agent_prompts/01_admission_risk_agent.md](agent_prompts/01_admission_risk_agent.md)) replaces the deterministic scoring with LLM-driven sub-component scoring.

**What changed:**
- [agents/admission_risk_agent.py](agents/admission_risk_agent.py) — stub: reads input state, calls (mocked) `skills.member.get_profile` + `skills.claims.get_member_history` to keep audit trail realistic, mirrors the case into CRM via `skills.crm.create_case`, writes John Martinez's POC scores into `risk_scores`, denormalizes `crm_case_record_id`/`composite_priority`/`priority_tier` onto `cases`, creates 4 CRM workflow tasks, and advances state via `update_case_state`. Idempotent: re-entry with state past `DISCHARGE_RECEIVED` logs `stub_already_past` and exits.
- [agents/__init__.py](agents/__init__.py) — imports `admission_risk_agent` so the registry side-effect fires.
- [config/priority_tiers.py](config/priority_tiers.py) — `tier_for(score) -> PriorityTier` with thresholds 50/80.
- [config/stp_rules.py](config/stp_rules.py) — `is_stp(case) -> bool = False` placeholder; 5 candidate rules documented for business sign-off.
- [config/high_risk_dx.csv](config/high_risk_dx.csv) — 24 ICD-10 prefixes (respiratory / cardio / endocrine / neuro / renal / behavioral) seeded from [knowledge/tcm_guidelines/high_risk_icd10.md](knowledge/tcm_guidelines/high_risk_icd10.md).
- [scripts/smoke_step6_admission_risk.py](scripts/smoke_step6_admission_risk.py) — orchestrator-driven smoke test (19 checks).

**Live verification (against Neon, orchestrator-driven):**
- Tier helpers: `tier_for(42)=Low`, `tier_for(73)=Medium`, `tier_for(80)=High`.
- `is_stp(stub) == False` — every case routes through the human gate (until business signs off on the rules).
- One orchestrator `tick()` advances `CASE-00099999`: `DISCHARGE_RECEIVED → RISK_STRATIFIED`.
- `risk_scores` row inserted with subscores matching the POC exactly (Impactability 42 = 9+8+9+8+8, Intervenability 31 = 7+8+8+8, Composite 73 = Medium).
- `cases.crm_case_record_id` set to a freshly minted `CRM-NNNNNNNN`.
- 4 CRM tasks created (in-memory CRM mock): "Verify member contactability", "Schedule discharge summary review", "Prepare TCM outreach materials", "Confirm PCP follow-up window (7-10 days)".
- `audit_log` shows exactly one `RISK_STRATIFIED` transition row with `agent_name='admission_risk_agent'`.
- `case_events` has `state.RISK_STRATIFIED` milestone.
- **Idempotency:** 3 replay ticks each log `agent_not_registered` for `document_extraction_agent` (Step 8) and do not double-write anything — `risk_scores` row count stays at 1, audit row count stays at 1.

**Notes for the teammate (carried into the stub's TODO header):**
- Use the Strands Agents SDK for the LLM scoring step (`pip install strands-agents`). The stub doesn't import strands because the stub does no LLM work.
- The canonical schema is [models/schemas.py](models/schemas.py) + [skills.md](skills.md). The teammate's spec references case-level convenience fields (`case.impactability`, `case.claims_summary`, etc.) that **do not exist** in this schema — write to the `risk_scores` table instead via `db.state_io.insert_risk_scores`.
- Composite math, tiering, state transition, and CRM/task writes stay deterministic — the LLM only produces the 9 sub-component scores per the system prompt.

**Driveable demo:**
- `python -m scripts.smoke_step6_admission_risk` (idempotent; leaves `CASE-00099999` in `RISK_STRATIFIED` so Step 8 can pick it up).

---

## Step 7 — FastAPI core + lifespan-hosted orchestrator

**Goal:** Stand up the API surface that hosts the orchestrator polling loop as a lifespan-managed daemon inside one uvicorn process. Swagger at `/docs` becomes the rolling demo surface for every later step.

**What changed:**
- [api/main.py](api/main.py) — `FastAPI(lifespan=lifespan)` factory. Lifespan: open DB pool → start orchestrator `asyncio.Task` (if `ORCHESTRATOR_ENABLED=true`) → yield → set stop event, await task (10s grace; cancel on timeout), close pool.
- [api/settings.py](api/settings.py) — `pydantic-settings` `BaseSettings` reading `.env` + `os.environ`. Typed config: `database_url`, `bedrock_*`, `orchestrator_*`, `admin_token`.
- [api/dependencies.py](api/dependencies.py) — `db_conn()` async generator dep (pool-borrowed connection per request), `require_admin_token(...)` (Header dep; 503 if `ADMIN_TOKEN` unset, 401 if mismatch).
- [api/routes/health.py](api/routes/health.py) — `GET /health` (DB ping + Bedrock credential probe; no Bedrock API call).
- [api/routes/cases.py](api/routes/cases.py) — `GET /cases/{case_id}` returns `CaseView` (`case + risk_scores + extracted_fields + referrals + compliance_findings + audit_log`); `GET /cases?state=...` lists by state (default = all dispatchable).
- [api/routes/intake.py](api/routes/intake.py) — `POST /cases/intake` normalizes a discharge event, mints a `CASE-NNNNNNNN`, inserts in `DISCHARGE_RECEIVED`. Returns 201 with the new `Case` or 409 with `existing_case_id` on dedup conflict (UniqueViolation on `cases_dedup_key`).
- [api/routes/admin.py](api/routes/admin.py) — `POST /admin/orchestrator/tick?limit=N` (header-auth-gated). Returns claim stats.
- [.env](.env) / [.env.example](.env.example) — `ORCHESTRATOR_ENABLED`, `ORCHESTRATOR_TICK_LIMIT`, `ADMIN_TOKEN` added.
- [scripts/smoke_step7_api.py](scripts/smoke_step7_api.py) — 19-check smoke. Uses `httpx.ASGITransport(app=app)` so the lifespan is actually exercised; disables the background daemon via `ORCHESTRATOR_ENABLED=false` so the admin tick is the only thing that moves cases (deterministic).

**Live verification (against Neon + real Bedrock probe):**
- `GET /` returns the meta envelope with `/docs` link.
- `GET /health` returns `{status: ok, db: {ok: true}, bedrock: {region, chat_model: claude-sonnet-4, embed_model: titan-v2, credentials_present: true}, orchestrator: {enabled: false, poll_seconds: 5}}`.
- `GET /cases?state=DISCHARGE_RECEIVED` returns the list with CASE-00099999 present after a reset.
- `POST /admin/orchestrator/tick` without token → **401** with `invalid admin token`.
- `POST /admin/orchestrator/tick` with `X-Admin-Token: <env>` → **200**, claims CASE-00099999, admission_risk_agent runs, transitions to RISK_STRATIFIED.
- `GET /cases/CASE-00099999` returns the full view: state=RISK_STRATIFIED, risk_scores.composite_priority=73, audit_log present.
- `GET /cases/CASE-99999999` → 404.
- `POST /cases/intake` (fresh member MBR-99000001 / 2026-11-03) → 201 with a new minted case_id (CASE-95353914 in the run).
- Repeat intake (same dedup key) → 409 with `{detail: {error: "duplicate_discharge_event", existing_case_id: "CASE-95353914"}}`.

**Notes:**
- Lifespan-hosted orchestrator task is named `orchestrator_daemon`. On shutdown the stop event is set + a 10s grace `wait_for` is attempted; cancel-with-suppressed-CancelledError as the hard fallback. uvicorn's `--reload` reuses this path on every reload.
- Pool warm-up is idempotent (`get_pool()` returns the singleton); helpful when tests + uvicorn share the same module.
- I used `httpx.ASGITransport(app=app)` rather than `fastapi.TestClient` so the smoke could be fully async and consistent with the rest of the codebase. Lifespan still runs (httpx's ASGITransport drives the startup/shutdown protocol).

**Demoable surface (`uvicorn api.main:app --reload --port 8000`):**
- `http://localhost:8000/docs` — Swagger UI
- `http://localhost:8000/health`
- `http://localhost:8000/cases?state=DISCHARGE_RECEIVED`
- `http://localhost:8000/cases/{case_id}`
- `POST http://localhost:8000/cases/intake` with the DischargeEventIn JSON shape
- `POST http://localhost:8000/admin/orchestrator/tick` (header `X-Admin-Token: <env ADMIN_TOKEN>`)

**Deferred:**
- Comms-event polling daemon — lands with the communication_agent in Step 14 (also lifespan-hosted in the same uvicorn process).
- WebSocket fan-out for the CM panel (`skills.ui`) — wires up alongside the agent_assist endpoints in Step 11.
- Proper auth (JWT / OAuth) — POC only uses a static admin token in `.env`.

**Driveable demo:** `python -m scripts.smoke_step7_api` or `uvicorn api.main:app --port 8000` then visit `/docs`.

---

## Step 8 — `document_extraction_agent` + endpoints

**Goal:** Second teammate-owned agent, now full real implementation. Walks `RISK_STRATIFIED → DOCUMENT_PENDING_REVIEW` — extracting 13 per-field values + confidence from the discharge summary, flagging fields below the 0.80 confidence threshold for the clinician reviewer, and persisting denormalized `cases.extraction_flags` + `cases.is_stp` for the reviewer UI without an extra round-trip. Escalates after two failed document fetches.

**What changed:**
- [agents/document_extraction_agent.py](agents/document_extraction_agent.py) — real implementation (replaced the Step 8 stub):
  - Idempotency: state-guard (`current_state != RISK_STRATIFIED` returns) + extraction-row-guard (reuses pre-existing `extracted_fields` rather than re-extracting).
  - Document fetch retries: `MAX_DOCUMENT_FETCH_ATTEMPTS = 2` per `config.extraction`. Final failure transitions the case to `ESCALATED` with the last-error type on the audit metadata.
  - Bedrock-backed per-field extractor via [`skills.documents.extract_fields_llm`](skills/documents.py). `BedrockError` and `ExtractionParseError` propagate to the orchestrator — the agent does NOT silently fall back to the deterministic mock, so LLM outages surface to on-call instead of being papered over with stub data.
  - 0.80 flag threshold applied **deterministically in Python**, not by the LLM. Builds the denormalized `case.extraction_flags` array of `{field, confidence, reason, tier}`.
  - STP check via `config.stp_rules.is_stp(case)` (currently always False) persisted to `cases.is_stp` alongside the flags.
  - Transition flows through `db.state.update_case_state` — the milestone event for `DOCUMENT_PENDING_REVIEW` is emitted by that helper, not by the agent.
- [config/extraction.py](config/extraction.py) — new module owning the prompt skeleton, the 13 `EXPECTED_FIELDS` + tier hints, `LOW_CONFIDENCE_THRESHOLD = 0.80`, `MAX_DOCUMENT_FETCH_ATTEMPTS = 2`, `MAX_DOC_CHARS_FOR_LLM = 24_000`.
- [skills/documents.py](skills/documents.py) — added `extract_fields_llm` (Bedrock Converse call → JSON parsing → normalized `ExtractedField` rows) + the JSON-parsing helpers (`_parse_extractor_json`, `_payload_to_fields`, `_stringify_value`, `_clamp_confidence`) + new `ExtractionParseError` exception. The fixture-based `extract_fields` stays for unit tests + offline smoke scripts, but the agent does NOT use it as a runtime fallback.
- [skills/_fixtures.py](skills/_fixtures.py) — extended the canned John Martinez extraction from 11 → 13 fields (`last_spo2`, `discharge_disposition`).
- [skills/ehr.py](skills/ehr.py) + [data/documents/MBR-00847291_2026-10-05_discharge.md](data/documents/MBR-00847291_2026-10-05_discharge.md) — synthesized markdown now carries the `Last SpO2` and `Discharge Disposition` lines so the LLM has source text to extract from.
- [db/schema.sql](db/schema.sql) — added `cases.extraction_flags JSONB` and `cases.is_stp BOOLEAN NOT NULL DEFAULT FALSE` via idempotent `ALTER TABLE ... ADD COLUMN IF NOT EXISTS`. Re-runnable against existing Neon instances.
- [models/schemas.py](models/schemas.py) — added the new fields to the `Case` model.
- [api/routes/extraction.py](api/routes/extraction.py) — `GET /cases/{case_id}/extraction` already returned `ExtractionView`; no change. The full-case `GET /cases/{case_id}` (which serializes the `Case` model) now also surfaces the new columns.
- [scripts/smoke_step8_document_extraction.py](scripts/smoke_step8_document_extraction.py) — updated to expect 13 fields, the new `extraction_flags` payload, and `is_stp=False`. Reset clause also clears the two new columns.
- [scripts/smoke_step4_skills.py](scripts/smoke_step4_skills.py) + [scripts/smoke_step10_review.py](scripts/smoke_step10_review.py) — bumped the hard-coded 11 → 13.
- [tests/](tests/) — new pytest suite:
  - [tests/test_document_extraction_unit.py](tests/test_document_extraction_unit.py) — unit tests for the prompt + thresholds + JSON-parsing helpers + flag aggregation.
  - [tests/test_document_extraction_agent.py](tests/test_document_extraction_agent.py) — integration tests for `agent.run`, mocking the DB pool + EHR/Bedrock skills. Covers happy-path (LLM and fixture-fallback), retry-then-escalate, idempotency, and unknown-case behavior.
  - [tests/conftest.py](tests/conftest.py) — shared fixtures (John Martinez `Case` row, in-memory fake DB pool).
  - [pytest.ini](pytest.ini) — `asyncio_mode = auto` so async test funcs need no decorator.

**Verification (offline):**
- `python -m py_compile` clean on every touched file.
- `python -m pytest tests/` — 30+ checks across the new suite. (Run inside the project's uv-managed venv, where `pydantic`, `pytest`, `pytest-asyncio` are already installed.)

**Live verification (Neon + ASGI lifespan):**
- Tick 1: `DISCHARGE_RECEIVED → RISK_STRATIFIED` (admission_risk_agent).
- Tick 2: `RISK_STRATIFIED → DOCUMENT_PENDING_REVIEW` (document_extraction_agent).
- 13 `extracted_fields` rows persisted, 1 flagged. Flagged field = `medication_changes` at confidence `0.72`.
- `GET /cases/CASE-00099999/extraction`: `total_fields=13`, `flagged_count=1`, `flagged_field_names=['medication_changes']`, `ready_for_review=true`.
- `GET /cases/CASE-00099999`: `case.is_stp=false`, `case.extraction_flags=[{"field":"medication_changes","confidence":0.72,"reason":"...","tier":"low"}]`.
- `case_events` contains `state.RISK_STRATIFIED` and `state.DOCUMENT_PENDING_REVIEW` milestones.
- Tick 3 (with lease cleared): orchestrator returns `claimed=0` for our case — `DOCUMENT_PENDING_REVIEW` is intentionally NOT in `DISPATCHABLE_STATES` (human gate). `extracted_fields` count stays at 13.

**Architectural notes:**
- The Bedrock call is wrapped behind `skills.documents.extract_fields_llm`. The agent never imports `skills.bedrock` directly — keeps the LLM call site swappable (e.g., for a future vision-capable model that takes the raw PDF rather than parsed text).
- Bedrock failures (`BedrockError`) and JSON-parse failures (`ExtractionParseError`) propagate from `agent.run` to the orchestrator. The orchestrator's `MAX_RETRIES=3` policy retries the dispatch with `60s / 5min / 30min` backoff and transitions to `ESCALATED` on the third failure. We deliberately did NOT wrap the LLM call in a fallback to the fixture extractor — that would mask outages and ship stub data to the clinician reviewer.
- `cases.extraction_flags` is a denormalization of `extracted_fields.flagged=true`. Source of truth remains the per-field rows; the JSON column saves the reviewer queue a re-join.

**Driveable demo:**
- `python -m scripts.smoke_step8_document_extraction` (walks the case end-to-end from `DISCHARGE_RECEIVED`)
- `python -m pytest tests/test_document_extraction_unit.py tests/test_document_extraction_agent.py -v`
- `GET http://localhost:8000/cases/CASE-00099999/extraction` while uvicorn is running

**Open questions carried forward:**
- STP rules (5 candidate rules in [config/stp_rules.py](config/stp_rules.py)) — business sign-off still pending. Once finalized, `is_stp(case)` will gate auto-approval before the human review for compliant cases.
- Offline smoke runs (no Bedrock) currently fail at the LLM call. Acceptable for now — the smoke script's purpose is end-to-end exercise, and end-to-end means Bedrock has to be reachable. If we need a fully-offline smoke for CI, wire it through `skills.documents.extract_fields` directly via an environment switch on the agent, rather than re-introducing a silent fallback.

---

## Step 9 — `outreach_agent` (stub) with RAG + endpoints

**Goal:** Third stub. Walks `OUTREACH_SCHEDULED → OUTREACH_COMPLETE` by simulating the 6-step TCM messaging conversation against the canned John Martinez replies, exercising the RAG corpus once, and persisting a populated `OutreachSession` (transcript + survey + SDOH flags) for downstream stubs.

**Step-ordering caveat:** Step 8 leaves the case in `DOCUMENT_PENDING_REVIEW` (human gate). The reviewer endpoint that moves it to `DOCUMENT_APPROVED → OUTREACH_SCHEDULED` lands in Step 10. For Step 9's smoke, we bypass the gate via raw SQL (test-only — flagged in the script). Step 10 will provide the proper transition.

**What changed:**
- [agents/outreach_agent.py](agents/outreach_agent.py) — stub:
  - Opens a messaging session via `skills.messaging.open_session`.
  - Sends 7 outbound canned prompts paired 1:1 with John Martinez's 7 canned replies from `skills._fixtures` (identity verify x2, clinical check-in x3, CMP pitch, callback preference).
  - Issues one `skills.knowledge.search_guidelines` call (query: "Care Management Program enrollment criteria for COPD post-discharge") so the RAG corpus is exercised on the audit trail.
  - Builds `SurveyForm` with POC values (`symptoms="Mild dyspnea, morning SOB"`, `medication_pickup=True`, `pcp_followup_scheduled=False`, `cmp_enrollment=True`, `contact_phone="+15558472910"`).
  - Derives `sdoh_flags = ["no_pcp_appt"]` from the survey gate.
  - Persists `OutreachSession` (14 turns) via `db.state_io.insert_outreach_session`.
  - Closes the messaging session + transitions state.
  - Two-layer idempotency: state guard + prior-session guard (if a complete session already exists for the case, transitions without re-running).
- [agents/__init__.py](agents/__init__.py) — imports the new stub.
- [api/routes/outreach.py](api/routes/outreach.py) — `GET /cases/{case_id}/outreach` returns the most-recent `OutreachSession` or 404.
- [api/main.py](api/main.py) — includes the new router.
- [scripts/smoke_step9_outreach.py](scripts/smoke_step9_outreach.py) — 17-check smoke (state bypass + tick + endpoint).

**Live verification (Neon + ASGI lifespan):**
- One tick from `OUTREACH_SCHEDULED` → `OUTREACH_COMPLETE`. Session `MS-NNNNNNNN` minted.
- 14-turn transcript persisted (7 tcm + 7 member). First member reply is the canned "Speaking.".
- `survey.medication_pickup=True`, `survey.pcp_followup_scheduled=False`, `survey.cmp_enrollment=True` — matches POC exactly.
- `sdoh_flags == ["no_pcp_appt"]`. Other flag types (transport, lives_alone, language_barrier) are deferred to the real LLM impl.
- RAG call observable in logs (`rag_grounding` event with top hit + similarity).
- `case_events` contains `state.OUTREACH_COMPLETE` milestone.
- Re-tick is a no-op: `OUTREACH_COMPLETE` is **not** in `DISPATCHABLE_STATES` (the next state — `CM_CALLBACK_IN_PROGRESS` — is foreground-triggered by an HTTP call when the CM picks up, not the orchestrator).

**Driveable demo:**
- `python -m scripts.smoke_step9_outreach` (bypasses the human gate; one tick + endpoint check)
- `GET http://localhost:8000/cases/CASE-00099999/outreach` while uvicorn is running

---

## Step 10 — Human review endpoints (first true end-to-end)

**Goal:** Close the loop on the human gate. `POST /cases/{id}/review` records a clinician outcome (approve / reject / escalate) and drives the state transition; `GET /clinician/queue` powers the reviewer UI. After Step 10 the case walks `DISCHARGE_RECEIVED → OUTREACH_COMPLETE` end-to-end via the live FastAPI surface with **zero raw-SQL bypasses**.

**What changed:**
- [api/routes/review.py](api/routes/review.py) — `POST /cases/{case_id}/review`:
  - Body: `{reviewer_id, outcome: approve|reject|escalate, comments?}`.
  - Pre-conditions: case must exist (404) and be in `DOCUMENT_PENDING_REVIEW` (409 with `expected_state` in detail).
  - Inserts a `reviewer_decisions` row with `expires_at = now + clinician_review_sla_hours` (env-configurable, default 4h).
  - Transitions: `approve → DOCUMENT_APPROVED`, `reject → ESCALATED`, `escalate → ESCALATED`.
- [api/routes/clinician.py](api/routes/clinician.py) — `GET /clinician/queue`:
  - Returns `list[QueueItem]` (case + `flagged_count` + `total_fields`).
  - Single SQL join against `extracted_fields` for per-case flag count; ordered oldest-first.
- [api/settings.py](api/settings.py) — added `clinician_review_sla_hours: int = 4`.
- [api/main.py](api/main.py) — includes review + clinician routers.

**Architectural fix — milestone emission moved into `update_case_state`:**
- The reviewer endpoint's `DOCUMENT_APPROVED` transition was missing a `case_events` row because milestone emission was only wired in the orchestrator's `_dispatch_case`. Any other state-mutation path (API endpoints, future foreground calls) would silently skip the comms queue.
- Fix: `db.state.update_case_state` now inserts a `case_events` row when `new_state ∈ MILESTONE_STATES`, inside the same transaction as the state UPDATE + audit insert. Single source of truth.
- Removed three now-redundant `_emit_milestone` calls from `agents/orchestration_agent.py` (auto-transition path, agent dispatch path, escalation path). The `_emit_milestone` helper itself was deleted along with the `insert_case_event` import.

**Live verification (full end-to-end via API only):**
```
Start: CASE-00099999 in DISCHARGE_RECEIVED (clean reset).

Tick 1 → admission_risk_agent       → RISK_STRATIFIED
Tick 2 → document_extraction_agent  → DOCUMENT_PENDING_REVIEW
GET /clinician/queue                → CASE-00099999 present, flagged_count=1, total_fields=11
POST /cases/{id}/review approve     → DOCUMENT_APPROVED
                                      reviewer_decisions row written
                                      (reviewer_id, outcome=approve, expires_at=+4h)
Tick 3 → orchestrator auto-transition → OUTREACH_SCHEDULED
Tick 4 → outreach_agent              → OUTREACH_COMPLETE

audit_log: 5 transition rows in expected order.
case_events: { RISK_STRATIFIED, DOCUMENT_PENDING_REVIEW, DOCUMENT_APPROVED,
               OUTREACH_SCHEDULED, OUTREACH_COMPLETE } — all 5 milestones present.
```

**Negative paths verified:**
- `POST /cases/{id}/review` in `DISCHARGE_RECEIVED` → 409 with `expected_state`.
- `POST /cases/CASE-NO-EXIST/review` → 404.
- `reject` outcome → `ESCALATED` (separate test case, business decision locked in this step).

**Driveable demo:** `python -m scripts.smoke_step10_review` (full chain via API; 24 checks).

---

## Step 11 — `agent_assist_agent` (stub) + real-time call endpoints

**Goal:** First **foreground** agent — runs as a background asyncio task on the FastAPI event loop, NOT orchestrator-dispatched. POST initiates the call; subsequent GETs poll partial progress until the canned replay completes.

**What changed:**
- [agents/agent_assist_agent.py](agents/agent_assist_agent.py) — stub: `async def run(case_id, *, call_id, cm_id)`:
  - Iterates `skills.transcript.subscribe` (yields 12 canned John Martinez turns at 0.05s each).
  - On member turns: `skills.sentiment.score_turn` → appends `{ts, speaker, score_0_100, label}` to `sentiment_trend`; sets `CallTurn.sentiment` on the persisted turn (mapped 0–100 → -1.0..1.0). Pushes a live sentiment event via `skills.ui.push_sentiment`.
  - On CM turns: matches against 4 trigger keywords (`how have you been` → p1_breathing; `inhaler` → p2_oximeter; `transportation` → p3_transport; `next week` → p4_schedule). Each prompt fires once, in order, via `skills.ui.push_prompt`.
  - Detects verbal consent on `"yes, please"` substring → sets `consent_captured=True` + stores excerpt.
  - Persists `CallSession` every 2 turns (so polled GETs see live motion), then a final write with `status=complete` + `ended_at`. Does **not** transition case state — Step 12's scheduling_agent owns the move to `APPOINTMENT_BOOKED`.
  - 30-turn safety cap.
  - NOT registered in `_registry` (foreground agent — not orchestrator-dispatched).
- [agents/__init__.py](agents/__init__.py) — imports the new stub.
- [api/routes/call.py](api/routes/call.py):
  - `POST /cases/{id}/call/start` body: `{cm_id}`. Pre-conditions: case must exist (404), case must be in `OUTREACH_COMPLETE` (409). Mints `CL-NNNNNNNN`, inserts `CallSession(status=in_progress)`, transitions case to `CM_CALLBACK_IN_PROGRESS`, spawns `agent_assist_agent.run(...)` via `asyncio.create_task` named `agent_assist_{call_id}`. Returns **202 Accepted** with `{call_id, current_state, status}`.
  - `GET /cases/{id}/call` returns the most-recent `CallSession` for the case (404 if none).
- [api/main.py](api/main.py) — wires the new call router.
- [scripts/smoke_step11_call.py](scripts/smoke_step11_call.py) — 19-check smoke. Drives the case via API from `DISCHARGE_RECEIVED` → `OUTREACH_COMPLETE` (4 ticks + 1 review), then exercises the call lifecycle.

**Live verification (background asyncio task on the ASGI lifespan):**
- 12-turn transcript persisted.
- 4 prompts fired in canonical order `[1, 2, 3, 4]` — verified via `prompt_idx` list.
- `consent_captured=True`, `consent_excerpt="Yes, please."` (canned reply turn 12).
- Sentiment trend: first member score `62` → last `85` (label `very_positive`). UI ring buffer received the sequence of sentiment events.
- `audit_log` records one `CM_CALLBACK_IN_PROGRESS` transition row from `agent_name="agent_assist_agent"`.
- `case_events` correctly does **not** include `state.CM_CALLBACK_IN_PROGRESS` (foreground call state — intentionally excluded from `MILESTONE_STATES`). Prior milestones preserved.

**Negative paths verified:**
- `POST /call/start` while not in `OUTREACH_COMPLETE` → 409 with `expected_state`.
- `GET /call` before any call session → 404.
- Re-POST while case is already `CM_CALLBACK_IN_PROGRESS` → 409.

**Driveable demo:**
- `python -m scripts.smoke_step11_call` (full chain via API from `DISCHARGE_RECEIVED`; polls until `status=complete`).

---

## Step 12 — `scheduling_agent` (stub) + endpoints + artifact rendering

**Goal:** Fourth foreground stub. CM-triggered mid-call (after verbal consent is captured by `agent_assist_agent`). Books the PCP appointment, sends SMS, renders a PDF (HTML fallback when WeasyPrint isn't installed), updates the Patient Journey Calendar, creates a follow-up task, and inserts the Valley CHC pulse oximeter referral — all within a single POST.

**What changed:**
- [agents/scheduling_agent.py](agents/scheduling_agent.py) — stub:
  1. Reads case + latest `CallSession`, enforces `consent_captured=True` (raises `ConsentNotCaptured` if not).
  2. `skills.scheduling.get_availability(pcp_id="PCP-00042100", window=[discharge+1d, discharge+10d])`.
  3. Picks earliest slot matching `outreach.survey.callback_preference` ("afternoon" → Oct 10 14:00, matches POC).
  4. `skills.scheduling.book_appointment(...)` → `Appointment` instance.
  5. Renders SMS body via `skills.templates.render("sms_appointment_confirmation.j2", ...)`.
  6. `skills.sms.send(...)` (stub appends to `data/outbox/sms.log` with phone redacted).
  7. `db.state_io.insert_appointment` persists; appointment_id returned.
  8. `skills.crm.create_appointment(...)` mirrors into CRM.
  9. `skills.calendar.add_event(...)` updates Patient Journey Calendar.
  10. `skills.pdf.render("appointment_confirmation.j2", ...)` (HTML fallback on Windows without GTK3).
  11. `skills.crm.create_task("Follow up after PCP visit and confirm device receipt", due_at=slot+1d)`.
  12. `db.state_io.insert_referral` for Valley CHC pulse oximeter (`device`/`community`/`created`).
  13. `update_case_state(CM_CALLBACK_IN_PROGRESS → APPOINTMENT_BOOKED)` with rich metadata (appointment_id, scheduled_at, sms_sid, follow_up_task_id, referral_id, pdf_artifact path).
- [agents/__init__.py](agents/__init__.py) — imports the new stub.
- [api/routes/scheduling.py](api/routes/scheduling.py):
  - `POST /cases/{id}/schedule` body: `{cm_id}`. Pre-conditions: case exists (404), case in `CM_CALLBACK_IN_PROGRESS` (409), latest `CallSession.consent_captured=True` (409). Returns 201 with `{case_id, current_state, appointment}`.
  - `GET /cases/{id}/appointment` returns the latest booked appointment (404 if none).
- [api/main.py](api/main.py) — wires the scheduling router.
- [models/schemas.py](models/schemas.py) — `SurveyForm.callback_preference: str | None` added; outreach_agent stub now populates it as `"afternoon"`.
- [db/state_io.py](db/state_io.py) — added `get_latest_appointment(conn, case_id)` and `get_latest_call_session(conn, case_id)` helpers.
- [scripts/smoke_step12_scheduling.py](scripts/smoke_step12_scheduling.py) — 20-check end-to-end: reset → tick×2 → review approve → tick×2 → call/start + poll → schedule → verify all artifacts.

**Live verification (full chain via API only):**
```
CASE-00099999 path:
  DISCHARGE_RECEIVED -> RISK_STRATIFIED -> DOCUMENT_PENDING_REVIEW
  -> DOCUMENT_APPROVED (via /review) -> OUTREACH_SCHEDULED
  -> OUTREACH_COMPLETE -> CM_CALLBACK_IN_PROGRESS (via /call/start)
  -> APPOINTMENT_BOOKED (via /schedule)

Artifacts created in one POST /schedule:
  · Appointment row: provider=Dr. Luis Garcia, scheduled_at=2026-10-10T14:00:00Z, sms_confirmation_sent=true
  · sms.log line with case_id + "Luis Garcia" + redacted phone (***)***-2910
  · data/documents/CASE-00099999_appointment_confirmation.html (PDF fallback; GTK3 not installed)
  · calendar event "PCP follow-up: Dr. Luis Garcia" at slot time
  · referral row: Valley CHC pulse oximeter / device / community / created
  · CRM task "Follow up after PCP visit and confirm device receipt" due slot+1d
  · audit_log: APPOINTMENT_BOOKED transition with full metadata
  · case_events: state.APPOINTMENT_BOOKED milestone emitted
```

**Negative paths verified:**
- Re-POST `/schedule` on `APPOINTMENT_BOOKED` state → 409.
- POST `/schedule` with `consent_captured=False` on the latest CallSession → 409 with `error: consent_not_captured`.

**Driveable demo:** `python -m scripts.smoke_step12_scheduling` (idempotent; resets the case before walking it).
