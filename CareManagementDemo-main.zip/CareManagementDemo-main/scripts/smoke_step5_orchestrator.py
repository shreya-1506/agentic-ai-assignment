"""Step 5 smoke test — orchestrator dispatch + retry + escalate + auto-transition.

Four scenarios, all run against the live Neon DB using `CASE-00099999`:

  1. Happy path:
     Register a fake agent for DISCHARGE_RECEIVED that advances the case to
     RISK_STRATIFIED. After one tick: state advanced, audit_log has both the
     agent's row AND no orchestrator failure row, case_events has the
     `state.RISK_STRATIFIED` milestone.

  2. Auto-transition:
     Reset the case to DOCUMENT_APPROVED. Without registering any agent,
     one tick should auto-advance to OUTREACH_SCHEDULED and emit a milestone.

  3. Transient failure:
     Register a fake agent that always raises. After one tick: agent_retry_count
     incremented, next_eligible_at set, audit_log shows transient_failure.

  4. Escalation:
     Force agent_retry_count = MAX_RETRIES-1 + clear next_eligible_at; one more
     failing tick should escalate the case to ESCALATED.

Each scenario resets `CASE-00099999` via raw SQL (test-only bypass of the
state machine) and clears the registry afterward.
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.ingest_knowledge import _load_env

_load_env()

from db.pool import configure_async_loop_policy

configure_async_loop_policy()

from agents._registry import register as register_agent, _reset as reset_registry  # noqa: E402
from agents.orchestration_agent import tick  # noqa: E402
from config.orchestrator import MAX_RETRIES  # noqa: E402
from db.pool import connection  # noqa: E402
from db.state import update_case_state  # noqa: E402
from db.state_io import get_case, list_audit_log  # noqa: E402
from models.schemas import CaseState  # noqa: E402

CASE_ID = "CASE-00099999"


async def _reset_case(state: CaseState) -> None:
    """Bypass the state machine. Test-only."""
    async with connection() as conn:
        async with conn.transaction():
            async with conn.cursor() as cur:
                await cur.execute(
                    """
                    UPDATE cases SET
                        current_state     = %s,
                        agent_retry_count = 0,
                        agent_last_error  = NULL,
                        next_eligible_at  = NULL
                      WHERE case_id = %s
                    """,
                    (state.value, CASE_ID),
                )
                # also wipe audit_log + case_events for the case so each
                # scenario reads a clean slate
                await cur.execute("DELETE FROM audit_log WHERE case_id = %s", (CASE_ID,))
                await cur.execute("DELETE FROM case_events WHERE case_id = %s", (CASE_ID,))


async def _force_retry_count(n: int) -> None:
    """Pre-load agent_retry_count and clear the lease (so the next tick fires)."""
    async with connection() as conn:
        async with conn.transaction():
            async with conn.cursor() as cur:
                await cur.execute(
                    """
                    UPDATE cases SET
                        agent_retry_count = %s,
                        next_eligible_at  = NULL
                      WHERE case_id = %s
                    """,
                    (n, CASE_ID),
                )


async def _count_audit_rows() -> int:
    async with connection() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT count(*) FROM audit_log WHERE case_id = %s", (CASE_ID,)
            )
            return (await cur.fetchone())[0]


async def _count_case_events() -> list[dict]:
    async with connection() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT event_type, payload FROM case_events WHERE case_id = %s ORDER BY event_id",
                (CASE_ID,),
            )
            rows = await cur.fetchall()
            return [{"event_type": r[0], "payload": r[1]} for r in rows]


def _check(label: str, ok: bool, detail: str = "") -> None:
    marker = "[OK]" if ok else "[FAIL]"
    suffix = f" -- {detail}" if detail else ""
    print(f"  {marker} {label}{suffix}")
    if not ok:
        raise AssertionError(label)


# ----------------------------- scenarios ------------------------------------


async def scenario_happy_path() -> None:
    print("\n--- Scenario 1: happy path ---")
    await _reset_case(CaseState.DISCHARGE_RECEIVED)
    reset_registry()

    # Fake agent that advances the case to RISK_STRATIFIED.
    async def fake_admission_risk(case_id: str) -> None:
        async with connection() as conn:
            await update_case_state(
                conn,
                case_id,
                CaseState.RISK_STRATIFIED,
                agent_name="admission_risk_agent",
                reason="test stub transitioned",
            )

    register_agent("admission_risk_agent", fake_admission_risk)

    stats = await tick(limit=5)
    _check("claimed CASE-00099999", CASE_ID in stats["case_ids"])

    async with connection() as conn:
        case = await get_case(conn, CASE_ID)
    _check("state advanced to RISK_STRATIFIED", case.current_state == CaseState.RISK_STRATIFIED)
    _check("retry count is 0 after success", case.agent_retry_count == 0)
    _check("lease cleared after success", case.next_eligible_at is None)

    events = await _count_case_events()
    _check(
        "milestone emitted to case_events",
        any(e["event_type"] == "state.RISK_STRATIFIED" for e in events),
        f"events={events}",
    )

    async with connection() as conn:
        audits = await list_audit_log(conn, CASE_ID)
    transitioned = [a for a in audits if a.to_state == CaseState.RISK_STRATIFIED]
    _check("audit_log has the RISK_STRATIFIED transition", len(transitioned) == 1)


async def scenario_auto_transition() -> None:
    print("\n--- Scenario 2: auto-transition (DOCUMENT_APPROVED -> OUTREACH_SCHEDULED) ---")
    await _reset_case(CaseState.DOCUMENT_APPROVED)
    reset_registry()  # no agent registered for OUTREACH_SCHEDULED in this scenario

    await tick(limit=5)

    async with connection() as conn:
        case = await get_case(conn, CASE_ID)
    _check(
        "auto-transitioned to OUTREACH_SCHEDULED",
        case.current_state == CaseState.OUTREACH_SCHEDULED,
    )
    events = await _count_case_events()
    _check(
        "milestone emitted for OUTREACH_SCHEDULED",
        any(e["event_type"] == "state.OUTREACH_SCHEDULED" for e in events),
        f"events={events}",
    )


async def scenario_transient_failure() -> None:
    print("\n--- Scenario 3: transient failure ---")
    await _reset_case(CaseState.DISCHARGE_RECEIVED)
    reset_registry()

    async def always_raises(case_id: str) -> None:
        raise RuntimeError("simulated transient blip")

    register_agent("admission_risk_agent", always_raises)
    await tick(limit=5)

    async with connection() as conn:
        case = await get_case(conn, CASE_ID)
    _check(
        "case did not transition out of DISCHARGE_RECEIVED",
        case.current_state == CaseState.DISCHARGE_RECEIVED,
    )
    _check("agent_retry_count == 1", case.agent_retry_count == 1)
    _check("agent_last_error recorded", "simulated transient blip" in (case.agent_last_error or ""))
    _check("next_eligible_at set", case.next_eligible_at is not None)

    async with connection() as conn:
        audits = await list_audit_log(conn, CASE_ID)
    transient_rows = [a for a in audits if "transient_failure" in a.reason]
    _check("audit_log has a transient_failure row", len(transient_rows) == 1)


async def scenario_escalation() -> None:
    print(f"\n--- Scenario 4: escalation after MAX_RETRIES={MAX_RETRIES} failures ---")
    await _reset_case(CaseState.DISCHARGE_RECEIVED)
    reset_registry()

    async def always_raises(case_id: str) -> None:
        raise RuntimeError("simulated persistent failure")

    register_agent("admission_risk_agent", always_raises)

    # Force retry_count to MAX_RETRIES-1, clear lease — next failure escalates.
    await _force_retry_count(MAX_RETRIES - 1)
    await tick(limit=5)

    async with connection() as conn:
        case = await get_case(conn, CASE_ID)
    _check("case escalated to ESCALATED", case.current_state == CaseState.ESCALATED)

    events = await _count_case_events()
    _check(
        "milestone emitted for ESCALATED",
        any(e["event_type"] == "state.ESCALATED" for e in events),
        f"events={events}",
    )

    async with connection() as conn:
        audits = await list_audit_log(conn, CASE_ID)
    escal_rows = [a for a in audits if a.to_state == CaseState.ESCALATED]
    _check("audit_log has the ESCALATED transition", len(escal_rows) == 1)
    _check(
        "audit_log reason mentions retries exhausted",
        any("retries exhausted" in a.reason for a in escal_rows),
    )


# ----------------------------- driver ---------------------------------------


async def main() -> int:
    print("=== Step 5 orchestrator smoke test ===")
    print(f"  case_id: {CASE_ID}")
    try:
        await scenario_happy_path()
        await scenario_auto_transition()
        await scenario_transient_failure()
        await scenario_escalation()
    except AssertionError as e:
        print(f"\nFAILED: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"\nERROR: {type(e).__name__}: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 2

    # Leave the case in a clean DISCHARGE_RECEIVED for the next step
    await _reset_case(CaseState.DISCHARGE_RECEIVED)
    reset_registry()

    print("\nAll orchestrator scenarios OK.")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
