"""Step 11 smoke - agent_assist_agent foreground stub via /call/start + polling.

Starts the case at OUTREACH_COMPLETE (re-runs Step 10's reset + 4 ticks +
approve to get there), then:

  POST /cases/{id}/call/start          -> 202 with call_id, case in CM_CALLBACK_IN_PROGRESS
  poll GET /cases/{id}/call            -> watch transcript grow + status flip to complete
  assert: 12 turns total, 4 prompts fired (p1..p4 in order),
          sentiment trends Neutral -> Very Positive,
          consent_captured=True with the "Yes, please." excerpt

Plus negative paths:
  - POST /call/start on wrong state -> 409
  - GET /call before any call -> 404
"""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.ingest_knowledge import _load_env

_load_env()
os.environ["ORCHESTRATOR_ENABLED"] = "false"

from db.pool import configure_async_loop_policy  # noqa: E402

configure_async_loop_policy()

import httpx  # noqa: E402

from api.main import app  # noqa: E402
from api.settings import get_settings  # noqa: E402
from db.pool import connection  # noqa: E402

CASE_ID = "CASE-00099999"
ADMIN_TOKEN = get_settings().admin_token or ""
HEADERS = {"X-Admin-Token": ADMIN_TOKEN}


async def _reset_to_outreach_complete(client: httpx.AsyncClient) -> None:
    """Drive the case from a clean DISCHARGE_RECEIVED to OUTREACH_COMPLETE."""
    async with connection() as conn:
        async with conn.transaction():
            async with conn.cursor() as cur:
                for tbl in (
                    "extracted_fields",
                    "outreach_sessions",
                    "risk_scores",
                    "reviewer_decisions",
                    "call_sessions",
                    "audit_log",
                    "case_events",
                ):
                    await cur.execute(f"DELETE FROM {tbl} WHERE case_id = %s", (CASE_ID,))
                await cur.execute(
                    """
                    UPDATE cases SET
                        current_state = 'DISCHARGE_RECEIVED',
                        priority_tier = NULL,
                        composite_priority = NULL,
                        crm_case_record_id = NULL,
                        agent_retry_count = 0,
                        agent_last_error = NULL,
                        next_eligible_at = NULL
                      WHERE case_id = %s
                    """,
                    (CASE_ID,),
                )

    # tick 1 -> RISK_STRATIFIED
    await client.post("/admin/orchestrator/tick", headers=HEADERS)
    # tick 2 -> DOCUMENT_PENDING_REVIEW
    await client.post("/admin/orchestrator/tick", headers=HEADERS)
    # approve -> DOCUMENT_APPROVED
    await client.post(
        f"/cases/{CASE_ID}/review",
        json={"reviewer_id": "test", "outcome": "approve"},
    )
    # tick 3 -> OUTREACH_SCHEDULED (auto-transition)
    await client.post("/admin/orchestrator/tick", headers=HEADERS)
    # tick 4 -> OUTREACH_COMPLETE
    await client.post("/admin/orchestrator/tick", headers=HEADERS)


def _check(label: str, ok: bool, detail: str = "") -> None:
    marker = "[OK]" if ok else "[FAIL]"
    suffix = f" -- {detail}" if detail else ""
    print(f"  {marker} {label}{suffix}")
    if not ok:
        raise AssertionError(label)


async def main() -> int:
    print("=== Step 11 agent_assist_agent smoke ===")

    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testapi") as client:

        # GET /call before any call -> 404
        await client.get(f"/cases/{CASE_ID}/call")  # warm-up to ensure app is up
        # Drive to OUTREACH_COMPLETE
        await _reset_to_outreach_complete(client)

        # ---- Negative: GET /call before any call ---------------------------
        # (call_sessions was wiped in the reset)
        r = await client.get(f"/cases/{CASE_ID}/call")
        _check("GET /call before start -> 404", r.status_code == 404)

        # ---- POST /call/start ---------------------------------------------
        r = await client.post(
            f"/cases/{CASE_ID}/call/start",
            json={"cm_id": "cm.sarah@example.com"},
        )
        _check("POST /call/start -> 202", r.status_code == 202,
               f"status={r.status_code} body={r.text[:200]}")
        start_body = r.json()
        call_id = start_body["call_id"]
        _check("call_id is CL-NNNNNNNN", call_id.startswith("CL-"))
        _check("state advanced to CM_CALLBACK_IN_PROGRESS",
               start_body["current_state"] == "CM_CALLBACK_IN_PROGRESS")
        _check("status == in_progress", start_body["status"] == "in_progress")

        # ---- Re-POST should now 409 (case already past OUTREACH_COMPLETE) -
        r = await client.post(
            f"/cases/{CASE_ID}/call/start",
            json={"cm_id": "cm.sarah@example.com"},
        )
        _check("POST /call/start while in CM_CALLBACK_IN_PROGRESS -> 409",
               r.status_code == 409)

        # ---- Poll GET /call until status=complete --------------------------
        final_view = None
        for i in range(60):  # 6s max
            r = await client.get(f"/cases/{CASE_ID}/call")
            if r.status_code == 200 and r.json().get("status") == "complete":
                final_view = r.json()
                break
            await asyncio.sleep(0.1)
        if final_view is None:
            r = await client.get(f"/cases/{CASE_ID}/call")
            raise AssertionError(
                f"call did not reach status=complete in 6s; last status={r.json().get('status')}, "
                f"turns={len(r.json().get('transcript', []))}"
            )

        # ---- Verify final state -------------------------------------------
        _check("transcript has 12 turns", len(final_view["transcript"]) == 12,
               f"got {len(final_view['transcript'])}")
        _check("consent_captured == True", final_view["consent_captured"] is True)
        _check("consent_excerpt == 'Yes, please.'",
               final_view["consent_excerpt"] == "Yes, please.",
               f"got={final_view['consent_excerpt']!r}")

        # 4 prompts in order
        prompts = final_view["prompts_fired"]
        _check("4 prompts fired", len(prompts) == 4, f"got {len(prompts)}")
        _check("prompts fired in order (1..4)",
               [p["prompt_idx"] for p in prompts] == [1, 2, 3, 4],
               f"got={[p['prompt_idx'] for p in prompts]}")

        # Sentiment trends positive
        st = final_view["sentiment_trend"]
        _check("at least 1 member sentiment entry", len(st) >= 1)
        first_score = st[0]["score_0_100"]
        last_score = st[-1]["score_0_100"]
        _check(
            f"sentiment trends positive ({first_score} -> {last_score})",
            last_score > first_score,
            f"first={first_score} last={last_score}",
        )
        _check("final label is positive or very_positive",
               st[-1]["label"] in ("positive", "very_positive"),
               f"label={st[-1]['label']}")

        # Audit log + case_events for the CM_CALLBACK_IN_PROGRESS transition
        r = await client.get(f"/cases/{CASE_ID}")
        audits = r.json()["audit_log"]
        callback_audits = [a for a in audits if a["to_state"] == "CM_CALLBACK_IN_PROGRESS"]
        _check("audit_log has CM_CALLBACK_IN_PROGRESS transition", len(callback_audits) == 1)

        async with connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT event_type FROM case_events WHERE case_id = %s ORDER BY event_id",
                    (CASE_ID,),
                )
                events = [r[0] for r in await cur.fetchall()]
        # CM_CALLBACK_IN_PROGRESS is NOT in MILESTONE_STATES so no milestone event
        # is expected; the prior milestones (RISK, DOCUMENT_PENDING_REVIEW,
        # DOCUMENT_APPROVED, OUTREACH_SCHEDULED, OUTREACH_COMPLETE) should remain.
        for required in (
            "state.OUTREACH_COMPLETE",
            "state.DOCUMENT_APPROVED",
        ):
            _check(f"prior milestone {required!r} preserved", required in events,
                   f"events={events}")
        _check(
            "no spurious state.CM_CALLBACK_IN_PROGRESS milestone",
            "state.CM_CALLBACK_IN_PROGRESS" not in events,
            f"events={events}",
        )

    print("\nAll Step 11 checks OK.")
    print(f"  CASE-00099999 is in CM_CALLBACK_IN_PROGRESS with call_id={call_id}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
