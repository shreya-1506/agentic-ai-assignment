"""End-to-end smoke test for the full Step 4 skills layer.

Touches every mocked external system. Inserts (and leaves behind) a John
Martinez member + case row on the live DB, then exercises each skill
against that case. Idempotent on re-run.

Run:  python -m scripts.smoke_step4_skills
"""

from __future__ import annotations

import asyncio
import sys
from datetime import date, datetime, timezone, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.ingest_knowledge import _load_env

_load_env()

from db.pool import configure_async_loop_policy, connection  # noqa: E402

configure_async_loop_policy()

from db.state_io import (  # noqa: E402
    get_case,
    get_member,
    insert_case,
    insert_member,
)
from models.schemas import Case, CaseState  # noqa: E402
from skills import (  # noqa: E402
    calendar,
    claims,
    community,
    crm,
    documents,
    ehr,
    email,
    events,
    formulary,
    member,
    messaging,
    pdf,
    scheduling,
    sentiment,
    sms,
    templates,
    transcript,
    ui,
    webhook,
)
from skills._fixtures import (  # noqa: E402
    JOHN_MARTINEZ_DISCHARGE_EVENT,
    JOHN_MARTINEZ_MEMBER_ID,
)

CASE_ID = "CASE-00099999"


async def _seed_case_and_member() -> None:
    """Ensure a John Martinez member + CASE-00099999 row exist on Neon."""
    async with connection() as conn:
        existing_member = await get_member(conn, JOHN_MARTINEZ_MEMBER_ID)
        if existing_member is None:
            m = member.get_profile(CASE_ID, JOHN_MARTINEZ_MEMBER_ID)
            async with conn.transaction():
                await insert_member(conn, m)
            print("  seeded member: John Martinez")
        else:
            print("  member already seeded")

        existing_case = await get_case(conn, CASE_ID)
        if existing_case is None:
            c = Case(
                case_id=CASE_ID,
                member_id=JOHN_MARTINEZ_MEMBER_ID,
                current_state=CaseState.DISCHARGE_RECEIVED,
                discharge_facility=JOHN_MARTINEZ_DISCHARGE_EVENT["facility"],
                discharge_date=date.fromisoformat(JOHN_MARTINEZ_DISCHARGE_EVENT["discharge_date"]),
                admit_date=date.fromisoformat(JOHN_MARTINEZ_DISCHARGE_EVENT["admit_date"]),
                length_of_stay=JOHN_MARTINEZ_DISCHARGE_EVENT["length_of_stay_days"],
                primary_dx_code=JOHN_MARTINEZ_DISCHARGE_EVENT["primary_dx_code"],
                primary_dx_description=JOHN_MARTINEZ_DISCHARGE_EVENT["primary_dx_description"],
                attending_physician=JOHN_MARTINEZ_DISCHARGE_EVENT["attending_physician"],
                pcp_name=JOHN_MARTINEZ_DISCHARGE_EVENT["pcp_name"],
                plan_name=JOHN_MARTINEZ_DISCHARGE_EVENT["plan_name"],
                raw_discharge_event=JOHN_MARTINEZ_DISCHARGE_EVENT,
            )
            async with conn.transaction():
                await insert_case(conn, c)
            print(f"  seeded case: {CASE_ID}")
        else:
            print(f"  case already seeded: {CASE_ID}")


def _check(label: str, ok: bool, detail: str = "") -> None:
    marker = "[OK]" if ok else "[FAIL]"
    suffix = f" -- {detail}" if detail else ""
    print(f"  {marker} {label}{suffix}")
    if not ok:
        raise AssertionError(label)


async def main() -> int:
    print("=== Step 4 skills end-to-end smoke ===")
    print(f"  case_id: {CASE_ID}")

    await _seed_case_and_member()

    # ---- member ------------------------------------------------------------
    profile = member.get_profile(CASE_ID, JOHN_MARTINEZ_MEMBER_ID)
    _check("member.get_profile", profile.first_name == "John")
    _check(
        "member.verify_identity (positive)",
        member.verify_identity(
            CASE_ID, JOHN_MARTINEZ_MEMBER_ID,
            dob_provided=date(1952, 3, 15),
            name_provided="John Martinez",
        ),
    )
    _check(
        "member.verify_identity (negative DOB)",
        not member.verify_identity(
            CASE_ID, JOHN_MARTINEZ_MEMBER_ID,
            dob_provided=date(1900, 1, 1),
            name_provided="John Martinez",
        ),
    )

    # ---- claims ------------------------------------------------------------
    history = claims.get_member_history(CASE_ID, JOHN_MARTINEZ_MEMBER_ID)
    _check("claims.get_member_history", len(history["admits"]) == 2)

    # ---- ehr + documents ---------------------------------------------------
    doc_path = ehr.fetch_discharge_summary(CASE_ID, JOHN_MARTINEZ_MEMBER_ID, date(2026, 10, 5))
    _check("ehr.fetch_discharge_summary", doc_path.exists())
    text = documents.parse_pdf(CASE_ID, doc_path)
    _check("documents.parse_pdf", "COPD" in text)
    fields = documents.extract_fields(CASE_ID, text)
    flagged = [f for f in fields if f.flagged]
    _check(
        "documents.extract_fields",
        len(fields) == 13 and len(flagged) == 1,
        f"got {len(fields)} fields, {len(flagged)} flagged",
    )

    # ---- formulary ---------------------------------------------------------
    cov = formulary.check_coverage(CASE_ID, "Prednisone 40 mg", "BlueCross Premier")
    _check("formulary.check_coverage (Prednisone)", cov["covered"] and cov["tier"] == 1)

    # ---- crm ---------------------------------------------------------------
    crm._reset()
    crm_num = crm.create_case(CASE_ID, JOHN_MARTINEZ_MEMBER_ID, plan="BlueCross Premier")
    _check("crm.create_case", crm_num.startswith("CRM-"))
    crm.update_case(CASE_ID, crm_num, priority_tier="medium")
    task_id = crm.create_task(CASE_ID, title="Verify member contactability")
    _check("crm.create_task", task_id.startswith("TASK-"))

    # ---- scheduling --------------------------------------------------------
    win_start = datetime(2026, 10, 8, tzinfo=timezone.utc)
    win_end = datetime(2026, 10, 15, tzinfo=timezone.utc)
    slots = scheduling.get_availability(CASE_ID, "PCP-00042100", win_start, win_end)
    _check("scheduling.get_availability", len(slots) >= 1)
    appt = scheduling.book_appointment(CASE_ID, "PCP-00042100", slots[2])
    _check("scheduling.book_appointment", appt.scheduled_at == slots[2])

    # ---- sms + email -------------------------------------------------------
    sid = sms.send(CASE_ID, "(555) 847-2910", "Your appointment is confirmed.")
    _check("sms.send", sid.startswith("SM"))
    mid = email.send(CASE_ID, "john.martinez@example.com", "Welcome to CMP", "Body.")
    _check("email.send", mid.startswith("MSG-"))

    # ---- calendar ----------------------------------------------------------
    calendar._reset()
    cal_id = calendar.add_event(
        CASE_ID, JOHN_MARTINEZ_MEMBER_ID, appt.scheduled_at, "PCP follow-up: Dr. Garcia"
    )
    _check("calendar.add_event", bool(cal_id) and len(calendar._all_events()) == 1)

    # ---- messaging ---------------------------------------------------------
    messaging._reset()
    session_id = messaging.open_session(CASE_ID, JOHN_MARTINEZ_MEMBER_ID, "(555) 847-2910")
    messaging.send_message(CASE_ID, session_id, "Hi John, may I confirm your DOB?")
    reply1 = messaging.poll_for_reply(CASE_ID, session_id)
    reply2 = messaging.poll_for_reply(CASE_ID, session_id)
    _check("messaging round-trip", reply1 == "Speaking." and "1952" in reply2)
    messaging.close_session(CASE_ID, session_id)

    # ---- transcript --------------------------------------------------------
    last = transcript.get_recent(CASE_ID, "CL-00011223", n=4)
    _check("transcript.get_recent", len(last) == 4 and last[-1].text.lower() == "yes, please.")
    collected = [t async for t in transcript.subscribe(CASE_ID, "CL-00011223", interval_s=0.001)]
    _check("transcript.subscribe", len(collected) == 12)

    # ---- sentiment ---------------------------------------------------------
    early = sentiment.score_turn(CASE_ID, "Doing okay, the mornings are still a little tight on the breathing.")
    late = sentiment.score_turn(CASE_ID, "Yes, please.")
    _check(
        "sentiment trends positive over call",
        late["score_0_100"] > early["score_0_100"],
        f"early={early}, late={late}",
    )

    # ---- community ---------------------------------------------------------
    hits = community.search_resources(
        CASE_ID, need_type="device", subtype="pulse_oximeter", member_zip="94101"
    )
    _check("community.search_resources (pulse oximeter)", any("Valley" in r["name"] for r in hits))

    # ---- templates + pdf ---------------------------------------------------
    body = templates.render(
        CASE_ID,
        "sms_appointment_confirmation.j2",
        {
            "member_first_name": "John",
            "provider_name": "Dr. Garcia",
            "slot_human": "Oct 10, 2026 at 2:00 PM",
            "location": "Springfield Primary Care Clinic",
        },
    )
    _check("templates.render (sms)", "John" in body and "Garcia" in body)

    pdf_path = pdf.render(
        CASE_ID,
        "appointment_confirmation.j2",
        {
            "case_id": CASE_ID,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "member_name": "John Martinez",
            "member_id": JOHN_MARTINEZ_MEMBER_ID,
            "plan_name": "BlueCross Premier",
            "provider_name": "Dr. Luis Garcia",
            "specialty": "Primary Care",
            "slot_human": "Oct 10, 2026 at 2:00 PM",
            "location": "Springfield Primary Care Clinic",
        },
    )
    _check("pdf.render (or HTML fallback)", pdf_path.exists())

    # ---- webhook (graceful failure expected — no sink listening) -----------
    resp = webhook.post(CASE_ID, {"event": "smoke_test"}, url="http://127.0.0.1:9/sink")
    _check("webhook.post (graceful failure)", "error" in resp)

    # ---- events (DB-backed) -----------------------------------------------
    eid = await events.emit(CASE_ID, "smoke_test", {"k": "v"})
    _check("events.emit", isinstance(eid, int))
    pending = await events.pop_unprocessed(limit=10)
    _check("events.pop_unprocessed", any(e["event_id"] == eid for e in pending))
    await events.mark_processed(eid, "sent")
    _check("events.mark_processed", True)

    # ---- ui ----------------------------------------------------------------
    ui.push_prompt(CASE_ID, "p1", {"text": "Last SpO2 was 93%"})
    ui.push_sentiment(CASE_ID, {"label": "very_positive", "score_0_100": 90})
    ui.push_slot_options(CASE_ID, "CL-00011223", [appt.scheduled_at])
    drained = ui._drain(CASE_ID)
    _check("ui.push_* x3", len(drained) == 3)

    print("\nAll skills OK.")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
