"""One-off driver for `document_extraction_agent.run`.

Bypasses the orchestrator: invokes the agent the same way the dispatch loop
would, but with no polling, no retry/backoff, no other agents. Useful when
you want to:
  - debug just this agent in your IDE (set breakpoints in agent.run)
  - re-run extraction after fixing a prompt change
  - exercise the agent against a specific case_id without the orchestrator

Usage
-----
  # default: walks CASE-00099999 (seeded John Martinez)
  python -m scripts.run_document_extraction

  # specific case
  python -m scripts.run_document_extraction CASE-12345678

  # reset the case back to RISK_STRATIFIED first (clears extracted_fields,
  # extraction_flags, is_stp) so you can replay end-to-end
  python -m scripts.run_document_extraction CASE-00099999 --reset

Pre-conditions
--------------
  - DATABASE_URL set in .env (points at Neon)
  - For real LLM extraction: AWS creds + BEDROCK_MODEL_ID set. Without them
    the agent will raise BedrockError (no silent fallback) -- that's the
    production behavior; rerun with creds to get a successful walk.
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.ingest_knowledge import _load_env

_load_env()

from db.pool import configure_async_loop_policy  # noqa: E402

configure_async_loop_policy()

from agents.document_extraction_agent import run  # noqa: E402
from db.pool import close_pool, connection  # noqa: E402
from db.state_io import get_case, list_extracted_fields  # noqa: E402


async def _reset(case_id: str) -> None:
    """Move the case back to RISK_STRATIFIED so the agent will pick it up."""
    async with connection() as conn:
        async with conn.transaction():
            async with conn.cursor() as cur:
                await cur.execute(
                    "DELETE FROM extracted_fields WHERE case_id = %s",
                    (case_id,),
                )
                await cur.execute(
                    """
                    UPDATE cases SET
                        current_state    = 'RISK_STRATIFIED',
                        extraction_flags = NULL,
                        is_stp           = FALSE,
                        agent_retry_count = 0,
                        agent_last_error  = NULL,
                        next_eligible_at  = NULL
                      WHERE case_id = %s
                    """,
                    (case_id,),
                )
    print(f"[reset] case={case_id} -> RISK_STRATIFIED")


async def _show(case_id: str) -> None:
    async with connection() as conn:
        case = await get_case(conn, case_id)
        fields = await list_extracted_fields(conn, case_id)
    if case is None:
        print(f"[result] case={case_id} not found")
        return
    flagged = [f for f in fields if f.flagged]
    print(f"[result] case={case_id}")
    print(f"  current_state      : {case.current_state.value}")
    print(f"  extracted_fields   : {len(fields)} ({len(flagged)} flagged)")
    print(f"  case.is_stp        : {case.is_stp}")
    print(f"  case.extraction_flags:")
    for entry in case.extraction_flags or []:
        print(f"    - {entry}")


async def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "case_id",
        nargs="?",
        default="CASE-00099999",
        help="case_id to extract for (default: CASE-00099999)",
    )
    parser.add_argument(
        "--reset",
        action="store_true",
        help="reset the case to RISK_STRATIFIED before running",
    )
    args = parser.parse_args()

    try:
        if args.reset:
            await _reset(args.case_id)
        print(f"[run]   agent.run({args.case_id!r})")
        await run(args.case_id)
        print("[run]   ok")
        await _show(args.case_id)
        return 0
    finally:
        await close_pool()


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
