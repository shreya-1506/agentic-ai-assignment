"""Step 6 smoke test — admission_risk_agent stub driven by the orchestrator.

  1. Reset CASE-00099999 to DISCHARGE_RECEIVED.
  2. Tick the orchestrator once.
  3. Verify:
       - state advanced to RISK_STRATIFIED
       - risk_scores row exists with John Martinez subscores (42 / 31 / 73 / Medium)
       - case.crm_case_record_id is set
       - case.composite_priority == 73
       - case.priority_tier == "medium"
       - audit_log has the RISK_STRATIFIED transition
       - case_events has the milestone
  4. Tick again — verify idempotency (no second risk_scores row, no second
     state transition, agent logs `stub_already_past`).

  5. Sanity-check `config.priority_tiers.tier_for` and `config.stp_rules.is_stp`.
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.ingest_knowledge import _load_env

_load_env()

from db.pool import configure_async_loop_policy

configure_async_loop_policy()

import agents  # noqa: F401,E402  triggers registration of admission_risk_agent
from agents._registry import all_registered  # noqa: E402
from agents.orchestration_agent import tick  # noqa: E402
from config.priority_tiers import tier_for  # noqa: E402
from config.stp_rules import is_stp  # noqa: E402
from db.pool import connection  # noqa: E402
from db.state_io import get_case, get_risk_scores, list_audit_log  # noqa: E402
from models.schemas import Case, CaseState, PriorityTier  # noqa: E402

CASE_ID = "CASE-00099999"


async def _reset_case_clean() -> None:
    """Hard reset CASE-00099999 to DISCHARGE_RECEIVED and clear downstream artifacts."""
    async with connection() as conn:
        async with conn.transaction():
            async with conn.cursor() as cur:
                await cur.execute("DELETE FROM risk_scores WHERE case_id = %s", (CASE_ID,))
                await cur.execute("DELETE FROM audit_log WHERE case_id = %s", (CASE_ID,))
                await cur.execute("DELETE FROM case_events WHERE case_id = %s", (CASE_ID,))
                await cur.execute(
                    """
                    UPDATE cases SET
                        current_state       = 'DISCHARGE_RECEIVED',
                        priority_tier       = NULL,
                        composite_priority  = NULL,
                        crm_case_record_id  = NULL,
                        agent_retry_count   = 0,
                        agent_last_error    = NULL,
                        next_eligible_at    = NULL
                      WHERE case_id = %s
                    """,
                    (CASE_ID,),
                )


def _check(label: str, ok: bool, detail: str = "") -> None:
    marker = "[OK]" if ok else "[FAIL]"
    suffix = f" -- {detail}" if detail else ""
    print(f"  {marker} {label}{suffix}")
    if not ok:
        raise AssertionError(label)


async def main() -> int:
    print("=== Step 6 admission_risk_agent stub smoke ===")

    # Registry sanity
    registry = all_registered()
    _check(
        "admission_risk_agent registered",
        "admission_risk_agent" in registry,
        f"registered={list(registry)}",
    )

    # Config helpers
    _check("tier_for(42) -> Low", tier_for(42) == PriorityTier.LOW)
    _check("tier_for(73) -> Medium", tier_for(73) == PriorityTier.MEDIUM)
    _check("tier_for(80) -> High", tier_for(80) == PriorityTier.HIGH)
    _check("is_stp(stub) returns False", is_stp(Case(
        case_id=CASE_ID, member_id="MBR-00847291",
        discharge_facility="X", discharge_date="2026-10-05", primary_dx_code="J44.1",
    )) is False)

    # ---- Happy path -------------------------------------------------------
    await _reset_case_clean()

    stats = await tick(limit=5)
    _check("orchestrator claimed CASE-00099999", CASE_ID in stats["case_ids"])

    async with connection() as conn:
        case = await get_case(conn, CASE_ID)
        risk = await get_risk_scores(conn, CASE_ID)
        audits = await list_audit_log(conn, CASE_ID)

    _check("state advanced to RISK_STRATIFIED", case.current_state == CaseState.RISK_STRATIFIED)
    _check("crm_case_record_id set", case.crm_case_record_id and case.crm_case_record_id.startswith("CRM-"))
    _check("case.composite_priority == 73", case.composite_priority == 73)
    _check("case.priority_tier == medium", case.priority_tier == PriorityTier.MEDIUM)

    _check("risk_scores row inserted", risk is not None)
    _check(
        "risk_scores totals match POC (Impact=42, Interv=31, Composite=73)",
        risk.impactability_total == 42 and risk.intervenability_total == 31 and risk.composite_priority == 73,
        f"got {risk.impactability_total}/{risk.intervenability_total}/{risk.composite_priority}",
    )
    _check("impactability subscores match POC",
        risk.impactability_subscores.clinical_severity == 9
        and risk.impactability_subscores.utilization == 8
        and risk.impactability_subscores.med_complexity == 9
        and risk.impactability_subscores.care_gaps == 8
        and risk.impactability_subscores.prior_engagement == 8,
    )
    _check("intervenability subscores match POC",
        risk.intervenability_subscores.sdoh == 7
        and risk.intervenability_subscores.insurance_pharmacy == 8
        and risk.intervenability_subscores.cognitive_behavioral == 8
        and risk.intervenability_subscores.contactability == 8,
    )

    transition_rows = [a for a in audits if a.to_state == CaseState.RISK_STRATIFIED]
    _check("audit_log has RISK_STRATIFIED transition", len(transition_rows) == 1)

    async with connection() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT event_type FROM case_events WHERE case_id = %s ORDER BY event_id",
                (CASE_ID,),
            )
            events = [r[0] for r in await cur.fetchall()]
    _check("case_events has state.RISK_STRATIFIED milestone", "state.RISK_STRATIFIED" in events)

    # ---- Idempotency ------------------------------------------------------
    # After Step 6, the case is in RISK_STRATIFIED. That state is dispatchable
    # (maps to document_extraction_agent, not yet registered in Step 6) so the
    # orchestrator will re-claim it on the next tick — but the only effect should
    # be an `agent_not_registered` log and a lease bump. No new audit rows under
    # admission_risk_agent, no new risk_scores row.
    print("\n--- Idempotency: replay ticks ---")
    for _ in range(3):
        # Clear the lease each iteration so the orchestrator definitely re-evaluates.
        async with connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "UPDATE cases SET next_eligible_at = NULL WHERE case_id = %s",
                    (CASE_ID,),
                )
        await tick(limit=5)

    async with connection() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT count(*) FROM audit_log WHERE case_id = %s AND to_state='RISK_STRATIFIED'",
                (CASE_ID,),
            )
            transition_count = (await cur.fetchone())[0]
            await cur.execute(
                "SELECT count(*) FROM audit_log WHERE case_id = %s AND agent_name='admission_risk_agent'",
                (CASE_ID,),
            )
            risk_agent_audits = (await cur.fetchone())[0]
            await cur.execute("SELECT count(*) FROM risk_scores WHERE case_id = %s", (CASE_ID,))
            risk_rows = (await cur.fetchone())[0]

    _check(
        "still only one RISK_STRATIFIED transition after 3 replay ticks",
        transition_count == 1,
        f"got {transition_count}",
    )
    _check(
        "admission_risk_agent only wrote audit once",
        risk_agent_audits == 1,
        f"got {risk_agent_audits}",
    )
    _check(
        "risk_scores has exactly one row after replays",
        risk_rows == 1,
        f"got {risk_rows}",
    )

    # Leave the case in RISK_STRATIFIED so Step 7+ can use it; reset only fresh state
    # if the user wants to re-test Step 6 from scratch (call this script again).
    print("\nAll Step 6 checks OK.")
    print(f"  CASE-00099999 is in state RISK_STRATIFIED with composite=73 (Medium).")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
