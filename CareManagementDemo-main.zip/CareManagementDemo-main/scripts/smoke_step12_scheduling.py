"""Step 12 smoke - scheduling_agent stub + /schedule endpoints.

Drives the case from DISCHARGE_RECEIVED to APPOINTMENT_BOOKED via API only:
  4 ticks + 1 approve -> OUTREACH_COMPLETE
  POST /call/start + poll until complete -> CM_CALLBACK_IN_PROGRESS w/ consent
  POST /cases/{id}/schedule -> APPOINTMENT_BOOKED

Verifies:
  - state advanced to APPOINTMENT_BOOKED
  - appointment row: provider=Dr. Luis Garcia, slot=2026-10-10T14:00:00 (POC pick)
  - SMS log line appended to data/outbox/sms.log
  - PDF/HTML artifact written under data/documents/
  - calendar event added (in-memory state, exposed via skills.calendar._all_events)
  - referral row exists for Valley CHC pulse oximeter
  - follow-up CRM task created
  - audit_log + case_events show the APPOINTMENT_BOOKED milestone

Negative paths:
  - POST /schedule on wrong state -> 409
  - POST /schedule when consent not captured -> 409
  - GET /cases/{id}/appointment when none exists -> 404
"""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.ingest_knowledge import _load_env

_load_env()
os.environ["ORCHESTRATOR_ENABLED"] = "false"

from db.pool import configure_async_loop_policy  # noqa: E402

configure_async_loop_policy()

import httpx  # noqa: E402

from api.main import app  # noqa: E402
from api.settings import get_settings  # noqa: E402
from db.pool import connection  # noqa: E402
from skills import calendar as calendar_skill  # noqa: E402

PROJECT_ROOT = Path(__file__).resolve().parent.parent
CASE_ID = "CASE-00099999"
ADMIN_TOKEN = get_settings().admin_token or ""
HEADERS = {"X-Admin-Token": ADMIN_TOKEN}


async def _reset_to_callback_in_progress(client: httpx.AsyncClient) -> str:
    """Drive a clean case all the way to CM_CALLBACK_IN_PROGRESS + completed call.
    Returns the call_id."""
    async with connection() as conn:
        async with conn.transaction():
            async with conn.cursor() as cur:
                for tbl in (
                    "appointments",
                    "referrals",
                    "extracted_fields",
                    "outreach_sessions",
                    "risk_scores",
                    "reviewer_decisions",
                    "call_sessions",
                    "audit_log",
                    "case_events",
                ):
                    await cur.execute(f"DELETE FROM {tbl} WHERE case_id = %s", (CASE_ID,))
                await cur.execute(
                    """
                    UPDATE cases SET
                        current_state = 'DISCHARGE_RECEIVED',
                        priority_tier = NULL,
                        composite_priority = NULL,
                        crm_case_record_id = NULL,
                        agent_retry_count = 0,
                        agent_last_error = NULL,
                        next_eligible_at = NULL
                      WHERE case_id = %s
                    """,
                    (CASE_ID,),
                )

    # Walk through the pipeline
    await client.post("/admin/orchestrator/tick", headers=HEADERS)  # -> RISK_STRATIFIED
    await client.post("/admin/orchestrator/tick", headers=HEADERS)  # -> DOCUMENT_PENDING_REVIEW
    await client.post(
        f"/cases/{CASE_ID}/review",
        json={"reviewer_id": "test", "outcome": "approve"},
    )
    await client.post("/admin/orchestrator/tick", headers=HEADERS)  # -> OUTREACH_SCHEDULED
    await client.post("/admin/orchestrator/tick", headers=HEADERS)  # -> OUTREACH_COMPLETE

    r = await client.post(
        f"/cases/{CASE_ID}/call/start",
        json={"cm_id": "cm.sarah@example.com"},
    )
    call_id = r.json()["call_id"]
    # Poll until call complete
    for _ in range(60):
        r = await client.get(f"/cases/{CASE_ID}/call")
        if r.status_code == 200 and r.json().get("status") == "complete":
            return call_id
        await asyncio.sleep(0.1)
    raise RuntimeError("call did not complete in 6s")


def _check(label: str, ok: bool, detail: str = "") -> None:
    marker = "[OK]" if ok else "[FAIL]"
    suffix = f" -- {detail}" if detail else ""
    print(f"  {marker} {label}{suffix}")
    if not ok:
        raise AssertionError(label)


async def main() -> int:
    print("=== Step 12 scheduling_agent smoke ===")

    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testapi") as client:

        # Reset skills.calendar in-memory store so our test count is deterministic.
        calendar_skill._reset()

        call_id = await _reset_to_callback_in_progress(client)
        print(f"  reached CM_CALLBACK_IN_PROGRESS with call_id={call_id}")

        # 404 before any appointment exists (the reset wiped appointments)
        r = await client.get(f"/cases/{CASE_ID}/appointment")
        _check("GET /appointment before scheduling -> 404",
               r.status_code == 404,
               f"status={r.status_code}")

        # ---- POST /schedule -> 201 ----------------------------------------
        r = await client.post(
            f"/cases/{CASE_ID}/schedule",
            json={"cm_id": "cm.sarah@example.com"},
        )
        _check("POST /cases/{id}/schedule -> 201",
               r.status_code == 201,
               f"status={r.status_code} body={r.text[:200]}")
        body = r.json()
        _check("response.current_state == APPOINTMENT_BOOKED",
               body["current_state"] == "APPOINTMENT_BOOKED")
        appt = body["appointment"]
        _check("provider == Dr. Luis Garcia",
               appt["provider_name"] == "Dr. Luis Garcia")
        _check(
            "scheduled_at matches POC pick (Oct 10 14:00 UTC)",
            appt["scheduled_at"].startswith("2026-10-10T14:00:00"),
            f"got={appt['scheduled_at']}",
        )
        _check("appointment status == booked", appt["status"] == "booked")
        _check("sms_confirmation_sent == True", appt["sms_confirmation_sent"] is True)

        # ---- GET /appointment ---------------------------------------------
        r = await client.get(f"/cases/{CASE_ID}/appointment")
        _check("GET /appointment -> 200", r.status_code == 200)
        _check("appointment retrieved matches POST",
               r.json()["appointment_id"] == appt["appointment_id"])

        # ---- Side-effect artifacts ----------------------------------------
        sms_log = PROJECT_ROOT / "data" / "outbox" / "sms.log"
        _check("data/outbox/sms.log exists", sms_log.exists())
        sms_text = sms_log.read_text(encoding="utf-8")
        _check("sms.log has confirmation line for case",
               CASE_ID in sms_text and "Luis Garcia" in sms_text)

        docs_dir = PROJECT_ROOT / "data" / "documents"
        pdf_or_html = list(docs_dir.glob(f"{CASE_ID}_appointment_confirmation.*"))
        _check(
            "appointment confirmation artifact rendered (PDF or HTML)",
            len(pdf_or_html) >= 1,
            f"found={[p.name for p in pdf_or_html]}",
        )

        # calendar event added
        cal_events = calendar_skill._all_events()
        _check(
            "calendar.add_event called once for the appointment",
            len(cal_events) == 1
            and cal_events[0].title.startswith("PCP follow-up:"),
            f"got={[e.title for e in cal_events]}",
        )

        # referral row in DB
        async with connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT resource_name, resource_type, source, status "
                    "FROM referrals WHERE case_id = %s ORDER BY referral_id DESC LIMIT 1",
                    (CASE_ID,),
                )
                ref = await cur.fetchone()
        _check("referral row exists", ref is not None)
        _check(
            "referral is Valley CHC pulse oximeter (device/community/created)",
            ref is not None
            and "Valley" in ref[0]
            and ref[1] == "device"
            and ref[2] == "community"
            and ref[3] == "created",
            f"got={ref}",
        )

        # follow-up CRM task — exposed only via in-memory dict in skills.crm
        from skills import crm as crm_skill
        follow_up_tasks = [
            t for t in crm_skill._all_tasks()
            if t.title.startswith("Follow up after PCP visit")
        ]
        _check("follow-up CRM task created", len(follow_up_tasks) >= 1)

        # audit + milestone
        r = await client.get(f"/cases/{CASE_ID}")
        audits = r.json()["audit_log"]
        booked = [a for a in audits if a["to_state"] == "APPOINTMENT_BOOKED"]
        _check("audit_log has APPOINTMENT_BOOKED transition", len(booked) == 1)

        async with connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT event_type FROM case_events WHERE case_id = %s ORDER BY event_id",
                    (CASE_ID,),
                )
                events = [r[0] for r in await cur.fetchall()]
        _check(
            "case_events contains state.APPOINTMENT_BOOKED milestone",
            "state.APPOINTMENT_BOOKED" in events,
            f"events={events}",
        )

        # ---- Negative: re-POST when already booked -> 409 -----------------
        r = await client.post(
            f"/cases/{CASE_ID}/schedule",
            json={"cm_id": "cm.sarah@example.com"},
        )
        _check(
            "POST /schedule on APPOINTMENT_BOOKED state -> 409",
            r.status_code == 409,
            f"status={r.status_code}",
        )

        # ---- Negative: POST /schedule when consent not captured -> 409 ---
        # Build a synthetic test case in CM_CALLBACK_IN_PROGRESS with consent=false.
        test_case = "CASE-00077777"
        async with connection() as conn:
            async with conn.transaction():
                async with conn.cursor() as cur:
                    await cur.execute("DELETE FROM audit_log WHERE case_id = %s", (test_case,))
                    await cur.execute("DELETE FROM call_sessions WHERE case_id = %s", (test_case,))
                    await cur.execute("DELETE FROM cases WHERE case_id = %s", (test_case,))
                    await cur.execute(
                        """
                        INSERT INTO cases (case_id, member_id, current_state,
                            discharge_facility, discharge_date, primary_dx_code)
                        VALUES (%s, %s, 'CM_CALLBACK_IN_PROGRESS', 'X', '2026-11-01', 'J44.1')
                        """,
                        (test_case, "MBR-00847291"),
                    )
                    await cur.execute(
                        """
                        INSERT INTO call_sessions (call_id, case_id, cm_id, status,
                            consent_captured)
                        VALUES ('CL-77777777', %s, 'cm.test', 'in_progress', FALSE)
                        """,
                        (test_case,),
                    )

        r = await client.post(
            f"/cases/{test_case}/schedule",
            json={"cm_id": "cm.test"},
        )
        _check(
            "POST /schedule without consent -> 409",
            r.status_code == 409,
            f"status={r.status_code} body={r.text[:200]}",
        )

        # Cleanup
        async with connection() as conn:
            async with conn.transaction():
                async with conn.cursor() as cur:
                    await cur.execute("DELETE FROM call_sessions WHERE case_id = %s", (test_case,))
                    await cur.execute("DELETE FROM audit_log WHERE case_id = %s", (test_case,))
                    await cur.execute("DELETE FROM cases WHERE case_id = %s", (test_case,))

    print("\nAll Step 12 checks OK.")
    print("  CASE-00099999 is in APPOINTMENT_BOOKED with the full artifact set.")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
