"""Step 10 smoke - human review endpoints + first true end-to-end run.

Drives CASE-00099999 from DISCHARGE_RECEIVED -> OUTREACH_COMPLETE through
the live FastAPI surface only. No raw-SQL bypasses (except the initial
reset to a clean DISCHARGE_RECEIVED state).

Sequence:
  Tick 1: admission_risk_agent      -> RISK_STRATIFIED
  Tick 2: document_extraction_agent -> DOCUMENT_PENDING_REVIEW
  GET /clinician/queue              -> CASE-00099999 present with flagged_count=1
  POST /cases/{id}/review approve   -> DOCUMENT_APPROVED
  Tick 3: orchestrator auto-transition -> OUTREACH_SCHEDULED
  Tick 4: outreach_agent            -> OUTREACH_COMPLETE
  reviewer_decisions row persisted, audit_log + case_events complete.

Negative checks:
  - POST /cases/{id}/review when state != DOCUMENT_PENDING_REVIEW -> 409
  - POST /cases/{unknown}/review -> 404
  - reject outcome -> ESCALATED (separate sub-scenario on a different test case)
"""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.ingest_knowledge import _load_env

_load_env()
os.environ["ORCHESTRATOR_ENABLED"] = "false"

from db.pool import configure_async_loop_policy  # noqa: E402

configure_async_loop_policy()

import httpx  # noqa: E402

from api.main import app  # noqa: E402
from api.settings import get_settings  # noqa: E402
from db.pool import connection  # noqa: E402

CASE_ID = "CASE-00099999"
ADMIN_TOKEN = get_settings().admin_token or ""
HEADERS = {"X-Admin-Token": ADMIN_TOKEN}


async def _reset_case_clean() -> None:
    async with connection() as conn:
        async with conn.transaction():
            async with conn.cursor() as cur:
                for tbl in (
                    "extracted_fields",
                    "outreach_sessions",
                    "risk_scores",
                    "reviewer_decisions",
                    "audit_log",
                    "case_events",
                ):
                    await cur.execute(f"DELETE FROM {tbl} WHERE case_id = %s", (CASE_ID,))
                await cur.execute(
                    """
                    UPDATE cases SET
                        current_state       = 'DISCHARGE_RECEIVED',
                        priority_tier       = NULL,
                        composite_priority  = NULL,
                        crm_case_record_id  = NULL,
                        agent_retry_count   = 0,
                        agent_last_error    = NULL,
                        next_eligible_at    = NULL
                      WHERE case_id = %s
                    """,
                    (CASE_ID,),
                )


def _check(label: str, ok: bool, detail: str = "") -> None:
    marker = "[OK]" if ok else "[FAIL]"
    suffix = f" -- {detail}" if detail else ""
    print(f"  {marker} {label}{suffix}")
    if not ok:
        raise AssertionError(label)


async def _state(client: httpx.AsyncClient) -> str:
    r = await client.get(f"/cases/{CASE_ID}")
    return r.json()["case"]["current_state"]


async def main() -> int:
    print("=== Step 10 reviewer endpoints + first end-to-end run ===")
    await _reset_case_clean()

    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testapi") as client:

        # ---- Pre: case is in DISCHARGE_RECEIVED ---------------------------
        _check("starting state: DISCHARGE_RECEIVED", await _state(client) == "DISCHARGE_RECEIVED")

        # ---- Negative: review before reviewable state ---------------------
        r = await client.post(
            f"/cases/{CASE_ID}/review",
            json={"reviewer_id": "test", "outcome": "approve"},
        )
        _check(
            "review while in DISCHARGE_RECEIVED -> 409",
            r.status_code == 409,
            f"status={r.status_code}",
        )

        r = await client.post(
            "/cases/CASE-NO-EXIST/review",
            json={"reviewer_id": "test", "outcome": "approve"},
        )
        _check("review on unknown case -> 404", r.status_code == 404)

        # ---- Tick 1: admission_risk_agent ---------------------------------
        await client.post("/admin/orchestrator/tick", headers=HEADERS)
        _check("after tick 1: RISK_STRATIFIED", await _state(client) == "RISK_STRATIFIED")

        # ---- Tick 2: document_extraction_agent -> DOCUMENT_PENDING_REVIEW
        await client.post("/admin/orchestrator/tick", headers=HEADERS)
        _check("after tick 2: DOCUMENT_PENDING_REVIEW",
               await _state(client) == "DOCUMENT_PENDING_REVIEW")

        # ---- Clinician queue ---------------------------------------------
        r = await client.get("/clinician/queue")
        _check("GET /clinician/queue -> 200", r.status_code == 200)
        items = r.json()
        _check(
            "queue contains CASE-00099999",
            any(it["case"]["case_id"] == CASE_ID for it in items),
            f"queue_case_ids={[it['case']['case_id'] for it in items]}",
        )
        our_item = next(it for it in items if it["case"]["case_id"] == CASE_ID)
        _check("queue item.flagged_count == 1", our_item["flagged_count"] == 1)
        _check("queue item.total_fields == 13", our_item["total_fields"] == 13)

        # ---- Review approve ----------------------------------------------
        r = await client.post(
            f"/cases/{CASE_ID}/review",
            json={
                "reviewer_id": "clinician.sarah@example.com",
                "outcome": "approve",
                "comments": "Medication taper confirmed. Authorize outreach.",
            },
        )
        _check("POST /cases/{id}/review approve -> 200", r.status_code == 200,
               f"status={r.status_code} body={r.text[:200]}")
        _check("review response: state == DOCUMENT_APPROVED",
               r.json()["current_state"] == "DOCUMENT_APPROVED")

        # reviewer_decisions row written
        async with connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT outcome, reviewer_id, expires_at FROM reviewer_decisions "
                    "WHERE case_id = %s ORDER BY decision_id DESC LIMIT 1",
                    (CASE_ID,),
                )
                row = await cur.fetchone()
        _check("reviewer_decisions row written", row is not None)
        _check("decision.outcome == 'approve'", row[0] == "approve")
        _check("decision.reviewer_id captured",
               row[1] == "clinician.sarah@example.com")
        _check("decision.expires_at is set (SLA window)", row[2] is not None)

        # ---- Tick 3: orchestrator auto-transitions DOCUMENT_APPROVED -> OUTREACH_SCHEDULED
        await client.post("/admin/orchestrator/tick", headers=HEADERS)
        _check("after tick 3: OUTREACH_SCHEDULED (auto-transition)",
               await _state(client) == "OUTREACH_SCHEDULED")

        # ---- Tick 4: outreach_agent -> OUTREACH_COMPLETE -----------------
        await client.post("/admin/orchestrator/tick", headers=HEADERS)
        _check("after tick 4: OUTREACH_COMPLETE",
               await _state(client) == "OUTREACH_COMPLETE")

        # Verify the audit trail captures the full chain
        r = await client.get(f"/cases/{CASE_ID}")
        audit = r.json()["audit_log"]
        states_visited = [a["to_state"] for a in audit]
        expected_chain = [
            "RISK_STRATIFIED",
            "DOCUMENT_PENDING_REVIEW",
            "DOCUMENT_APPROVED",
            "OUTREACH_SCHEDULED",
            "OUTREACH_COMPLETE",
        ]
        for state in expected_chain:
            _check(
                f"audit_log contains {state}",
                state in states_visited,
                f"states={states_visited}",
            )

        # case_events should contain milestones for each state in the chain
        async with connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT event_type FROM case_events WHERE case_id = %s ORDER BY event_id",
                    (CASE_ID,),
                )
                events = [r[0] for r in await cur.fetchall()]
        expected_events = {
            "state.RISK_STRATIFIED",
            "state.DOCUMENT_PENDING_REVIEW",
            "state.DOCUMENT_APPROVED",
            "state.OUTREACH_SCHEDULED",
            "state.OUTREACH_COMPLETE",
        }
        _check(
            "case_events captures every milestone",
            expected_events.issubset(events),
            f"got={events}",
        )

        # ---- Reject -> ESCALATED (on a separate temporary case row) ------
        # Use a fresh case to avoid disturbing the happy-path artifacts above.
        test_case_id = "CASE-00088888"
        async with connection() as conn:
            async with conn.transaction():
                async with conn.cursor() as cur:
                    await cur.execute(
                        "DELETE FROM audit_log WHERE case_id = %s", (test_case_id,)
                    )
                    await cur.execute(
                        "DELETE FROM reviewer_decisions WHERE case_id = %s", (test_case_id,)
                    )
                    await cur.execute(
                        "DELETE FROM cases WHERE case_id = %s", (test_case_id,)
                    )
                    await cur.execute(
                        """
                        INSERT INTO cases (case_id, member_id, current_state,
                            discharge_facility, discharge_date, primary_dx_code)
                        VALUES (%s, %s, 'DOCUMENT_PENDING_REVIEW',
                            'St. Test Center', '2026-11-15', 'J44.1')
                        """,
                        (test_case_id, "MBR-00847291"),
                    )
        r = await client.post(
            f"/cases/{test_case_id}/review",
            json={"reviewer_id": "test", "outcome": "reject", "comments": "extraction quality too low"},
        )
        _check("review reject -> 200", r.status_code == 200,
               f"status={r.status_code} body={r.text[:200]}")
        _check(
            "reject outcome -> ESCALATED",
            r.json()["current_state"] == "ESCALATED",
            f"state={r.json()['current_state']}",
        )

        # Cleanup the reject test case
        async with connection() as conn:
            async with conn.transaction():
                async with conn.cursor() as cur:
                    await cur.execute(
                        "DELETE FROM audit_log WHERE case_id = %s", (test_case_id,)
                    )
                    await cur.execute(
                        "DELETE FROM reviewer_decisions WHERE case_id = %s", (test_case_id,)
                    )
                    await cur.execute(
                        "DELETE FROM cases WHERE case_id = %s", (test_case_id,)
                    )

    print("\nAll Step 10 checks OK.")
    print("  CASE-00099999 walked DISCHARGE_RECEIVED -> OUTREACH_COMPLETE end-to-end via API.")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
