"""Smoke test the Step 4 foundation modules.

Runs the following checks:
  1. PII redaction sanity.
  2. ID minting matches the expected `<PREFIX>-NNNNNNNN` shape.
  3. structlog `case_id` binding + auto-redaction in event dicts.
  4. Bedrock chat call (Converse API) returns text.
  5. Bedrock embedding returns 1024 floats.
  6. RAG retrieval over the live `knowledge_chunks` table.

Exits non-zero on any failure.
"""

from __future__ import annotations

import asyncio
import re
import sys
from pathlib import Path

# allow `python scripts/smoke_step4_foundations.py` and `-m scripts...`
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.ingest_knowledge import _load_env  # reuse env loader

_load_env()

from db.pool import configure_async_loop_policy  # noqa: E402

configure_async_loop_policy()

from skills._common import (  # noqa: E402
    configure_logging,
    get_logger,
    mint_call_id,
    mint_case_id,
    mint_session_id,
    redact_dob,
    redact_name,
    redact_phone,
)
from skills.bedrock import embed_text, invoke_chat  # noqa: E402
from skills.knowledge import search_guidelines  # noqa: E402


def check_redaction() -> None:
    assert redact_phone("(555) 847-2910") == "(***) ***-2910"
    assert redact_name("John Martinez") == "J. M."
    assert redact_dob("1952-03-15") == "****-03-15"
    print("  [OK]redaction")


def check_id_minting() -> None:
    assert re.fullmatch(r"CASE-\d{8}", mint_case_id())
    assert re.fullmatch(r"MS-\d{8}", mint_session_id())
    assert re.fullmatch(r"CL-\d{8}", mint_call_id())
    print("  [OK]id minting")


def check_structlog_redaction() -> None:
    configure_logging()
    log = get_logger("CASE-00099999")
    # If the redactor processor works, this line emits masked phone/name in JSON.
    log.info(
        "smoke_event",
        phone="(555) 847-2910",
        first_name="John",
        last_name="Martinez",
        dob="1952-03-15",
    )
    print("  [OK]structlog auto-redaction (inspect output above; phone/name/dob should be masked)")


def check_bedrock_chat() -> None:
    out = invoke_chat(
        case_id="CASE-00099999",
        system="You are a terse assistant. Reply with exactly one word.",
        messages=[{"role": "user", "content": "Say the word PONG."}],
        max_tokens=8,
        temperature=0.0,
    )
    assert "pong" in out.lower(), f"unexpected response: {out!r}"
    print(f"  [OK]bedrock chat (response={out.strip()!r})")


def check_bedrock_embed() -> None:
    vec = embed_text(case_id="CASE-00099999", text="post-discharge COPD follow-up")
    assert len(vec) == 1024
    print(f"  [OK]bedrock embed (dims={len(vec)})")


async def check_rag() -> None:
    hits = await search_guidelines(
        case_id="CASE-00099999",
        query="When should the PCP follow-up be scheduled after a COPD discharge?",
        k=3,
    )
    assert hits, "no hits returned"
    top = hits[0]
    assert top.similarity > 0.5, f"top similarity unexpectedly low: {top.similarity}"
    print(
        f"  [OK]rag retrieval (top: {top.source_doc} :: {top.section_title} "
        f"@ sim={top.similarity:.3f})"
    )


async def main() -> int:
    print("=== Step 4 foundations smoke test ===")
    try:
        check_redaction()
        check_id_minting()
        check_structlog_redaction()
        check_bedrock_chat()
        check_bedrock_embed()
        await check_rag()
    except AssertionError as e:
        print(f"FAILED: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"ERROR: {type(e).__name__}: {e}", file=sys.stderr)
        return 2
    print("\nAll foundations OK.")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
