"""Step 8 smoke — document_extraction_agent.

Walks CASE-00099999 from DISCHARGE_RECEIVED through two orchestrator ticks:
  Tick 1: admission_risk_agent     -> RISK_STRATIFIED
  Tick 2: document_extraction_agent -> DOCUMENT_PENDING_REVIEW

Then queries the new GET /cases/{id}/extraction endpoint and verifies the
13-field John Martinez extraction (1 flagged: medication_changes at 0.72)
is surfaced correctly, along with the denormalized case.extraction_flags
+ case.is_stp populated by the agent.

The smoke runs with `BEDROCK_MODEL_ID` resolution in the loop; when Bedrock
is unreachable the agent transparently falls back to the deterministic
mock extractor, so this smoke is driveable offline.
"""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.ingest_knowledge import _load_env

_load_env()
os.environ["ORCHESTRATOR_ENABLED"] = "false"

from db.pool import configure_async_loop_policy  # noqa: E402

configure_async_loop_policy()

import httpx  # noqa: E402

from api.main import app  # noqa: E402
from api.settings import get_settings  # noqa: E402
from db.pool import connection  # noqa: E402

CASE_ID = "CASE-00099999"
ADMIN_TOKEN = get_settings().admin_token or ""


async def _reset_case_clean() -> None:
    async with connection() as conn:
        async with conn.transaction():
            async with conn.cursor() as cur:
                await cur.execute("DELETE FROM extracted_fields WHERE case_id = %s", (CASE_ID,))
                await cur.execute("DELETE FROM risk_scores WHERE case_id = %s", (CASE_ID,))
                await cur.execute("DELETE FROM audit_log WHERE case_id = %s", (CASE_ID,))
                await cur.execute("DELETE FROM case_events WHERE case_id = %s", (CASE_ID,))
                await cur.execute(
                    """
                    UPDATE cases SET
                        current_state       = 'DISCHARGE_RECEIVED',
                        priority_tier       = NULL,
                        composite_priority  = NULL,
                        crm_case_record_id  = NULL,
                        agent_retry_count   = 0,
                        agent_last_error    = NULL,
                        next_eligible_at    = NULL,
                        extraction_flags    = NULL,
                        is_stp              = FALSE
                      WHERE case_id = %s
                    """,
                    (CASE_ID,),
                )


def _check(label: str, ok: bool, detail: str = "") -> None:
    marker = "[OK]" if ok else "[FAIL]"
    suffix = f" -- {detail}" if detail else ""
    print(f"  {marker} {label}{suffix}")
    if not ok:
        raise AssertionError(label)


async def main() -> int:
    print("=== Step 8 document_extraction_agent smoke ===")
    await _reset_case_clean()

    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testapi") as client:

        # Tick 1: admission_risk_agent
        r = await client.post(
            "/admin/orchestrator/tick",
            headers={"X-Admin-Token": ADMIN_TOKEN},
        )
        _check("tick 1 -> 200", r.status_code == 200, f"body={r.text[:200]}")

        r = await client.get(f"/cases/{CASE_ID}")
        view = r.json()
        _check(
            "after tick 1: state == RISK_STRATIFIED",
            view["case"]["current_state"] == "RISK_STRATIFIED",
            f"state={view['case']['current_state']}",
        )

        # Tick 2: document_extraction_agent
        r = await client.post(
            "/admin/orchestrator/tick",
            headers={"X-Admin-Token": ADMIN_TOKEN},
        )
        _check("tick 2 -> 200", r.status_code == 200)

        r = await client.get(f"/cases/{CASE_ID}")
        view = r.json()
        _check(
            "after tick 2: state == DOCUMENT_PENDING_REVIEW",
            view["case"]["current_state"] == "DOCUMENT_PENDING_REVIEW",
            f"state={view['case']['current_state']}",
        )
        _check(
            "CaseView shows 13 extracted fields",
            len(view["extracted_fields"]) == 13,
            f"count={len(view['extracted_fields'])}",
        )

        # Focused extraction endpoint
        r = await client.get(f"/cases/{CASE_ID}/extraction")
        ext = r.json()
        _check("GET /cases/{id}/extraction -> 200", r.status_code == 200)
        _check("extraction.total_fields == 13", ext["total_fields"] == 13)
        _check("extraction.flagged_count == 1", ext["flagged_count"] == 1)
        _check(
            "extraction.flagged_field_names == ['medication_changes']",
            ext["flagged_field_names"] == ["medication_changes"],
            f"got={ext['flagged_field_names']}",
        )
        _check(
            "extraction.ready_for_review == True",
            ext["ready_for_review"] is True,
        )

        flagged_field = next(f for f in ext["fields"] if f["flagged"])
        _check(
            "medication_changes confidence < 0.80 (flag threshold)",
            float(flagged_field["confidence"]) < 0.80,
            f"confidence={flagged_field['confidence']}",
        )

        # The denormalized columns the agent writes alongside the field rows.
        case_view = view["case"]
        _check(
            "case.extraction_flags has 1 entry (medication_changes)",
            isinstance(case_view.get("extraction_flags"), list)
            and len(case_view["extraction_flags"]) == 1
            and case_view["extraction_flags"][0]["field"] == "medication_changes",
            f"flags={case_view.get('extraction_flags')}",
        )
        _check(
            "case.is_stp == False (business rule placeholder)",
            case_view.get("is_stp") is False,
            f"is_stp={case_view.get('is_stp')}",
        )

        # case_events should now contain the DOCUMENT_PENDING_REVIEW milestone.
        async with connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT event_type FROM case_events WHERE case_id = %s ORDER BY event_id",
                    (CASE_ID,),
                )
                events = [r[0] for r in await cur.fetchall()]
        _check(
            "case_events contains state.RISK_STRATIFIED and state.DOCUMENT_PENDING_REVIEW",
            "state.RISK_STRATIFIED" in events and "state.DOCUMENT_PENDING_REVIEW" in events,
            f"events={events}",
        )

        # audit_log should have two state transitions (admission_risk + document_extraction)
        audit = view["audit_log"]
        risk_to = [a for a in audit if a["to_state"] == "RISK_STRATIFIED"]
        doc_to = [a for a in audit if a["to_state"] == "DOCUMENT_PENDING_REVIEW"]
        _check("audit_log has 1 RISK_STRATIFIED transition", len(risk_to) == 1)
        _check("audit_log has 1 DOCUMENT_PENDING_REVIEW transition", len(doc_to) == 1)

        # Idempotency: third tick should be a no-op (DOCUMENT_PENDING_REVIEW
        # has no registered agent and no auto-transition).
        async with connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "UPDATE cases SET next_eligible_at = NULL WHERE case_id = %s",
                    (CASE_ID,),
                )
        r = await client.post(
            "/admin/orchestrator/tick",
            headers={"X-Admin-Token": ADMIN_TOKEN},
        )
        body = r.json()
        _check(
            "tick 3: DOCUMENT_PENDING_REVIEW is not dispatchable (no claim)",
            CASE_ID not in body.get("case_ids", []),
            f"case_ids={body.get('case_ids')}",
        )

        # Verify nothing duplicated
        async with connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT count(*) FROM extracted_fields WHERE case_id = %s",
                    (CASE_ID,),
                )
                field_count = (await cur.fetchone())[0]
        _check("still exactly 13 extracted_fields rows", field_count == 13)

    print("\nAll Step 8 checks OK.")
    print(f"  CASE-00099999 is in DOCUMENT_PENDING_REVIEW (awaiting clinician gate, Step 10).")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
