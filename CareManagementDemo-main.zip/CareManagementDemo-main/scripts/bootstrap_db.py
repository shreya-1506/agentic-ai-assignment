"""Apply db/schema.sql to the configured Postgres database.

Usage (from project root, with `hh` venv activated):

    python -m scripts.bootstrap_db

Reads DATABASE_URL from `.env` (loaded by python-dotenv if available, else from
the environment). Idempotent: every statement in schema.sql is safe to re-run.

Exits non-zero on failure so it can be wired into CI later.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import psycopg

PROJECT_ROOT = Path(__file__).resolve().parent.parent
SCHEMA_PATH = PROJECT_ROOT / "db" / "schema.sql"


def _load_env() -> None:
    """Read .env into os.environ if present. Avoids a hard dotenv dependency."""
    env_path = PROJECT_ROOT / ".env"
    if not env_path.exists():
        return
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if not value:
            continue
        os.environ.setdefault(key, value)


def main() -> int:
    _load_env()

    url = os.environ.get("DATABASE_URL")
    if not url:
        print("ERROR: DATABASE_URL is not set. Copy .env.example to .env first.", file=sys.stderr)
        return 2

    if not SCHEMA_PATH.exists():
        print(f"ERROR: schema file missing at {SCHEMA_PATH}", file=sys.stderr)
        return 2

    sql = SCHEMA_PATH.read_text(encoding="utf-8")

    print(f"Connecting to: {_redact(url)}")
    try:
        with psycopg.connect(url, autocommit=True) as conn:
            with conn.cursor() as cur:
                cur.execute(sql)
            print("OK: schema applied.")
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT table_name
                      FROM information_schema.tables
                     WHERE table_schema = 'public'
                     ORDER BY table_name
                    """
                )
                tables = [r[0] for r in cur.fetchall()]
            print(f"Tables in 'public': {tables}")
    except psycopg.errors.FeatureNotSupported as e:
        print(f"ERROR: feature not supported (pgvector missing?): {e}", file=sys.stderr)
        return 3
    except psycopg.OperationalError as e:
        print(f"ERROR: connection/operational failure: {e}", file=sys.stderr)
        return 4
    except Exception as e:  # surface anything unexpected with a clear exit code
        print(f"ERROR: bootstrap failed: {type(e).__name__}: {e}", file=sys.stderr)
        return 1
    return 0


def _redact(url: str) -> str:
    """Hide the password in URLs for safer log output."""
    try:
        scheme, rest = url.split("://", 1)
        if "@" not in rest:
            return url
        creds, host = rest.split("@", 1)
        if ":" not in creds:
            return f"{scheme}://{creds}@{host}"
        user, _ = creds.split(":", 1)
        return f"{scheme}://{user}:***@{host}"
    except Exception:
        return "<unparseable>"


if __name__ == "__main__":
    raise SystemExit(main())
