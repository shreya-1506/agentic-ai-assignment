"""Step 9 smoke - outreach_agent stub.

Test bypasses Step 10's human gate by forcing CASE-00099999 directly to
OUTREACH_SCHEDULED via raw SQL. (Step 10 will replace this with a real
reviewer endpoint.) One orchestrator tick should:
  - dispatch outreach_agent
  - open a messaging session, exchange 7 outbound + 7 inbound canned turns
  - issue one RAG query
  - build a populated SurveyForm with cmp_enrollment=True and
    pcp_followup_scheduled=False
  - emit sdoh_flags=['no_pcp_appt']
  - persist outreach_session row
  - transition OUTREACH_SCHEDULED -> OUTREACH_COMPLETE
"""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.ingest_knowledge import _load_env

_load_env()
os.environ["ORCHESTRATOR_ENABLED"] = "false"

from db.pool import configure_async_loop_policy  # noqa: E402

configure_async_loop_policy()

import httpx  # noqa: E402

from api.main import app  # noqa: E402
from api.settings import get_settings  # noqa: E402
from db.pool import connection  # noqa: E402

CASE_ID = "CASE-00099999"
ADMIN_TOKEN = get_settings().admin_token or ""


async def _force_state_outreach_scheduled() -> None:
    """Test-only bypass of the human gate. Step 10 replaces this with /review."""
    async with connection() as conn:
        async with conn.transaction():
            async with conn.cursor() as cur:
                await cur.execute(
                    "DELETE FROM outreach_sessions WHERE case_id = %s", (CASE_ID,)
                )
                await cur.execute("DELETE FROM audit_log WHERE case_id = %s", (CASE_ID,))
                await cur.execute("DELETE FROM case_events WHERE case_id = %s", (CASE_ID,))
                await cur.execute(
                    """
                    UPDATE cases SET
                        current_state     = 'OUTREACH_SCHEDULED',
                        agent_retry_count = 0,
                        agent_last_error  = NULL,
                        next_eligible_at  = NULL
                      WHERE case_id = %s
                    """,
                    (CASE_ID,),
                )


def _check(label: str, ok: bool, detail: str = "") -> None:
    marker = "[OK]" if ok else "[FAIL]"
    suffix = f" -- {detail}" if detail else ""
    print(f"  {marker} {label}{suffix}")
    if not ok:
        raise AssertionError(label)


async def main() -> int:
    print("=== Step 9 outreach_agent smoke ===")
    await _force_state_outreach_scheduled()

    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testapi") as client:

        r = await client.post(
            "/admin/orchestrator/tick",
            headers={"X-Admin-Token": ADMIN_TOKEN},
        )
        _check("tick -> 200", r.status_code == 200)
        body = r.json()
        _check("tick claimed CASE-00099999", CASE_ID in body.get("case_ids", []))

        r = await client.get(f"/cases/{CASE_ID}")
        view = r.json()
        _check(
            "state advanced to OUTREACH_COMPLETE",
            view["case"]["current_state"] == "OUTREACH_COMPLETE",
            f"state={view['case']['current_state']}",
        )

        r = await client.get(f"/cases/{CASE_ID}/outreach")
        _check("GET /cases/{id}/outreach -> 200", r.status_code == 200)
        outreach = r.json()
        _check("session_id format MS-NNNNNNNN", outreach["session_id"].startswith("MS-"))
        _check("channel == messaging", outreach["channel"] == "messaging")
        _check("status == complete", outreach["status"] == "complete")
        _check(
            "transcript has 14 turns (7 outbound + 7 inbound)",
            len(outreach["transcript"]) == 14,
            f"got {len(outreach['transcript'])}",
        )
        # Spot-check that the first inbound is the canned 'Speaking.' reply.
        first_member_turn = next(t for t in outreach["transcript"] if t["role"] == "member")
        _check(
            "first member reply == 'Speaking.'",
            first_member_turn["text"] == "Speaking.",
            f"got={first_member_turn['text']!r}",
        )

        survey = outreach["survey"]
        _check("survey.symptoms == 'Mild dyspnea, morning SOB'",
               survey["symptoms"] == "Mild dyspnea, morning SOB")
        _check("survey.medication_pickup == True", survey["medication_pickup"] is True)
        _check("survey.pcp_followup_scheduled == False",
               survey["pcp_followup_scheduled"] is False)
        _check("survey.cmp_enrollment == True", survey["cmp_enrollment"] is True)
        _check("survey.contact_phone == '+15558472910'",
               survey["contact_phone"] == "+15558472910")

        _check(
            "sdoh_flags == ['no_pcp_appt']",
            outreach["sdoh_flags"] == ["no_pcp_appt"],
            f"got={outreach['sdoh_flags']}",
        )

        # Confirm a milestone landed in case_events.
        async with connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT event_type FROM case_events WHERE case_id = %s ORDER BY event_id",
                    (CASE_ID,),
                )
                events = [r[0] for r in await cur.fetchall()]
        _check(
            "case_events contains state.OUTREACH_COMPLETE",
            "state.OUTREACH_COMPLETE" in events,
            f"events={events}",
        )

        # Idempotent re-tick: OUTREACH_COMPLETE is not in DISPATCHABLE_STATES,
        # so the orchestrator returns claimed=0 and no duplicate session is written.
        async with connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "UPDATE cases SET next_eligible_at = NULL WHERE case_id = %s",
                    (CASE_ID,),
                )
        r = await client.post(
            "/admin/orchestrator/tick",
            headers={"X-Admin-Token": ADMIN_TOKEN},
        )
        body = r.json()
        _check(
            "re-tick: OUTREACH_COMPLETE not dispatchable",
            CASE_ID not in body.get("case_ids", []),
            f"case_ids={body.get('case_ids')}",
        )

        async with connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT count(*) FROM outreach_sessions WHERE case_id = %s",
                    (CASE_ID,),
                )
                session_count = (await cur.fetchone())[0]
        _check("still exactly 1 outreach_session row", session_count == 1)

    print("\nAll Step 9 checks OK.")
    print(f"  CASE-00099999 is in OUTREACH_COMPLETE (awaiting CM callback start, Step 11).")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
