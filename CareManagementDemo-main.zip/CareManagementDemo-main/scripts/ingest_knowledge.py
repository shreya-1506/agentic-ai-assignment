"""Ingest knowledge/tcm_guidelines/*.md into the `knowledge_chunks` table.

Chunking strategy: **heading-aware**. Each `## ` section becomes one chunk;
the preamble (between the `# ` title and the first `## `) becomes a chunk
titled after the doc.

Idempotency: **content hash dedup**. Each chunk carries a SHA-256 over
`source_doc | chunk_text` in `chunk_metadata.content_hash`. On re-run:
  - chunks whose hash is already present  → skipped (no Bedrock call)
  - chunks whose hash is new              → embedded via Titan v2 + inserted
  - existing chunks not in the current docs → deleted (so edits propagate)

Usage:

    python -m scripts.ingest_knowledge            # full ingest
    python -m scripts.ingest_knowledge --dry-run  # plan only, no DB writes
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path

import boto3
import psycopg
from pgvector.psycopg import register_vector
from psycopg.types.json import Jsonb

PROJECT_ROOT = Path(__file__).resolve().parent.parent
KNOWLEDGE_DIR = PROJECT_ROOT / "knowledge" / "tcm_guidelines"


# ---- env loader (mirrors scripts/bootstrap_db.py) ---------------------------


def _load_env() -> None:
    env_path = PROJECT_ROOT / ".env"
    if not env_path.exists():
        return
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        value = value.strip().strip('"').strip("'")
        # Skip empty placeholder values — never clobber an already-set OS env,
        # and never override a real value with a blank one (matters for AWS creds).
        if not value:
            continue
        os.environ.setdefault(key.strip(), value)


# ---- chunking ---------------------------------------------------------------


@dataclass(frozen=True)
class Chunk:
    source_doc: str
    section_title: str
    text: str
    content_hash: str


_TITLE_RE = re.compile(r"(?m)^# (.+)$")
_SPLIT_RE = re.compile(r"(?m)^## ")


def chunk_markdown(source_doc: str, text: str) -> list[Chunk]:
    """Split a markdown doc into heading-aware chunks."""
    parts = _SPLIT_RE.split(text)
    preamble = parts[0].rstrip()

    chunks: list[Chunk] = []

    title_match = _TITLE_RE.search(preamble)
    doc_title = title_match.group(1).strip() if title_match else source_doc

    if preamble.strip():
        chunks.append(_make_chunk(source_doc, doc_title, preamble))

    for part in parts[1:]:
        first_line, _, body = part.partition("\n")
        section_title = first_line.strip()
        section_text = f"## {section_title}\n\n{body.strip()}"
        chunks.append(_make_chunk(source_doc, section_title, section_text))

    return chunks


def _make_chunk(source_doc: str, section_title: str, text: str) -> Chunk:
    h = hashlib.sha256(f"{source_doc}|{text}".encode("utf-8")).hexdigest()
    return Chunk(
        source_doc=source_doc,
        section_title=section_title,
        text=text,
        content_hash=h,
    )


# ---- Bedrock Titan v2 embedding --------------------------------------------


class BedrockEmbedder:
    def __init__(self) -> None:
        region = (
            os.environ.get("BEDROCK_REGION")
            or os.environ.get("AWS_REGION")
            or os.environ.get("AWS_DEFAULT_REGION")
            or "us-east-1"
        )
        self.model_id = os.environ.get(
            "BEDROCK_EMBEDDING_MODEL_ID", "amazon.titan-embed-text-v2:0"
        )
        self.dims = int(os.environ.get("BEDROCK_EMBEDDING_DIMENSIONS", "1024"))
        self.client = boto3.client("bedrock-runtime", region_name=region)

    def embed(self, text: str) -> list[float]:
        response = self.client.invoke_model(
            modelId=self.model_id,
            body=json.dumps({"inputText": text, "dimensions": self.dims, "normalize": True}),
            contentType="application/json",
            accept="application/json",
        )
        payload = json.loads(response["body"].read())
        embedding = payload["embedding"]
        if len(embedding) != self.dims:
            raise RuntimeError(
                f"unexpected embedding dim: got {len(embedding)} expected {self.dims}"
            )
        return embedding


# ---- DB helpers -------------------------------------------------------------


def fetch_existing_hashes(conn: psycopg.Connection) -> dict[tuple[str, str], int]:
    """Map (source_doc, content_hash) -> chunk_id for chunks already in the DB."""
    out: dict[tuple[str, str], int] = {}
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT chunk_id, source_doc, chunk_metadata->>'content_hash' AS h
              FROM knowledge_chunks
             WHERE chunk_metadata ? 'content_hash'
            """
        )
        for chunk_id, source_doc, h in cur.fetchall():
            if h is None:
                continue
            out[(source_doc, h)] = chunk_id
    return out


def delete_chunks(conn: psycopg.Connection, chunk_ids: list[int]) -> None:
    if not chunk_ids:
        return
    with conn.cursor() as cur:
        cur.execute(
            "DELETE FROM knowledge_chunks WHERE chunk_id = ANY(%s)",
            (chunk_ids,),
        )


def insert_chunk(
    conn: psycopg.Connection, chunk: Chunk, embedding: list[float]
) -> None:
    metadata = {"section_title": chunk.section_title, "content_hash": chunk.content_hash}
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO knowledge_chunks (source_doc, chunk_text, embedding, chunk_metadata)
            VALUES (%s, %s, %s, %s)
            """,
            (chunk.source_doc, chunk.text, embedding, Jsonb(metadata)),
        )


# ---- driver -----------------------------------------------------------------


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true", help="plan only; no DB writes")
    args = parser.parse_args(argv)

    _load_env()

    url = os.environ.get("DATABASE_URL")
    if not url:
        print("ERROR: DATABASE_URL is not set. Copy .env.example to .env first.", file=sys.stderr)
        return 2

    if not KNOWLEDGE_DIR.exists():
        print(f"ERROR: knowledge dir missing: {KNOWLEDGE_DIR}", file=sys.stderr)
        return 2

    md_files = sorted(KNOWLEDGE_DIR.glob("*.md"))
    if not md_files:
        print(f"ERROR: no .md files in {KNOWLEDGE_DIR}", file=sys.stderr)
        return 2

    print(f"Scanning {len(md_files)} markdown files in {KNOWLEDGE_DIR}")
    current: list[Chunk] = []
    per_doc_counts: dict[str, int] = {}
    for md in md_files:
        chunks = chunk_markdown(md.name, md.read_text(encoding="utf-8"))
        current.extend(chunks)
        per_doc_counts[md.name] = len(chunks)
        print(f"  {md.name}: {len(chunks)} chunks")

    with psycopg.connect(url, autocommit=False) as conn:
        register_vector(conn)
        existing = fetch_existing_hashes(conn)

        current_keys = {(c.source_doc, c.content_hash) for c in current}
        to_insert = [c for c in current if (c.source_doc, c.content_hash) not in existing]
        to_delete_ids = [
            cid for (sd, h), cid in existing.items() if (sd, h) not in current_keys
        ]

        unchanged = len(current) - len(to_insert)
        print(
            f"\nDiff vs DB: insert={len(to_insert)}  unchanged={unchanged}  delete={len(to_delete_ids)}"
        )

        if args.dry_run:
            print("\n[dry-run] no writes performed.")
            return 0

        if to_insert:
            embedder = BedrockEmbedder()
            print(f"\nEmbedding {len(to_insert)} chunk(s) via Titan v2 ({embedder.model_id}) ...")
        else:
            embedder = None
            print("\nNothing to embed.")

        for i, chunk in enumerate(to_insert, start=1):
            try:
                assert embedder is not None
                vec = embedder.embed(chunk.text)
                insert_chunk(conn, chunk, vec)
                print(f"  [{i}/{len(to_insert)}] {chunk.source_doc} :: {chunk.section_title}")
            except Exception as exc:  # one bad chunk shouldn't kill the run
                print(
                    f"  [{i}/{len(to_insert)}] FAILED {chunk.source_doc} :: "
                    f"{chunk.section_title} -- {type(exc).__name__}: {exc}",
                    file=sys.stderr,
                )
                conn.rollback()
                return 5

        if to_delete_ids:
            delete_chunks(conn, to_delete_ids)
            print(f"\nDeleted {len(to_delete_ids)} orphaned chunk row(s).")

        conn.commit()

        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM knowledge_chunks")
            total = cur.fetchone()[0]
        print(f"\nDone. knowledge_chunks now contains {total} row(s).")

    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
