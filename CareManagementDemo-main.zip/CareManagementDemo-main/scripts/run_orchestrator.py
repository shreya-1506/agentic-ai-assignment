"""Standalone runner for the orchestrator polling loop.

Use this before the FastAPI surface lands (Step 7) — once that's wired,
the orchestrator runs as a lifespan-managed daemon inside the same uvicorn
process and this script is redundant.

Usage:
    python -m scripts.run_orchestrator                 # poll forever
    python -m scripts.run_orchestrator --max-ticks 5   # one-shot
"""

from __future__ import annotations

import argparse
import asyncio
import signal
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.ingest_knowledge import _load_env

_load_env()

from db.pool import close_pool, configure_async_loop_policy  # noqa: E402

configure_async_loop_policy()

import agents  # noqa: E402,F401  # triggers _registry side-effects
from agents.orchestration_agent import run  # noqa: E402


async def _main(max_ticks: int | None, poll: int | None) -> int:
    stop_event = asyncio.Event()

    def _stop(*_args):  # SIGINT / SIGTERM handler
        stop_event.set()

    try:
        loop = asyncio.get_running_loop()
        for sig_name in ("SIGINT", "SIGTERM"):
            if hasattr(signal, sig_name):
                try:
                    loop.add_signal_handler(getattr(signal, sig_name), _stop)
                except NotImplementedError:
                    # Windows asyncio doesn't support add_signal_handler — ignore.
                    pass
    except RuntimeError:
        pass

    try:
        await run(
            poll_interval_s=poll,
            max_ticks=max_ticks,
            stop_event=stop_event,
        )
    finally:
        await close_pool()
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-ticks", type=int, default=None, help="Run N ticks then exit")
    parser.add_argument("--poll", type=int, default=None, help="Poll interval in seconds")
    args = parser.parse_args()
    return asyncio.run(_main(args.max_ticks, args.poll))


if __name__ == "__main__":
    raise SystemExit(main())
