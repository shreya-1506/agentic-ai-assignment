"""Step 7 smoke — FastAPI app with lifespan-hosted orchestrator daemon.

Drives the API via `httpx.AsyncClient` against the live app's ASGI surface.
Lifespan starts the orchestrator daemon; we disable its background polling
(via env var) so the admin tick endpoint is the only thing that moves cases.

Checks:
  1. GET /                 -> meta envelope
  2. GET /health           -> ok, db ok, bedrock creds present
  3. GET /cases?state=DISCHARGE_RECEIVED -> CASE-00099999 present after reset
  4. POST /admin/orchestrator/tick (auth)  -> claims and advances CASE-00099999
  5. GET /cases/{id}       -> state RISK_STRATIFIED, risk_scores populated, audit_log present
  6. POST /admin without admin token -> 401
  7. POST /cases/intake (new member)  -> 201
  8. POST /cases/intake (same dedup key) -> 409
"""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.ingest_knowledge import _load_env

_load_env()

# Disable the background daemon for deterministic admin-tick driven testing.
os.environ["ORCHESTRATOR_ENABLED"] = "false"

from db.pool import configure_async_loop_policy  # noqa: E402

configure_async_loop_policy()

import httpx  # noqa: E402

from api.main import app  # noqa: E402  imports trigger lifespan setup on first use
from api.settings import get_settings  # noqa: E402
from db.pool import connection  # noqa: E402

CASE_ID = "CASE-00099999"
ADMIN_TOKEN = get_settings().admin_token or ""


async def _reset_case_clean() -> None:
    """Park CASE-00099999 back in DISCHARGE_RECEIVED with no downstream artifacts."""
    async with connection() as conn:
        async with conn.transaction():
            async with conn.cursor() as cur:
                await cur.execute("DELETE FROM risk_scores WHERE case_id = %s", (CASE_ID,))
                await cur.execute("DELETE FROM audit_log WHERE case_id = %s", (CASE_ID,))
                await cur.execute("DELETE FROM case_events WHERE case_id = %s", (CASE_ID,))
                await cur.execute(
                    """
                    UPDATE cases SET
                        current_state       = 'DISCHARGE_RECEIVED',
                        priority_tier       = NULL,
                        composite_priority  = NULL,
                        crm_case_record_id  = NULL,
                        agent_retry_count   = 0,
                        agent_last_error    = NULL,
                        next_eligible_at    = NULL
                      WHERE case_id = %s
                    """,
                    (CASE_ID,),
                )


async def _cleanup_intake_test_case(member_id: str) -> None:
    """Drop any test case we created for the intake check (so re-runs are clean)."""
    async with connection() as conn:
        async with conn.transaction():
            async with conn.cursor() as cur:
                await cur.execute("DELETE FROM cases WHERE member_id = %s", (member_id,))
                await cur.execute("DELETE FROM members WHERE member_id = %s", (member_id,))


def _check(label: str, ok: bool, detail: str = "") -> None:
    marker = "[OK]" if ok else "[FAIL]"
    suffix = f" -- {detail}" if detail else ""
    print(f"  {marker} {label}{suffix}")
    if not ok:
        raise AssertionError(label)


async def main() -> int:
    print("=== Step 7 API smoke ===")
    print(f"  ORCHESTRATOR_ENABLED={os.environ['ORCHESTRATOR_ENABLED']}")
    print(f"  ADMIN_TOKEN set: {bool(ADMIN_TOKEN)}")

    await _reset_case_clean()

    # Seed a fresh test member for the intake-success test so we don't
    # collide with John Martinez's dedup key (MBR-00847291 / 2026-10-05).
    test_member_id = "MBR-99000001"
    await _cleanup_intake_test_case(test_member_id)
    async with connection() as conn:
        async with conn.transaction():
            async with conn.cursor() as cur:
                await cur.execute(
                    """
                    INSERT INTO members (member_id, first_name, last_name, dob, phone, plan_name)
                    VALUES (%s, 'Ada', 'Lovelace', '1815-12-10', '(555) 000-0001', 'BlueCross Premier')
                    """,
                    (test_member_id,),
                )

    transport = httpx.ASGITransport(app=app)  # uses the FastAPI lifespan
    async with httpx.AsyncClient(transport=transport, base_url="http://testapi") as client:

        r = await client.get("/")
        _check("GET / -> 200", r.status_code == 200, f"status={r.status_code}")

        r = await client.get("/health")
        body = r.json()
        _check("GET /health -> 200", r.status_code == 200)
        _check("health.db.ok == True", body["db"]["ok"] is True, f"body={body}")
        _check("health.bedrock.credentials_present == True", body["bedrock"]["credentials_present"] is True)

        r = await client.get("/cases", params={"state": "DISCHARGE_RECEIVED"})
        cases = r.json()
        _check("GET /cases?state=DISCHARGE_RECEIVED -> 200", r.status_code == 200)
        _check(
            "CASE-00099999 present in DISCHARGE_RECEIVED listing",
            any(c["case_id"] == CASE_ID for c in cases),
            f"got case_ids={[c['case_id'] for c in cases]}",
        )

        # Admin tick without token -> 401
        r = await client.post("/admin/orchestrator/tick")
        _check(
            "POST /admin/orchestrator/tick without token -> 401",
            r.status_code == 401,
            f"status={r.status_code} body={r.text[:200]}",
        )

        # Admin tick with token -> claims CASE-00099999 and advances state
        r = await client.post(
            "/admin/orchestrator/tick",
            headers={"X-Admin-Token": ADMIN_TOKEN},
            params={"limit": 5},
        )
        body = r.json()
        _check("POST /admin/orchestrator/tick (auth) -> 200", r.status_code == 200, f"body={body}")
        _check(
            "tick claimed CASE-00099999",
            CASE_ID in body.get("case_ids", []),
            f"case_ids={body.get('case_ids')}",
        )

        r = await client.get(f"/cases/{CASE_ID}")
        view = r.json()
        _check("GET /cases/{id} -> 200", r.status_code == 200)
        _check(
            "case advanced to RISK_STRATIFIED",
            view["case"]["current_state"] == "RISK_STRATIFIED",
            f"state={view['case']['current_state']}",
        )
        _check("risk_scores populated", view["risk_scores"] is not None)
        _check(
            "risk_scores composite_priority == 73",
            view["risk_scores"]["composite_priority"] == 73,
        )
        _check("audit_log has transition rows", len(view["audit_log"]) >= 1)

        # 404 on unknown case
        r = await client.get("/cases/CASE-99999999")
        _check("GET /cases/{unknown} -> 404", r.status_code == 404)

        # Intake — new case (fresh member, distinct dedup key)
        intake_payload = {
            "member_id": test_member_id,
            "facility": "St. Mary's Medical Center",
            "admit_date": "2026-11-01",
            "discharge_date": "2026-11-03",
            "length_of_stay_days": 2,
            "primary_dx_code": "J44.1",
            "primary_dx_description": "COPD with acute exacerbation",
            "attending_physician": "Dr. Patel",
            "pcp_name": "Dr. Garcia",
            "plan_name": "BlueCross Premier",
        }
        r = await client.post("/cases/intake", json=intake_payload)
        _check("POST /cases/intake -> 201", r.status_code == 201, f"status={r.status_code} body={r.text[:200]}")
        new_case = r.json()
        new_case_id = new_case["case_id"]
        _check("new case minted CASE-NNNNNNNN", new_case_id.startswith("CASE-"))
        _check("new case in DISCHARGE_RECEIVED", new_case["current_state"] == "DISCHARGE_RECEIVED")

        # Intake — same dedup key should 409
        r = await client.post("/cases/intake", json=intake_payload)
        _check("POST /cases/intake (duplicate) -> 409", r.status_code == 409)
        body = r.json()
        _check(
            "409 names the existing case_id",
            body["detail"].get("existing_case_id") == new_case_id,
            f"body={body}",
        )

    # Cleanup the test case we created (so re-runs of this smoke are idempotent).
    await _cleanup_intake_test_case(test_member_id)

    print("\nAll Step 7 API checks OK.")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
