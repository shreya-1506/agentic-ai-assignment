# Skills — Canonical Tool Contracts

> Single source of truth for deterministic tools in [skills/](skills/). **Update this file before changing skill code.** Every public function listed here has a 1:1 implementation.

## Rules

- Skills are **deterministic**. No LLM calls inside skill modules — except [skills.bedrock](skills/bedrock.py), which IS the LLM wrapper and is treated as shared infrastructure (like [skills._common](skills/_common.py)).
- Typed I/O via Pydantic v2 models from [models/schemas.py](models/schemas.py).
- Typed exceptions are `SkillError` subclasses from [models/exceptions.py](models/exceptions.py) (`CaseNotFound`, `InvalidStateTransition`, `DuplicateCase`, `DocumentNotFound`, `LowConfidenceField`, `HumanGateNotPassed`, `ReviewerDecisionExpired`, `ConsentNotCaptured`, `MockUnavailable`, `BedrockError`, `ExternalServiceError`).
- **Every public tool accepts `case_id: str` as the first positional arg** and binds it on every structlog line via `skills._common.get_logger(case_id)`.
- PII (names, DOB, MRN, phone, email) is **masked in logs** by the structlog redactor processor in `skills._common` — emit raw values into logs without manual scrubbing and the processor handles known PII keys.
- **No cross-skill imports** of business logic. Allowed imports inside a skill module: `models`, `db`, `skills._common`, `skills._fixtures`, `skills.bedrock`, `skills.templates`. Anything else is a violation.
- Every mocked external integration carries a `# MOCK:` comment naming the real system + a `TODO:` line.

## Shared infrastructure

### `skills._common`
- `get_logger(case_id, **bind) → BoundLogger` — `case_id`-bound logger with the redactor processor pre-installed.
- `configure_logging()` — one-time structlog setup (called automatically by `get_logger`).
- `redact_phone(phone) → str`, `redact_name(name)`, `redact_dob(dob)`, `redact_mrn(mrn)`, `redact_email(email)`, `redact_pii(value, key=None)` — explicit redactors when a caller needs the masked value (not for logging — the processor handles that).
- `mint_case_id() → str` (`CASE-NNNNNNNN`), `mint_session_id() → str` (`MS-NNNNNNNN`), `mint_call_id() → str` (`CL-NNNNNNNN`), `mint_member_id() → str` (`MBR-NNNNNNNN`), `mint_crm_id() → str` (`CRM-NNNNNNNN`), `mint_task_id() → str` (`TASK-NNNNNNNN`).

### `skills.bedrock`
- `invoke_chat(*, case_id, system, messages, max_tokens=1024, temperature=0.0, model_id=None) → str` — Bedrock Converse API. Default model from `BEDROCK_MODEL_ID`.
- `embed_text(*, case_id, text) → list[float]` — Titan v2 (or whatever `BEDROCK_EMBEDDING_MODEL_ID` points at).
- Raises: `BedrockError`.

### `skills._fixtures`
Hardcoded POC seed data for John Martinez (member, claims, extracted fields, messaging replies, call transcript, PCP slots, community resources, formulary). Mocks reference this so the case walks end-to-end with consistent data.

## External-system mock skills

> Each module has a `# MOCK:` comment at the top naming its real target.

### `skills.crm` — Salesforce Health Cloud
- `create_case(case_id, member_id, **fields) → str` — returns `CRM-NNNNNNNN`. Side-effect: in-memory dict.
- `update_case(case_id, crm_case_number, **fields) → None`.
- `create_task(case_id, title, *, due_at=None, priority="normal", links=None, **payload) → str` (`TASK-NNNNNNNN`).
- `create_appointment(case_id, appointment_id, slot, pcp_id) → str` — mirrors a booked appointment into CRM.
- `queue_for_cm(case_id, reason) → None`.

### `skills.member` — plan eligibility API
- `get_profile(case_id, member_id) → Member`. Raises `MemberNotFound`.
- `verify_identity(case_id, member_id, *, dob_provided, name_provided) → bool`.

### `skills.claims` — plan analytics API
- `get_member_history(case_id, member_id, lookback_months=24) → dict` — returns `{admits, ed_visits, care_gaps, prior_engagement}`.

### `skills.ehr` — FHIR R4 `/DocumentReference`
- `fetch_discharge_summary(case_id, member_id, discharge_date) → Path` — synthesizes a markdown stand-in for John Martinez on first call; raises `DocumentNotFound` for unknown members.

### `skills.documents` — Unstructured + Tesseract
- `parse_pdf(case_id, path) → str` — reads `.pdf` or `.md` stand-ins. Raises `DocumentNotFound`.
- `extract_fields(case_id, document_text) → list[ExtractedField]` — deterministic mock. Returns the canned 13-field John Martinez extraction with one flagged-low-confidence row (medication_changes @ 0.72). Used by unit tests and offline smoke scripts; **not** invoked by `document_extraction_agent` at runtime — LLM failures there propagate to the orchestrator's retry/escalate policy rather than being papered over with mock data.
- `extract_fields_llm(case_id, document_text, *, model_id=None, max_tokens=2048, temperature=0.0) → list[ExtractedField]` — Bedrock Converse per-field extractor using the prompt in [config.extraction](config/extraction.py). Parses the model's JSON, normalizes each entry into an `ExtractedField`, applies the 0.80 flag threshold deterministically, and stores the LLM's per-field rationale in `source_bbox.reason`. Raises `BedrockError` on transport failure; raises `ExtractionParseError` (also a `SkillError`) when the model's response isn't valid JSON.

### `skills.formulary` — PBM API
- `check_coverage(case_id, drug_name, member_plan) → dict` — `{covered, tier, prior_auth_required, copay_estimate}`.

### `skills.scheduling` — Epic MyChart Scheduling
- `get_availability(case_id, pcp_id, window_start, window_end) → list[datetime]`.
- `book_appointment(case_id, pcp_id, slot, *, provider_name, location, specialty) → Appointment` — returns an unsaved `Appointment`; persistence is the agent's responsibility (via `db.state_io.insert_appointment`).

### `skills.sms` — Twilio Messaging API
- `send(case_id, phone, body) → str` — returns a fake `SM*` SID when `TWILIO_STUB=true` (default); appends a tab-separated record to `data/outbox/sms.log` with the phone redacted.

### `skills.email` — aiosmtplib
- `send(case_id, to, subject, body, body_html=None) → str` — returns a fake `MSG-*` id when `SMTP_OFF=true` (default); appends a record to `data/outbox/email.log`.

### `skills.calendar` — member portal calendar service
- `add_event(case_id, member_id, when, title, kind="appointment", **payload) → str` — in-memory dict.

### `skills.messaging` — Twilio Conversations (vendor TBD)
- `open_session(case_id, member_id, member_phone) → str` (`MS-NNNNNNNN`).
- `send_message(case_id, session_id, text) → None` — logs to `data/outbox/messaging.log`.
- `poll_for_reply(case_id, session_id, timeout_seconds=10) → str | None` — returns the next canned John Martinez reply, or `None` once exhausted.
- `close_session(case_id, session_id) → None`.

### `skills.transcript` — AWS Transcribe Medical (vendor TBD)
- `get_recent(case_id, call_id, n=10) → list[CallTurn]` — last N turns of the canned transcript.
- `subscribe(case_id, call_id, *, interval_s=0.05) → AsyncIterator[CallTurn]` — async generator simulating a live feed.

### `skills.sentiment` — vendor TBD
- `score_turn(case_id, text) → dict` — `{score_0_100, label}`. Keyword-heuristic mock that trends positive on affirmatives.

### `skills.community` — Findhelp / Aunt Bertha
- `search_resources(case_id, *, need_type, member_zip=None, subtype=None) → list[dict]` — pulse oximeter + transport seeded for Springfield zips.

### `skills.knowledge` — (RAG over `knowledge_chunks`, not a mock)
- `search_guidelines(case_id, query, k=5) → list[GuidelineHit]` — Titan-v2 query embedding, HNSW cosine retrieval. Returns chunks with `(source_doc, section_title, chunk_text, similarity)`.

## Internal-only skills (not mocks)

### `skills.templates`
- `render(case_id, template_name, context) → str` — Jinja2 over `templates/`. Strict-undefined.

### `skills.pdf`
- `render(case_id, template_name, context, *, output_path=None) → Path` — Jinja2 + WeasyPrint. **Falls back to writing HTML** on `weasyprint` import failure (Windows GTK3 trap); returns whatever path was written.

### `skills.webhook`
- `post(case_id, payload, *, url=None) → dict` — real httpx POST with tenacity retry (3 attempts, exponential backoff). Returns `{ok: false, error, error_type}` on failure (graceful — never raises).

### `skills.events`
- `emit(case_id, event_type, payload=None) → int` — inserts into `case_events`.
- `pop_unprocessed(limit=50) → list[dict]` — `SELECT ... FOR UPDATE SKIP LOCKED` so multiple consumers don't double-process.
- `mark_processed(event_id, delivery_status) → None`.

### `skills.ui`
- `push_prompt(case_id, prompt_id, payload) → None`.
- `push_sentiment(case_id, sentiment_event) → None`.
- `push_slot_options(case_id, call_id, slots) → None`.
- POC behavior: in-memory ring buffer per case + line append to `data/outbox/ui_pushes.log`. Replaced by real WebSocket fan-out in Step 7+.
